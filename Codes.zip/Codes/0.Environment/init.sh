#!/bin/sh

PythonIntepreter=
AnacondaDir=
DatabaseDIR=

BaseinDir=

mkdir -p $BaseinDir
mkdir -p $BaseinDir/data
mkdir -p $BaseinDir/data/assembly
mkdir -p $BaseinDir/data/rnaseq
mkdir -p $BaseinDir/data/wgs
mkdir -p $BaseinDir/data/preds
mkdir -p $BaseinDir/data/preds/augustus_config
mkdir -p $BaseinDir/data/busco
mkdir -p $BaseinDir/msa
mkdir -p $BaseinDir/msa/align
mkdir -p $BaseinDir/msa/trim
mkdir -p $BaseinDir/msa/matrix
mkdir -p $BaseinDir/phylo
mkdir -p $BaseinDir/timing
