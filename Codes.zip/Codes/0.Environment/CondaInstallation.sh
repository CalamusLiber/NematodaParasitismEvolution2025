#!/bin/sh
conda update conda
conda update anaconda
conda config --add channels thiesgehrmann
conda install python=3.9.12
conda install biopython
conda install arviz
conda install numba
conda install -c conda-forge scikit-learn-extra kneed
conda clean -p && conda clean -y --all 
conda env list /user/home/vn21703/anaconda3 
conda env list /public1/home/scb4616/apps/anaconda3

conda create -n blastenv
conda install -n blastenv blast=2.12.0 diamond=2.0.15

conda create -n makerenv
conda install -n makerenv maker
conda install -c thiesgehrmann -n makerenv genemark_es
conda install -n makerenv star bedtools repeatmodeler pasa metaeuk

conda create -n repmaskenv python=3.7
conda install -n repmaskenv repeatmasker repeatmodeler edta dfam 

conda create -n braker2env
conda install -n braker2env braker2

conda create -n buscoenv python=3.9
conda install -n buscoenv r-base r-ggplot2 metaeuk=6.a5d39d9-1 prodigal sepp busco=5.4.3

conda create -n orthofinderenv python=2.7
conda install -n orthofinderenv orthofinder
conda install -n orthofinderenv -c conda-forge ucx

conda create -n gmshowenv
conda install -n gmshowenv jbrowse2 apollo pygenometracks igv

conda create -n newpy python=3.10 

conda create -n assemblingenv 
conda install -n assemblingenv spades soapdenovo2 soapdenovo2-gapcloser soapdenovo2-prepare

conda create -n rnaseqenv 
conda install -n rnaseqenv trinity=2.13.2 soapdenovo-trans transdecoder # soapdenovo2也可用于组装转录组, 但是有点问题

# conda create -n transrateenv 
# conda install -n transrateenv transrate transrate-tools

conda create -n seqqc
conda install -n seqqc fastp fastqc besst

conda create -n msaenv
conda install -n msaenv mafft bmge 
conda install -n msaenv -c jlsteenwyk phykit clipkit

conda create -n phylobayes
conda install -n phylobayes -c bioconda phylobayes-mpi

conda env list 
conda info -e
source activate your_env_nam
conda remove -n your_env_name --all
conda remove --name $your_env_name  $package_names