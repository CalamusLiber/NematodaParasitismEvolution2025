MuHiSSEModels3 <- function(phy, data, f=c(1,1,1,1), n.hidden.states=1, allow.extirpation=TRUE, keep.all.models=FALSE, criterion='AIC', multiprocessors=8){
    PruneRedundantModelsX <- function(..., precision = 1e-05){
        models <- list(...)
        if (!inherits(models[[1]], what = c("geohisse.fit", "hisse.fit", "misse.fit", "muhisse.fit"))) {
            models <- models[[1]]
        }
        mod.class.geohisse <- sapply(models, function(x) inherits(x, what = "geohisse.fit"))
        mod.class.hisse <- sapply(models, function(x) inherits(x, what = "hisse.fit"))
        mod.class.misse <- sapply(models, function(x) inherits(x, what = "misse.fit"))
        mod.class.muhisse <- sapply(models, function(x) inherits(x, what = "muhisse.fit"))
        if (all(mod.class.geohisse) & all(mod.class.hisse) & all(mod.class.misse) & all(mod.class.muhisse)) {
            stop("list of models need to be only HiSSE, MuHiSSE, GeoHiSSE, or MiSSE fits.")
        }
        if (!all(mod.class.geohisse) & !all(mod.class.hisse) & !all(mod.class.misse) & !all(mod.class.muhisse)) {
            stop("list of models need to be only HiSSE, MuHiSSE, GeoHiSSE, or MiSSE fits.")
        }
        mod.nparameters <- simplify2array(lapply(lapply(models, "[[", "starting.vals"), length))
        models <- models[order(mod.nparameters, decreasing = FALSE)]
        mod.loglik <- simplify2array(lapply(models, "[[", "loglik"))
        models_to_delete <- c()
        isTrueAllEqual <- function(...) {
            return(isTRUE(all.equal(...)))
        }
        if (length(models) > 1) {
            for (i in 2:(length(models))) {
                if (any(sapply(mod.loglik[1:(i - 1)], isTrueAllEqual, mod.loglik[i], tolerance = precision))) {
                    models_to_delete <- c(models_to_delete, i)
                }
            }
        }
        return(models_to_delete)
    }
    
    MODELS <- NULL
    Conf <- NULL
    
    # whether allowing extirpation (11 to 10/01 transitions)
    xnd <- ifelse(allow.extirpation, 20, 15) 

	for (nhs in n.hidden.states){
		# When nhs = 1, they are set for MuSSE models; while nhs > 1 the models are set with hidden states. At maximum, there could be 320 candidate models with up to 8 hidden states.
		HiState <- ifelse(nhs==1, FALSE, TRUE)

		# Initialize the loop counter
		rd <- which(n.hidden.states == nhs)

		for (qq in 2:1){
			# When qq = 2, transition rates are the same across all hidden states and between hidden states (null models), and no variation of transitions among hidden categories; when qq = 1, alternatively, these transition rates are unconstrained.

			# mod01*: Dull null model for 3-state MuSSE (turnover and extinction fraction are the same for all observed state combinations, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal)
			# turnover parameters: tau00=0, tau01=tau10=tau11
			tau <- rep(c(0,1,1,1), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model
			trm <- TransMatMakerMuHiSSE(hidden.traits=nhs-1, make.null=ifelse(qq==2,TRUE,FALSE), include.diagonals=TRUE, cat.trans.vary=ifelse(qq==2,FALSE,TRUE))
			# excluding 00 observed state
			trm[substr(rownames(trm),2,3)=='00',][!is.na(trm)[substr(rownames(trm),2,3)=='00',]] <- 0
			trm[,substr(rownames(trm),2,3)=='00'][!is.na(trm)[,substr(rownames(trm),2,3)=='00']] <- 0
			# disallowing 11>10 or 11>01 transitions
			trm[substr(rownames(trm),2,3)=='11',][!is.na(trm)[substr(rownames(trm),2,3)=='11',]] <- 0
			# reroder the remaining indices
			uni <- !is.na(trm) & trm>0
			xy <- rank(unique(as.vector(trm[uni])))
			names(xy) <- unique(na.omit(as.vector(trm[uni])))
			trm[uni] <- xy[as.character(na.omit(as.vector(trm[uni])))]
			# setting equality for q
			trm[trm>0] <- 1
			Conf[[1+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			# mod02*: Null model for 3-state MuSSE (turnover is the same for 01 and 10 states but free for 11 state, extinction fraction is same for all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal)
			# turnover parameters: tau00=0, tau01=tau10, tau11
			tau <- rep(c(0,1,1,2), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model (same as mod1*)
			Conf[[2+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			# mod03*: Null model for 3-state MuSSE (turnover varies across all observed states, extinction fraction is same for all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal)
			# turnover parameters: tau00=0, tau01, tau10, tau11
			tau <- rep(c(0,1,2,3), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model (same as mod1*)
			Conf[[3+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)

			# mod04*: Null model for 3-state MuSSE (turnover and extinction fraction are the same for 01 and 10 states but free for 11 state, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal)
			# turnover parameters: tau00=0, tau01=tau10, tau11
			tau <- rep(c(0,1,1,2), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10, ef11
			eps <- rep(c(0,1,1,2), nhs)
			# transition rate model (same as mod1*)
			Conf[[4+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			# mod05*: Null model for 3-state MuSSE (turnover and extinction fraction vary across all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal)
			# turnover parameters: tau00=0, tau01, tau10, tau11
			tau <- rep(c(0,1,2,3), nhs)
			# extinct fraction parameters: ef00=0, ef01, ef10, ef11
			eps <- rep(c(0,1,2,3), nhs)
			# transition rate model (same as mod1*)
			Conf[[5+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)

			# mod06*: Null model for 3-state MuSSE (turnover and extinction fraction are the same for all observed state combinations, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal for 01>11 and 10>11 transitions)
			# turnover parameters: tau00=0, tau01=tau10=tau11
			# turnover parameters: tau00=0, tau01=tau10=tau11
			tau <- rep(c(0,1,1,1), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model
			trm <- TransMatMakerMuHiSSE(hidden.traits=nhs-1, make.null=ifelse(qq==2,TRUE,FALSE), include.diagonals=TRUE, cat.trans.vary=ifelse(qq==2,FALSE,TRUE))
			# excluding 00 observed state
			trm[substr(rownames(trm),2,3)=='00',][!is.na(trm)[substr(rownames(trm),2,3)=='00',]] <- 0
			trm[,substr(rownames(trm),2,3)=='00'][!is.na(trm)[,substr(rownames(trm),2,3)=='00']] <- 0
			# disallowing 11>10 or 11>01 transitions
			trm[substr(rownames(trm),2,3)=='11',][!is.na(trm)[substr(rownames(trm),2,3)=='11',]] <- 0
			# setting equality for q of 01>11 and 10>11 transitions
			trm[substr(colnames(trm),2,3)=='10',substr(colnames(trm),2,3)=='11'] <- trm[substr(colnames(trm),2,3)=='01',substr(colnames(trm),2,3)=='11']
			# reroder the remaining indices
			uni <- !is.na(trm) & trm>0
			xy <- rank(unique(as.vector(trm[uni])))
			names(xy) <- unique(na.omit(as.vector(trm[uni])))
			trm[uni] <- xy[as.character(na.omit(as.vector(trm[uni])))]
			Conf[[6+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			# mod07*: Null model for 3-state MuSSE (turnover is the same for 01 and 10 states but free for 11 state, extinction fraction is same for all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal for 01>11 and 10>11 transitions)
			# turnover parameters: tau00=0, tau01=tau10, tau11
			tau <- rep(c(0,1,1,2), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model (same as mod6*)
			Conf[[7+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			# mod08*: Null model for 3-state MuSSE (turnover varies across all observed states, extinction fraction is same for all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal for 01>11 and 10>11 transitions)
			# turnover parameters: tau00=0, tau01, tau10, tau11
			tau <- rep(c(0,1,2,3), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model (same as mod6*)
			Conf[[8+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)

			# mod09*: Null model for 3-state MuSSE (turnover and extinction fraction are the same for 01 and 10 states but free for 11 state, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal for 01>11 and 10>11 transitions)
			# turnover parameters: tau00=0, tau01=tau10, tau11
			tau <- rep(c(0,1,1,2), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,2), nhs)
			# transition rate model (same as mod6*)
			Conf[[9+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			# mod10*: Null model for 3-state MuSSE (turnover and extinction fraction vary across all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's equal for 01>11 and 10>11 transitions)
			# turnover parameters: tau00=0, tau01, tau10, tau11
			tau <- rep(c(0,1,2,3), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,2,3), nhs)
			# transition rate model (same as mod6*)
			Conf[[10+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)

			# mod11*: Null model for 3-state MuSSE (turnover and extinction fraction are the same for all observed state combinations, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
			# turnover parameters: tau00=0, tau01=tau10=tau11
			tau <- rep(c(0,1,1,1), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model
			trm <- TransMatMakerMuHiSSE(hidden.traits=nhs-1, make.null=ifelse(qq==2,TRUE,FALSE), include.diagonals=TRUE, cat.trans.vary=ifelse(qq==2,FALSE,TRUE))
			# excluding 00 observed state
			trm[substr(rownames(trm),2,3)=='00',][!is.na(trm)[substr(rownames(trm),2,3)=='00',]] <- 0
			trm[,substr(rownames(trm),2,3)=='00'][!is.na(trm)[,substr(rownames(trm),2,3)=='00']] <- 0
			# disallowing 11>10 or 11>01 transitions
			trm[substr(rownames(trm),2,3)=='11',][!is.na(trm)[substr(rownames(trm),2,3)=='11',]] <- 0
			# reroder the remaining indices
			uni <- !is.na(trm) & trm>0
			xy <- rank(unique(as.vector(trm[uni])))
			names(xy) <- unique(na.omit(as.vector(trm[uni])))
			trm[uni] <- xy[as.character(na.omit(as.vector(trm[uni])))]
			Conf[[11+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
						
			# mod12*: Null model for 3-state MuSSE (turnover is the same for 01 and 10 states but free for 11 state, extinction fraction is same for all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
			# turnover parameters: tau00=0, tau01=tau10, tau11
			tau <- rep(c(0,1,1,2), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model (same as mod11*)
			Conf[[12+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			# mod13*: Null model for 3-state MuSSE (turnover varies across all observed states, extinction fraction is same for all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
			# turnover parameters: tau00=0, tau01, tau10, tau11
			tau <- rep(c(0,1,2,3), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,1), nhs)
			# transition rate model (same as mod11*)
			Conf[[13+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)

			# mod14*: Null model for 3-state MuSSE (turnover and extinction fraction are the same for 01 and 10 states but free for 11 state, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
			# turnover parameters: tau00=0, tau01=tau10, tau11
			tau <- rep(c(0,1,1,2), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,1,2), nhs)
			# transition rate model (same as mod11*)
			Conf[[14+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			# mod15*: Null model for 3-state MuSSE (turnover and extinction fraction vary across all observed states, disallowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
			# turnover parameters: tau00=0, tau01, tau10, tau11
			tau <- rep(c(0,1,2,3), nhs)
			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
			eps <- rep(c(0,1,2,3), nhs)
			# transition rate model (same as mod11*)
			Conf[[15+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			
			if (allow.extirpation){
    			# mod16*: Null model for 3-state MuSSE (turnover and extinction fraction are the same for all observed state combinations, allowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
    			# turnover parameters: tau00=0, tau01=tau10=tau11
    			tau <- rep(c(0,1,1,1), nhs)
    			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
    			eps <- rep(c(0,1,1,1), nhs)
    			# transition rate model
    			trm <- TransMatMakerMuHiSSE(hidden.traits=nhs-1, make.null=ifelse(qq==2,TRUE,FALSE), include.diagonals=TRUE, cat.trans.vary=ifelse(qq==2,FALSE,TRUE))
    			# excluding 00 observed state
    			trm[substr(rownames(trm),2,3)=='00',][!is.na(trm)[substr(rownames(trm),2,3)=='00',]] <- 0
    			trm[,substr(rownames(trm),2,3)=='00'][!is.na(trm)[,substr(rownames(trm),2,3)=='00']] <- 0
    			# reroder the remaining indices
    			uni <- !is.na(trm) & trm>0
    			xy <- rank(unique(as.vector(trm[uni])))
    			names(xy) <- unique(na.omit(as.vector(trm[uni])))
    			trm[uni] <- xy[as.character(na.omit(as.vector(trm[uni])))]
    			Conf[[16+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
    			
    			# mod17*: Null model for 3-state MuSSE (turnover is the same for 01 and 10 states but free for 11 state, extinction fraction is same for all observed states, allowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
    			# turnover parameters: tau00=0, tau01=tau10, tau11
    			tau <- rep(c(0,1,1,2), nhs)
    			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
    			eps <- rep(c(0,1,1,1), nhs)
    			# transition rate model (same as mod16*)
    			Conf[[17+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
    			
    			# mod18*: Null model for 3-state MuSSE (turnover varies across all observed states, extinction fraction is same for all observed states, allowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
    			# turnover parameters: tau00=0, tau01, tau10, tau11
    			tau <- rep(c(0,1,2,3), nhs)
    			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
    			eps <- rep(c(0,1,1,1), nhs)
    			# transition rate model (same as mod16*)
    			Conf[[18+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
    
    			# mod19*: Null model for 3-state MuSSE (turnover and extinction fraction are the same for 01 and 10 states but free for 11 state, allowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
    			# turnover parameters: tau00=0, tau01=tau10, tau11
    			tau <- rep(c(0,1,1,2), nhs)
    			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
    			eps <- rep(c(0,1,1,2), nhs)
    			# transition rate model (same as mod16*)
    			Conf[[19+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
    			
    			# mod20*: Null model for 3-state MuSSE (turnover and extinction fraction vary across all observed states, allowing 11>10 or 11>01 transitions, transition rates are the same across all hidden states and between hidden states, no variation of transitions among hidden categories, q's free for all allowed transitions)
    			# turnover parameters: tau00=0, tau01, tau10, tau11
    			tau <- rep(c(0,1,2,3), nhs)
    			# extinct fraction parameters: ef00=0, ef01=ef10=ef11
    			eps <- rep(c(0,1,2,3), nhs)
    			# transition rate model (same as mod16*)
    			Conf[[20+xnd*(rd*2-qq)]] <- list(tau=tau, eps=eps, trate=trm, HiState=HiState)
			}
		}
	}
	
	NumConf <- length(Conf)

	library(doParallel)
    cl <- makeCluster(multiprocessors, type="PSOCK")
    registerDoParallel(cl)
    MODELS <- foreach(i=1:NumConf, .combine = list, .multicombine = TRUE, .maxcombine = NumConf, .packages = c('ape', 'hisse')) %dopar% 
	    MuHiSSE(phy=phy, data=data, f=f, turnover=Conf[[i]]$tau, eps=Conf[[i]]$eps, hidden.states=Conf[[i]]$HiState, trans.rate=Conf[[i]]$trate, turnover.upper=10000, eps.upper=3, trans.upper=100)

	stopCluster(cl)

	cat('MuHiSSE modelling finished.\n')

	# return(Conf)
	
	ModelSelection <- data.frame(Model=rep(NA, NumConf), lnlik=rep(NA, NumConf), n.parameters=rep(NA, NumConf), AIC=rep(NA, NumConf), AICc=rep(NA, NumConf))

	for (j in 1:NumConf){
	    ModelSelection[j, 'Model'] <- j
	    ModelSelection[j, 'lnlik'] <- MODELS[[j]]$loglik
	    ModelSelection[j, 'n.parameters'] <- length(MODELS[[j]]$starting.vals)
	    ModelSelection[j, 'AIC'] <- MODELS[[j]]$AIC
	    ModelSelection[j, 'AICc'] <- MODELS[[j]]$AICc
	}

	models_to_delete <- PruneRedundantModelsX(MODELS)

    if (keep.all.models){

        ModelSelectionSorted <- ModelSelection[with(ModelSelection,order(ModelSelection[,criterion])),]
        ModelSelectionSorted[,ifelse(criterion=='AICc', 'dAICc', 'dAIC')] <- ModelSelectionSorted[,criterion]-ModelSelectionSorted[1,criterion]
        ModelSelectionSorted[,'w'] <- exp(-0.5*ModelSelectionSorted[,ifelse(criterion=='AICc', 'dAICc', 'dAIC')])/sum(exp(-0.5*ModelSelectionSorted[,ifelse(criterion=='AICc', 'dAICc', 'dAIC')]))

        MODELS <- MODELS[ModelSelectionSorted[,'Model']]

        cat('MuHiSSE sorting finished.\n')

        Pred.AllModels <- list()
        for (k in 1:length(MODELS)){
            Pred.AllModels[[k]] <- MarginReconMuHiSSE(phy=phy, data=data, f=f, pars=MODELS[[k]]$solution, hidden.states=nrow(MODELS[[k]]$trans.matrix)/4, condition.on.survival=TRUE, root.type="madfitz", root.p=NULL, includes.fossils = FALSE, k.samples = NULL, AIC=MODELS[[k]][[criterion]], get.tips.only=FALSE, verbose=TRUE, n.cores=multiprocessors, dt.threads=1)
        }

        cat('MuHiSSE marginal ancestral state estimation finished.\n')

        ModelAveRates <- GetModelAveRates(Pred.AllModels, AIC.weights=ModelSelectionSorted[,'w'], type="nodes")

        cat('MuHiSSE all-model averaging (on nodes) finished.\n')

        ModelAveRates.BestModel <- GetModelAveRates(Pred.AllModels[[1]], AIC.weights=NULL, type="both")

        cat('MuHiSSE best-model averaging (on both nodes and tips) finished.\n')

        # SupportRegion.BestModel <- SupportRegionHiSSE(MODELS[[1]])

        # cat('MuHiSSE adaptive sampling of the likelihood surface finished.\n')

        return(list(ModelSelection=ModelSelectionSorted, AllModels=MODELS, ModelAveRates=ModelAveRates, Pred.AllModels=Pred.AllModels, BestModel=MODELS[[1]], ModelAveRates.BestModel=ModelAveRates.BestModel))

    }else if (length(models_to_delete) > 0){

        ModelSelection <- ModelSelection[-models_to_delete, ]

        cat('MuHiSSE pruning finished.\n')

        ModelSelectionSorted <- ModelSelection[with(ModelSelection,order(ModelSelection[,criterion])),]
        ModelSelectionSorted[,ifelse(criterion=='AICc', 'dAICc', 'dAIC')] <- ModelSelectionSorted[,criterion]-ModelSelectionSorted[1,criterion]
        ModelSelectionSorted[,'w'] <- exp(-0.5*ModelSelectionSorted[,ifelse(criterion=='AICc', 'dAICc', 'dAIC')])/sum(exp(-0.5*ModelSelectionSorted[,ifelse(criterion=='AICc', 'dAICc', 'dAIC')]))
        RefinedModels <- MODELS[ModelSelectionSorted[,'Model']]

        cat('MuHiSSE sorting finished.\n')

        Pred.RefinedModels <- list()
        for (k in 1:length(RefinedModels)){
            Pred.RefinedModels[[k]] <- MarginReconMuHiSSE(phy=phy, data=data, f=f, pars=RefinedModels[[k]]$solution, hidden.states=nrow(RefinedModels[[k]]$trans.matrix)/4, condition.on.survival=TRUE, root.type="madfitz", root.p=NULL, includes.fossils = FALSE, k.samples = NULL, AIC=RefinedModels[[k]][[criterion]], get.tips.only=FALSE, verbose=TRUE, n.cores=multiprocessors, dt.threads=1)
        }

        cat('MuHiSSE marginal ancestral state estimation finished.\n')

        ModelAveRates <- GetModelAveRates(Pred.RefinedModels, AIC.weights=ModelSelectionSorted[,'w'], type="both")

        cat('MuHiSSE all-model averaging (on nodes) finished.\n')

        ModelAveRates.BestModel <- GetModelAveRates(Pred.RefinedModels[[1]], AIC.weights=NULL, type="both")

        cat('MuHiSSE best-model averaging (on both nodes and tips) finished.\n')

        # SupportRegion.BestModel <- SupportRegionHiSSE(RefinedModels[[1]])

        # cat('MuHiSSE adaptive sampling of the likelihood surface finished.\n')

        return(list(ModelSelection=ModelSelectionSorted, RefinedModels=RefinedModels, ModelAveRates=ModelAveRates, Pred.RefinedModels=Pred.RefinedModels, BestModel=RefinedModels[[1]], ModelAveRates.BestModel=ModelAveRates.BestModel))
	}
}
