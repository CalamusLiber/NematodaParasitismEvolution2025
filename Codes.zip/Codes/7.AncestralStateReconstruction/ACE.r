# setwd('E:/BristolProjects/Nematoda/lifehistory')
setwd('/mnt/hdd2/Nematoda/lifehistory')
save.image('./NemaLifeHist.RData')
save.image("./.RData")
load('./NemaLifeHist.RData')
source('./HiSSEModels.r')
# source('./MuHiSSEModels.r')
source('./SSEStateRateTest.r')

library(readxl)
library(ape)
library(vegan);library(ips);library(phytools)
library(ggtree);library(treeio)
library(future);library(doParallel)
library(hisse) # install_github(repo = "thej022214/hisse", ref = "master")
library(geiger)
library(ggplot2)

## input data----
# 184-taxon trees
cLGPMSF1 <- read.beast('../timing/20241203/Res_posttrees/PRD-DBSCAN-AverageTree_Grp_1.tre')
cLGPMSF5 <- read.beast('../timing/20241203/Res_posttrees/PRD-DBSCAN-AverageTree_Grp_5.tre')
C60PMSF <- read.beast('../timing/20241203/CalibrSensitivityAnalysis/FinalTimeTrees/NMtimetree_CalibrSensitivityAnalysis.C60PMSF.CST1.5P.IR.rg15_combined_time_tree_good.tre')
LG <- read.beast('../timing/20241203/CalibrSensitivityAnalysis/FinalTimeTrees/NMtimetree_CalibrSensitivityAnalysis.LG.CST3.5P.IR.rg15_combined_time_tree_good.tre')
Trad <- read.beast('../timing/20241203/CalibrSensitivityAnalysis/FinalTimeTrees/NMtimetree_CalibrSensitivityAnalysis.Trad.CST1.5P.IR.rg15_combined_time_tree_good.tre')

cLGPMSF1 <- drop.tip(cLGPMSF1@phylo, tip = cLGPMSF1@phylo$tip.label[1:25]) # Nematoda + Tardigrada
cLGPMSF5 <- drop.tip(cLGPMSF5@phylo, tip = cLGPMSF5@phylo$tip.label[1:25]) # Nematoda + Tardigrada
C60PMSF <- drop.tip(C60PMSF@phylo, tip = C60PMSF@phylo$tip.label[1:22]) # Nematoda + Tardigrada + Nematomorpha
LG <- drop.tip(LG@phylo, tip = LG@phylo$tip.label[1:22]) # Nematoda + Tardigrada + Nematomorpha
Trad <- drop.tip(Trad@phylo, tip = Trad@phylo$tip.label[1:25]) # Nematoda + Nematomorpha

# life history data
LifeHist<-as.data.frame(read_excel('./NematodaTreeTaxonHabitats.xlsx',sheet=2,col_names = T))
rownames(LifeHist)<-LifeHist[,1]
Parasitic <- LifeHist[,4]
Habitat <- LifeHist[,5]
Marine <- LifeHist[,6]
Freshwater <- LifeHist[,7]
Terrestrial <- LifeHist[,8]
names(Parasitic) <- names(Habitat) <- names(Marine) <- names(Freshwater) <- names(Terrestrial) <- LifeHist[,1]

## data cleaning----
rownames(LifeHist)%in%cLGPMSF1$tip.label
rownames(LifeHist)%in%cLGPMSF5$tip.label
rownames(LifeHist)%in%C60PMSF$tip.label
rownames(LifeHist)%in%LG$tip.label
rownames(LifeHist)%in%Trad$tip.label

# mapping ace-result onto nodes----
ParasiticColorS<-c('#0000aa','#ffaadd','#4dda2a')
HabitatColorS<-c('#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#f781bf', '#a65628')

## HiSSE----
# data of species richness: 
# Tardigrada: 1464 spp., according to (Degma and Guidetti 2023) online dataset, 2023-Jan-09
# Nematomorpha: 356 spp., according to Catalogue of Life online dataset, 2024-May-20
# Nematoda: 28537 described spp. according to (Hodda 2022, Phylum Nematoda: a classification). In a book published in 2013, Gardner (2013) estimated approximately 14,000–16,000 species of parasitic nematodes are parasitic (Encyclopedia of Biodiversity (Second Edition), when there were about 25043 species described (Zhang 2013, Zootaxa). From 2011 to 2011 to 2019 there are 3590 species were found as new, in which 1595 are free-living (44.42%) and 1995 are parasitic (55.57%) (Hodda 2022, Phylum Nematoda: trends in species descriptions). So, in a binary life style diviation, we estimate the number of parasitic species as (28537 - 25043) * 0.5557 + 16000 = 17942, that is the number of free-living species is 28537 - 17942 = 10595.
# Rhabdiasidae: 113 spp.; Strongyloididae: 82 spp.; Diplogasteromorpha: 483 spp. according to (Hodda 2022, Phylum Nematoda: a classification), totally 678 spp.

# For cLGPMSF, f=c(sum(LifeHist[cLGPMSF$tip.label, 'Parasitic']==0)/(10595+1464), sum(LifeHist[cLGPMSF$tip.label, 'Parasitic'])/(17942)) = c(0.005, 0.006)
# For C60PMSF, f=c(sum(LifeHist[C60PMSF$tip.label, 'Parasitic']==0)/(10595+1464), sum(LifeHist[C60PMSF$tip.label, 'Parasitic'])/(17942+356)) = c(0.005, 0.006)
# For LG, f=c(sum(LifeHist[LG$tip.label, 'Parasitic']==0)/(10595+1464), sum(LifeHist[LG$tip.label, 'Parasitic'])/(17942+356)) = c(0.005, 0.006)
# For Trad, f=c(sum(LifeHist[Trad$tip.label, 'Parasitic']==0)/(10595), sum(LifeHist[Trad$tip.label, 'Parasitic'])/(17942+356)) = c(0.005, 0.006)
# So, we use f=c(0.005, 0.006) for all the four HiSSE estimations.

Parasitic_cLGPMSF1_hisse <- HiSSEModels(phy=ladderize(cLGPMSF1), data=LifeHist[cLGPMSF1$tip.label, c('Tip_label', 'Parasitic')], f=c(0.005, 0.006), multiprocessors = 50)

Parasitic_cLGPMSF5_hisse <- HiSSEModels(phy=ladderize(cLGPMSF5), data=LifeHist[cLGPMSF5$tip.label, c('Tip_label', 'Parasitic')], f=c(0.005, 0.006), multiprocessors = 50)

Parasitic_C60PMSF_hisse <- HiSSEModels(phy=ladderize(C60PMSF), data=LifeHist[C60PMSF$tip.label, c('Tip_label', 'Parasitic')], f=c(0.005, 0.006), multiprocessors = 50)

Parasitic_LG_hisse <- HiSSEModels(phy=ladderize(LG), data=LifeHist[LG$tip.label, c('Tip_label', 'Parasitic')], f=c(0.005, 0.006), multiprocessors = 50)

Parasitic_Trad_hisse <- HiSSEModels(phy=ladderize(Trad), data=LifeHist[Trad$tip.label, c('Tip_label', 'Parasitic')], f=c(0.005, 0.006), multiprocessors = 50)

save.image('./NemaLifeHist.RData')

# For cLGPMSF, f=c(sum(LifeHist[cLGPMSF$tip.label, 'FreeLiving'])/(10595+1464+678), sum(LifeHist[cLGPMSF$tip.label, 'FreeLiving']==0)/(17942-678)) = c(0.005, 0.005)
# For C60PMSF, f=c(sum(LifeHist[C60PMSF$tip.label, 'FreeLiving'])/(10595+1464+678), sum(LifeHist[C60PMSF$tip.label, 'FreeLiving']==0)/(17942+356-678)) = c(0.005, 0.005)
# For LG, f=c(sum(LifeHist[LG$tip.label, 'FreeLiving'])/(10595+1464+678), sum(LifeHist[LG$tip.label, 'FreeLiving']==0)/(17942+356-678)) = c(0.005, 0.005)
# For Trad, f=c(sum(LifeHist[Trad$tip.label, 'FreeLiving'])/(10595+678), sum(LifeHist[Trad$tip.label, 'FreeLiving']==0)/(17942+356-678)) = c(0.006, 0.005)
# So, we use f=c(0.005, 0.005) for all the four HiSSE estimations but f=c(0.006, 0.005) for the Trad-tree-based reconstruction.

LHX <- LifeHist[,c('Tip_label', 'FreeLiving')]

LHX[, 'FreeLiving'] <- 1-LHX[, 'FreeLiving']

FreeLiving_cLGPMSF1_hisse <- HiSSEModels(phy=ladderize(cLGPMSF1), data=LHX[cLGPMSF1$tip.label, ], f=c(0.005, 0.005), multiprocessors = 50)

FreeLiving_cLGPMSF5_hisse <- HiSSEModels(phy=ladderize(cLGPMSF5), data=LHX[cLGPMSF5$tip.label, ], f=c(0.005, 0.005), multiprocessors = 50)

FreeLiving_C60PMSF_hisse <- HiSSEModels(phy=ladderize(C60PMSF), data=LHX[C60PMSF$tip.label, ], f=c(0.005, 0.005), multiprocessors = 50)

FreeLiving_LG_hisse <- HiSSEModels(phy=ladderize(LG), data=LHX[LG$tip.label, ], f=c(0.005, 0.005), multiprocessors = 50)

FreeLiving_Trad_hisse <- HiSSEModels(phy=ladderize(Trad), data=LHX[Trad$tip.label, ], f=c(0.006, 0.005), multiprocessors = 50)

save.image('./NemaLifeHist.RData')

## plotting HiSSE models----

for (fp in c('Parasitic', 'FreeLiving')){
    for (PhyModel in c('cLGPMSF1', 'cLGPMSF5', 'C60PMSF', 'LG', 'Trad')){
        svg(paste('./', fp, '_', PhyModel, '_hisse_p.svg', sep = ''), onefile = T, width = 10, height = 20, pointsize = 10, bg = "transparent")
            assign(paste(fp, '_', PhyModel, '_hisse_p_treeplots', sep = ''), plot.hisse.states(x = get(paste(fp, '_', PhyModel, '_hisse', sep = ''))$Pred.RefinedModels[[1]], rate.param = "net.div", rate.colors=c('#559900', '#ff5500'), type = "phylogram", show.tip.label = TRUE, legend ='internal'))
        dev.off()
        
        svg(paste('./', fp, '_', PhyModel, '_hisse_p_rs.svg', sep = ''), onefile = T, width = 20, height = 20, pointsize = 10, bg = "transparent")
            layout(matrix(1:2,1,2))
            get(paste(fp, '_', PhyModel, '_hisse_p_treeplots', sep = ''))$state.tree %>% plot(., direction='rightwards')
            get(paste(fp, '_', PhyModel, '_hisse_p_treeplots', sep = ''))$rate.tree %>% plot(., direction='leftwards')
        dev.off()
        
        svg(paste('./', fp, '_', PhyModel, '_hisse_c.svg', sep = ''), onefile = T, width = 10, height = 15, pointsize = 10, bg = "transparent")
            assign(paste(fp, '_', PhyModel, '_hisse_c_treeplots', sep = ''), plot.hisse.states(x = get(paste(fp, '_', PhyModel, '_hisse', sep = ''))$Pred.RefinedModels[[1]], rate.param = "net.div", rate.colors=c('#559900', '#ff5500'), type = "fan", show.tip.label = FALSE, legend = 'internal'))
        dev.off()
        
        svg(paste('./', fp, '_', PhyModel, '_hisse_c_rs.svg', sep = ''), onefile = T, width = 20, height = 15, pointsize = 10, bg = "transparent")
            layout(matrix(1:2,1,2))
            get(paste(fp, '_', PhyModel, '_hisse_c_treeplots', sep = ''))$state.tree %>% plot(., type='fan', show.tiplabels=FALSE)
            get(paste(fp, '_', PhyModel, '_hisse_c_treeplots', sep = ''))$rate.tree %>% plot(., type='fan', show.tip.label=FALSE)
        dev.off()
    }
}

# system('bash ./svg2pdf.sh r')

# MuHiSSE----
# For cLGPMSF, f=c(0,(sum(ParasiticHi[cLGPMSF$tip.label,2])-4)/(17942-195),(sum(ParasiticHi[cLGPMSF$tip.label,3])-4)/(10595+1464-195),4/195) = c(0, 0.005, 0.005, 0.02)
# For C60PMSF, f=c(0,(sum(ParasiticHi[C60PMSF$tip.label,2])-4)/(17942+356-195),(sum(ParasiticHi[C60PMSF$tip.label,3])-4)/(10595+1464-195),4/195) = c(0, 0.005, 0.005, 0.02)
# For LG, f=c(0,(sum(ParasiticHi[LG$tip.label,2])-4)/(17942+356-195),(sum(ParasiticHi[LG$tip.label,3])-4)/(10595+1464-195),4/195) = c(0, 0.005, 0.005, 0.02)
# For Trad, f=c(0,(sum(ParasiticHi[Trad$tip.label,2])-4)/(17942+356-195),(sum(ParasiticHi[Trad$tip.label,3])-4)/(10595-195),4/195) = c(0, 0.005, 0.005, 0.02)
# So, we use f=c(0, 0.005, 0.005, 0.02) for all the four MuHiSSE estimations.

## Phylogenetic comparison----

RateData_Comb <- NULL
RateData_KN_Comb <- NULL

for (AmbiLifeStyle in c('Parasitic', 'FreeLiving')){
    PhyModel_Comb <- NULL
    PhyModel_KN_Comb <- NULL
    for (PhyModel in c('cLGPMSF1', 'cLGPMSF5', 'C60PMSF', 'LG', 'Trad')){
        
        if (PhyModel=='cLGPMSF5'){
            SSEStateRateTest(get(paste(AmbiLifeStyle,'_',PhyModel,'_hisse', sep = '')), bin.wd=10, cut.point=200, drop.outgroups=grep("^(NM_|TG_)", get(paste(AmbiLifeStyle,'_',PhyModel,'_hisse', sep = ''))$BestModel$phy$tip.label, value=TRUE), tag=paste(AmbiLifeStyle,'_',PhyModel, sep = ''))
        }else{
            SSEStateRateTest(get(paste(AmbiLifeStyle,'_',PhyModel,'_hisse', sep = '')), bin.wd=10, cut.point=90, drop.outgroups=grep("^(NM_|TG_)", get(paste(AmbiLifeStyle,'_',PhyModel,'_hisse', sep = ''))$BestModel$phy$tip.label, value=TRUE), tag=paste(AmbiLifeStyle,'_',PhyModel, sep = ''))
        }
        
        RateDataBest$Model <- 'Best'
        RateDataBest_KN$Model <- 'Best'
        RateDataModAvg$Model <- 'Averaged'
        RateDataModAvg_KN$Model <- 'Averaged'
        
        PhyModel_ALL <- rbind(RateDataModAvg, RateDataBest)
        PhyModel_KN <- rbind(RateDataModAvg_KN, RateDataBest_KN)
        
        PhyModel_ALL$AmbiLifeStyle <- AmbiLifeStyle
        PhyModel_KN$AmbiLifeStyle <- AmbiLifeStyle
        PhyModel_ALL$PhyModel <- PhyModel
        PhyModel_KN$PhyModel <- PhyModel
        
        PhyModel_Comb <- rbind(PhyModel_Comb, PhyModel_ALL)
        PhyModel_KN_Comb <- rbind(PhyModel_KN_Comb, PhyModel_KN)
        
        # in case that the function itself failed to print the figures
        # pdf(paste('./Rate Distributions Histogram for Nodes and Tips - ', AmbiLifeStyle, '_', PhyModel,  '.pdf', sep = ''), width = 60, height = 64, pointsize = 12)

        # ggsave(file = paste('./Rate Distributions Histogram for Nodes and Tips - ', AmbiLifeStyle, '_', PhyModel,  '.pdf', sep = ''), plot = mplt, width = 60, height = 64, limitsize = FALSE)
        
        # dev.off()
    }
    RateData_Comb <- rbind(RateData_Comb, PhyModel_Comb)
    RateData_KN_Comb <- rbind(RateData_KN_Comb, PhyModel_KN_Comb)
}

RateData_Comb <- RateData_Comb[,c('PhyModel', 'AmbiLifeStyle', 'Model', 'nodeid', 'time', 'state', 'net.div', 	'turnover', 'speciation', 'extinction', 'state2', 'state4')]
RateData_KN_Comb <- RateData_KN_Comb[,c('Node', 'PhyModel', 'AmbiLifeStyle', 'Model', 'time', 'state', 'net.div', 	'turnover', 'speciation', 'extinction', 'state2', 'state4')]

RateData_KN_Comb <- RateData_KN_Comb %>% arrange(Node, PhyModel, AmbiLifeStyle, Model)

write.csv(RateData_Comb, file = './HiSSE_RateDataForBothNodesAndTips.csv', row.names = F)
write.csv(RateData_KN_Comb, file = './HiSSE_RateDataForKeyNodes.csv', row.names=F)

rm(AmbiLifeStyle, PhyModel, RateDataBest, RateDataBest_KN, RateDataModAvg, RateDataModAvg_KN, PhyModel_Comb, PhyModel_KN_Comb, PhyModel_ALL, PhyModel_KN)

system('bash ./svg2pdf.sh r')

save.image('./NemaLifeHist.RData')
save.image('./.RData')
