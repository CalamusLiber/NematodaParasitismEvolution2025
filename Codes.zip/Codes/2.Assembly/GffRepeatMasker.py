#!/user/home/vn21703/anaconda3/bin/python3.9

# load libraries
from Bio import SeqIO
from Bio.Seq import Seq, MutableSeq
import pandas as pd
import argparse

def toN(seq, gffline):
    s = gffline['qstart']-1
    e = gffline['qend']    
    seq[s:e] = 'N' * (e - s)

def toLower(seq, gffline):
    s = gffline['qstart']-1
    e = gffline['qend']
    seq[s:e] = seq[s:e].lower()

def HardMask(contig):
    seqid = contig.id
    contig.seq = contig.seq.upper()
    if seqid in Gff.index:
        seqnew = MutableSeq(contig.seq)
        repregion = Gff.loc[seqid]
        if repregion.shape==(2,):
            toN(seqnew, repregion)
        else:
            repregion.apply(lambda x: toN(seqnew, x), axis=1)
        contig.seq = Seq(seqnew)
    else:
        pass

def SoftMask(contig):
    seqid = contig.id
    contig.seq = contig.seq.upper()
    if seqid in Gff.index:
        seqnew = MutableSeq(contig.seq)
        repregion = Gff.loc[seqid]
        if repregion.shape==(2,):
            toLower(seqnew, repregion)
        else:
            repregion.apply(lambda x: toLower(seqnew, x), axis=1)
        contig.seq = Seq(seqnew)
    else:
        pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--fasta', '-f',
                        type=str,
                        help='Sequences requiring masking')
    parser.add_argument('--gff', '-c',
                        type=str,
                        help='Location information table(csv) of contaminated fragments by blast')
    parser.add_argument('--out', '-o',
                        type=str,
                        help='The output path of the masked sequence',
                        default=".")
    parser.add_argument('--skip', '-s',
                        type=str,
                        help='The first N lines will be skipped when reading the gff file.',
                        default="0")
    parser.add_argument('--masktype', '-t',
                        type=str,
                        help='Wheter use N to replace the masked region or NOT (default use softmask by lowercase): hard, soft, both.',
                        default="soft")
    args = parser.parse_args()

    fastafile = args.fasta.replace('\\','/')
    fmt = fastafile.split('.')[-1]
    gfffile = args.gff.replace('\\','/')
    if args.out=='':
        outprefix = fastafile.replace(fastafile.split("/")[-1], "")
    else:
        outprefix = args.out.replace('\\','/') + '/'
    
    Gff = pd.read_csv(gfffile, names=['sseqid', 'qstart', 'qend'], index_col=0, header=None, usecols=[0,3,4], skiprows=int(args.skip), sep="\t")
    Fas = pd.Series(SeqIO.parse(fastafile, "fasta"))
    if args.masktype.lower()=='hard':
        Fas.apply(HardMask)
        SeqIO.write(Fas, outprefix + fastafile.split("/")[-1].replace('.'+fmt, ".hardmask."+fmt), "fasta")
    elif args.masktype.lower()=='soft':
        Fas.apply(SoftMask)
        SeqIO.write(Fas, outprefix + fastafile.split("/")[-1].replace('.'+fmt, ".softmask."+fmt), "fasta")
    elif args.masktype.lower()=='both':
        Fas.apply(SoftMask)
        SeqIO.write(Fas, outprefix + fastafile.split("/")[-1].replace('.'+fmt, ".softmask."+fmt), "fasta")
        Fas.apply(HardMask)
        SeqIO.write(Fas, outprefix + fastafile.split("/")[-1].replace('.'+fmt, ".hardmask."+fmt), "fasta")
    else:
        print("Check --masktype setting, please!")
        quit()
