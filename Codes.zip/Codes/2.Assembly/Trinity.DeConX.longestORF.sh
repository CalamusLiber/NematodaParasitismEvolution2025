#!/bin/sh

# module load lang/perl/5.30.0-bioperl-gcc 
# module load apps/trinity/2.8.5
module load apps/samtools/1.9
# module load apps/bowtie2/2.3.5
# module load lib/boost/1.71.0
module load lang/intel-parallel-studio-xe/2020
alias python='/home/vn21703/miniconda3/bin/python3.9'
alias python3='/home/vn21703/miniconda3/bin/python3.9'
export PATH=$PATH:/home/vn21703/miniconda3/bin:/home/vn21703/miniconda3/pkgs
export TRINITY_HOME=/home/vn21703/trinityrnaseq

cd $WORK/nematoda/data/rnaseq/trans_ass_sift
mkdir $WORK/nematoda/data/rnaseq/trans_ass_sift_longest

rnaseq_list=$(ls *.DeContX* | sed -e "s/.fasta//g")

####Multithread preparation
tmp_fifofile="/tmp/$$.fifo"
trap "exec 9>&-;exec 9<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile

for ((i=1;i<=24;i++))
do
    echo >&9
done

for nrna in $rnaseq_list
do
    read -u9
    {
    
    if [[ $(ls -l ./"$nrna".fasta | awk '{ print $5 }') -gt 0 ]]; then
        echo -e "Selecting the longest isoform of "$nrna".fasta.\n" >> ../DeContX.longestORF.log
        perl ${TRINITY_HOME}/util/misc/get_longest_isoform_seq_per_trinity_gene.pl ./"$nrna".fasta > ../trans_ass_sift_longest/"$nrna"_longest.fasta && 
        echo -e "**********************************************\n" >> ../DeContX.longestORF.log
        echo -e "XXX>>> Longest isoform of "$nrna".fasta is stored in trans_ass_sift_longest/"$nrna"_longest.fasta.\n" >> ../DeContX.longestORF.log
        echo -e "**********************************************\n" >> ../DeContX.longestORF.log
    else 
        echo -e "**********************************************\n" >> ../DeContX.longestORF.log
        echo -e "But "$nrna".fasta file is empty.\n" >> ../DeContX.longestORF.log 
        echo -e "**********************************************\n\n" >> ../DeContX.longestORF.log
    fi
    
    echo >&9 
    } &   
done
wait

