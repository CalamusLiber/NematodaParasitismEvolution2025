#!/bin/sh
#SBATCH --job-name=NMTrinity.9

# module load lang/perl/5.30.0-bioperl-gcc 
# module load apps/trinity/2.8.5
# module load apps/samtools/1.9
# module load apps/bowtie2/2.3.5
# module load lib/boost/1.71.0
# module load lang/intel-parallel-studio-xe/2020
# alias python='/user/home/vn21703/anaconda3/bin/python3.9'
# alias python3='/user/home/vn21703/anaconda3/bin/python3.9'
export PATH=$PATH:/user/home/vn21703/anaconda3/bin:/user/home/vn21703/anaconda3/envs/rnaseqenv/bin
# export TRINITY_HOME=/user/home/vn21703/trinityrnaseq
# export TDC_DIR=/user/home/vn21703/TransDecoder

cd /user/work/vn21703/nematoda/data/rnaseq
DIR_cur=$(pwd)
HOME=/user/home/vn21703
DIR_cnd=/user/home/vn21703/anaconda3

source $DIR_cnd/bin/activate $DIR_cnd/envs/rnaseqenv

DIR_asm=$DIR_cur/trans_assembly
DIR_tdcout=$DIR_cur/transdecodes
DIR_tdcoutLg=$DIR_cur/transdecodesLongest

mkdir -p ./AfterQC.reports
mkdir -p $DIR_asm
mkdir -p $DIR_tdcout
mkdir -p $DIR_tdcoutLg

nrna=$1

echo -e "#######################\nTrinity Assembling start...\n$(date)\n#######################\n\n" >> NMTrinity.9.$nrna.log && 
echo -e "JOB NAME: $SLURM_JOB_NAME\nJob ID: $SLURM_JOBID\nAllocate Nodes: $SLURM_JOB_NODELIST\n" >> NMTrinity.9.$nrna.log && 
time0=$(date) && start_sec=$(date --date="$time0" +%s) 

fq1=$DIR_cur/$nrna.R1.fastq
fq2=$DIR_cur/$nrna.R2.fastq

if [ ! -d $nrna.AfterQC.output ]; then 
    echo "Trimming $nrna starts." >> NMTrinity.9.$nrna.log

    mkdir $nrna.AfterQC.output	

    $HOME/pypy2/bin/pypy $HOME/AfterQC/after.py -1 $fq1 -2 $fq2 -g $nrna.AfterQC.output -b $nrna.AfterQC.output -r AfterQC.reports >> NMTrinity.9.$nrna.log 2>&1 && 

    rm $nrna.AfterQC.output/*.bad.fq && 

    echo "Trimming $nrna is done." >> NMTrinity.9.$nrna.log
fi

if [[ ! -f ./trans_assembly/"$nrna"_trinity.Trinity.fasta ]]; then
    Trinity --seqType fq --max_memory 150G --left $nrna.AfterQC.output/$nrna.R1.good.fq --right $nrna.AfterQC.output/$nrna.R2.good.fq --CPU $[$SLURM_NTASKS-2] --output "$nrna"_trinity >> NMTrinity.9.$nrna.log 2>&1 &&
    mv "$nrna"_trinity.Trinity.fasta* ./trans_assembly && 
    echo "Assembling $nrna is done." >> NMTrinity.9.$nrna.log 
else
    echo ""$nrna"_trinity.Trinity.fasta exists, skip Trinity." >> NMTrinity.9.$nrna.log 
fi

if [[ $(ls -l ./trans_assembly/"$nrna"_trinity.Trinity.fasta | awk '{ print $5 }') -gt 0 ]]; then
    echo "Selecting the longest isoform." >> NMTrinity.9.$nrna.log && 
    perl $DIR_cnd/envs/rnaseqenv/opt/trinity-2.13.2/util/misc/get_longest_isoform_seq_per_trinity_gene.pl ./trans_assembly/"$nrna"_trinity.Trinity.fasta > ./trans_assembly/"$nrna"_trinity_longest.fasta && 
    echo -e "**********************************************\nXXX>>> $nrna Trinity job is done successfully.\n**********************************************" >> NMTrinity.9.$nrna.log && 
    rm -R ./$nrna.AfterQC.output && 
    rm -R ./"$nrna"_trinity
else 
    echo -e "**********************************************\nXXXXX $nrna Trinity job expires.\nXXXXX But "$nrna"_trinity.Trinity.fasta file was not found.\n**********************************************" >> NMTrinity.9.$nrna.log
fi

echo "TransDecoding $nrna starts." >> NMTrinity.9.$nrna.log

TransDecoder.LongOrfs -t $DIR_asm/"$nrna"_trinity.Trinity.fasta --gene_trans_map $DIR_asm/"$nrna"_trinity.Trinity.fasta.gene_trans_map >> NMTrinity.9.$nrna.log 2>&1 &&

TransDecoder.Predict -t $DIR_asm/"$nrna"_trinity.Trinity.fasta >> NMTrinity.9.$nrna.log 2>&1 &&

mv $DIR_cur/"$nrna"*.transdecoder.* $DIR_tdcout &&

mv $DIR_tdcout/"$nrna"*.transdecoder.pep $DIR_tdcout/"$nrna"_trinity.tdc.pep.faa && 

rm -R $DIR_cur/$nrna*.transdecoder_dir* &&

echo "TransDecoding $nrna LongestORF starts." >> NMTrinity.9.$nrna.log && 

TransDecoder.LongOrfs -t $DIR_asm/"$nrna"_trinity_longest.fasta --gene_trans_map $DIR_asm/"$nrna"_trinity.Trinity.fasta.gene_trans_map >> NMTrinity.9.$nrna.log 2>&1 && 

TransDecoder.Predict -t $DIR_asm/"$nrna"_trinity_longest.fasta >> NMTrinity.9.$nrna.log 2>&1 && 

mv $DIR_cur/"$nrna"*.transdecoder.* $DIR_tdcoutLg && 

mv $DIR_tdcoutLg/"$nrna"*.transdecoder.pep $DIR_tdcoutLg/"$nrna"_trinity.tdclongest.pep.faa && 

rm -R $DIR_cur/$nrna*.transdecoder_dir* && 

echo "TransDecoding $nrna LongestORF finished." >> NMTrinity.9.$nrna.log 

time1=$(date) && end_sec=$(date --date="$time1" +%s) && 
dsec=$((end_sec-start_sec)) && dhour=$(echo "scale=4; $dsec / 3600" | bc) && 
echo -e "#######################\nTransDecoding $nrna finished.\nAll assembling work accomplished.\n$time1\nOverall elapsed time: $dsec sec (= $dhour hr).\n#######################\n\n" >> NMTrinity.9.$nrna.log 
