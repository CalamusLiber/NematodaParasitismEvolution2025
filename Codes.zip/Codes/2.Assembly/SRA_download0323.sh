#!/bin/bash

DIR_data=/mnt/sdb/SRAData/Coleoptera_zty/SRA_AM
DIR_current=$(cd $(dirname $0);pwd)
DIR_csv=$DIR_current/Myxophaga_Archostemata.csv

mkdir $DIR_data/AM_RNA
cd $DIR_data/AM_RNA
for n in  {7..10}
do
accession=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$4}')
organism=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$6}')
http_download=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$10}')

output_pre="$organism"_"$accession"

echo "*****************"
echo "$output_pre"

axel -a -n 10 $http_download  --output=$output_pre
/apps/sratoolkit/bin/fasterq-dump -e 6 -p --split-3 --skip-technical $output_pre 
rm $output_pre

done

mkdir $DIR_data/AM_WGS
cd $DIR_data/AM_WGS
for n in  {3..6}
do
accession=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$4}')
organism=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$6}')
http_download=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$10}')

output_pre="$organism"_"$accession"

echo "*****************"
echo "$output_pre"

axel -a -n 10 $http_download  --output=$output_pre
/apps/sratoolkit/bin/fasterq-dump -e 6 -p --split-3 --skip-technical $output_pre 
rm $output_pre

done