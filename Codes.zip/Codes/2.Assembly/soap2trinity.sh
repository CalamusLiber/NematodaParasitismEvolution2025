#!/bin/sh

soapin=$1
if [$2 -eq ""]; then 
    if [[ $soapin =~ '/' ]]; then 
        trinityout=${soapin/.soap/.soap_trinity.Trinity}
    else
        trinityout="./${soapin/.soap/.soap_trinity.Trinity}"
    fi
else
    if [[ $2 =~ '/' ]]; then 
        trinityout=$2
    else
        trinityout="./$2"
    fi
fi

LineNum=($(grep -n "^>" $soapin | awk -F ":>" '{print $1}')) 
ContigTagQ=($(sed -n -e 's/scaffold[0-9]* Locus_/SOAP_DN/g;s/_\([0-9]*\) /_c0_g1_i\1 /g;s/  / /;s/>//p' $soapin | awk '{print $1}')) 
LastLine=$(cat $soapin | wc -l)

# convert sequence into a contig array
for ((g=1;g<${#ContigTagQ[*]};g++)) 
do 
    # get the seq of of the #g th contig
    sline=$[${LineNum[$[$g-1]]}+1] 
    eline=$[${LineNum[$[$g]]}-1] 
    seq0=$(sed -n "${sline},${eline}p" $soapin) 
    seq1=$(echo $seq0 | sed -e "s/ //g") 

    # write the seq and tags into local disc (one line per contig)
    echo ">${ContigTagQ[$g]} len=${#seq1} path=[0:0-$[${#seq1}-1]]" >> $trinityout 
    echo ${seq1} >> $trinityout 
done

# write the last seq and tag into local disc (one line per contig)
seq0=$(sed -n "$[${LineNum[-1]}+1],${LastLine}p" $soapin) 
seq1=$(echo $seq0 | sed -e "s/ //g") 
echo ">${ContigTagQ[-1]} len=${#seq1} path=[0:0-$[${#seq1}-1]]" >> $trinityout 
echo ${seq1} >> $trinityout 
