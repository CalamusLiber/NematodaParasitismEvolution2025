#!/bin/sh
#SBATCH --job-name=NMDecont.5
#SBATCH --partition=compute
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=3
#SBATCH --cpus-per-task=8
#SBATCH --mem=350GB
#SBATCH --exclusive

DNP=$SLURM_CPUS_PER_TASK
NT=$[$SLURM_NNODES*$SLURM_NTASKS_PER_NODE]
FNP=$[$SLURM_NTASKS-2]

cd /user/work/vn21703/nematoda/data/rnaseq
DIR_cur=$(pwd)
DIR_cnd=/user/home/vn21703/anaconda3
UniVecDB=/user/work/vn21703/db/UniVec/UniVec
NRDiaDB=/user/work/vn21703/db/nr/nr.dmnd
SeqOrinPiePlot=/user/work/vn21703/nematoda/data/SeqOriginPiePlot.py
TaxDumpDB=/user/work/vn21703/db/taxdump # change to "remote" when you want to use NCBI-taxonomy online, but not recommended on BluePebble

DIR_asm=$DIR_cur/trans_assembly
DIR_sif=$DIR_cur/trans_ass_sift
DIR_dec=$DIR_cur/decontamination
DIR_tdc=$DIR_cur/transdecodesX
DIR_Trc=$DIR_cur/TranscriptContents

mkdir -p $DIR_sif
mkdir -p $DIR_dec
mkdir -p $DIR_tdc
mkdir -p $DIR_Trc

InputFasta=$(ls ./trans_assembly/*_trinity.Trinity.fasta | sed -e "s/.fasta//g;s/.\/trans_assembly\///g") # all input fasta files
NNN=$(echo $InputFasta | wc -w)

EcdysFasta=$(ls ./trans_assembly/*_trinity.Trinity.fasta | sed -e "s/.fasta//g;s/.\/trans_assembly\///g" | grep -E "^OP_|^KR_|^TG_|^PA_|^LR_") # those (from Onychophora, Kinorhyncha, Tardigrada, Priapulida, Loricifera) should be decontaminated by searching Ecdysozoan genes

### Functions
runDeVect(){

    local rnatri=$(echo $1 | sed -e "s#$DIR_asm\/##g;s#.fasta##g")

    if [[ $EcdysFasta =~ $rnatri ]]; then 
        local DeConProg=/user/work/vn21703/nematoda/data/DeContaminRNA-tx.py
    else
        local DeConProg=/user/work/vn21703/nematoda/data/DeContaminRNA-rk.py
    fi
    
    echo -e "\n########################\nRemoval of vector sequences...\n$(date)\n########################\n" 
    echo -e "\n========================\nScreening $rnatri.fasta (round 1)...\n========================\n" 

    cp $1 $DIR_sif/$rnatri.Sifted.fasta
        
    echo -e "\nStart screening $rnatri.fasta.\n" 
    echo -e "\n$(blastn -version)\n" 
    blastn -db $UniVecDB -query $DIR_sif/$rnatri.Sifted.fasta -out $DIR_dec/$rnatri.decont -outfmt "6 qseqid sseqid qstart qend staxids" -task blastn -reward 1 -penalty -5 -gapopen 3 -gapextend 3 -dust yes -soft_masking true -evalue 700 -searchsp 1750000000000 && 
    echo -e "\nFinished screening $rnatri.fasta.\n$(date)\n" 
    
    local counter=1

    while [ $(ls -l $DIR_dec/$rnatri.decont | awk '{ print $5 }') -gt 0 -a $counter -le 10 ] 
    do
        echo -e "\n========================\nScreening $rnatri.fasta (round $[$counter+1])...\n$(date)\n========================\n" 
        echo -e "\nRemoving vector sequences from $rnatri.fasta...\n" 
        $DeConProg --fasta $DIR_sif/$rnatri.Sifted.fasta --csv $DIR_dec/$rnatri.decont --out $DIR_sif --keep && 
        mv -f $DIR_sif/$rnatri.Sifted.Sifted.fasta $DIR_sif/$rnatri.Sifted.fasta &&         
        echo -e "\nFinished. Clean assembly saved to $DIR_sif/$rnatri.Sifted.fasta...\n$(date)\n" 

        echo -e "\n========================\nScreening $DIR_sif/$rnatri.Sifted.fasta to confirm no vector sequences...\n$(date)\n========================\n" 
        rm $DIR_dec/$rnatri.decont && 
        blastn -db $UniVecDB -query $DIR_sif/$rnatri.Sifted.fasta -out $DIR_dec/$rnatri.decont -outfmt "6 qseqid sseqid qstart qend staxids" -task blastn -reward 1 -penalty -5 -gapopen 3 -gapextend 3 -dust yes -soft_masking true -evalue 700 -searchsp 1750000000000 && 
        echo -e "\nFinished screening $DIR_sif/$rnatri.Sifted.fasta.\n$(date)\n" 
        
        ((counter++))
    done
    
    echo -e "\n########################\nCleaning Vectors from $rnatri is accomplished after $counter rounds.\n$(date)\n########################\n" 
}

runFindAlien(){

    local rnatri=$(echo $1 | sed -e "s#$DIR_sif\/##g;s#.Sifted.fasta##g")

    echo -e "\n########################\nSearching contaminated sequences...\n$(date)\n########################\n" 

    if [[ ! -f $DIR_dec/$rnatri.decontX ]] || [[ $(ls -l $DIR_dec/$rnatri.decontX | awk '{ print $5 }') -eq 0 ]]; then 
        echo -e "\n========================\nSearching the unwanted transcripts by Diamond and non-redundant protein database...\n$(date)\n========================\n" && 
        diamond blastx --threads $DNP --db $NRDiaDB --query $1 --out $DIR_dec/$rnatri.decontX --outfmt 6 qseqid sseqid qstart qend score evalue pident ppos staxids --max-target-seqs 10 --fast && 
        echo -e "\nFinished screening $DIR_sif/$rnatri.Sifted.fasta.\n$(date)\n" 
    else
        echo -e "\n########################\nScreening $rnatri.Sifted.fasta has already been accomplished, no need to do it again.\n$(date)\n########################\n" 
    fi
}

runDeCont(){

    local rnatri=$(echo $1 | sed -e "s#$DIR_sif\/##g;s#.Sifted.fasta##g")

    if [[ $EcdysFasta =~ $rnatri ]]; then 
        local DeConProg=/user/work/vn21703/nematoda/data/DeContaminRNA-tx.py
        local DeConVad=Ecdysozoa
    else
        local DeConProg=/user/work/vn21703/nematoda/data/DeContaminRNA-rk.py
        local DeConVad=phylum
    fi
    
    echo -e "\n########################\nRemoval of contaminated sequences...\n$(date)\n########################\n" 

    echo -e "\n========================\nRemoving alien transcripts from the assembly $rnatri ...\n$(date)\n========================\n" && 
    $DeConProg --fasta $DIR_sif/$rnatri.Sifted.fasta --csv $DIR_dec/$rnatri.decontX --out $DIR_sif --sensitive 0 --valid $DeConVad --db $TaxDumpDB &&
    echo -e "\nFinished. Clean assembly saved to $DIR_sif/$rnatri.Sifted.DeContX.fasta...\n$(date)\n" 

    echo -e "\n########################\nCleaning alien transcripts from $rnatri is accomplished...\n$(date)\n########################\n" 
}

chmod -R 777 /user/work/vn21703/nematoda/data/*.py 

source $DIR_cnd/bin/activate $DIR_cnd/envs/blastenv 

### Remove vector fragments
# Multithread preparation
tmp_fifofile="/tmp/$$.fifo" 
trap "exec 9>&-;exec 9<&-;exit 0" 2 
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile

for ((i=1;i<=$FNP;i++))
do
    echo >&9
done

# vector-removing processes
for rnatri in $InputFasta
do
    read -u9
    {

    # remove vector fragments
    if [[ ! -f $DIR_dec/$rnatri.decont ]] || [[ $(ls -l $DIR_dec/$rnatri.decont | awk '{ print $5 }') -gt 0 ]]; then 
        runDeVect $DIR_asm/$rnatri.fasta >> $DIR_dec/$rnatri.DecontamRNA.6.log 2>&1 
    else
        echo -e "\n########################\nCleaning Vectors from $rnatri has already been accomplished, no need to do it again.\n$(date)\n########################\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log 
    fi 

    echo >&9 
    } & 
done
wait

### Finding decontamination
# Multithread preparation
tmp_fifofile="/tmp/$$.fifo"
trap "exec 9>&-;exec 9<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile

for ((i=1;i<=$NT;i++))
do
    echo >&9
done

# Finding decontamination process
for rnatri in $InputFasta
do
    read -u9
    {

    # remove transcripts that are likely to be from unwanted taxa
    while [[ ! -f $DIR_dec/$rnatri.decontX ]] || [[ $(ls -l $DIR_dec/$rnatri.decontX | awk '{ print $5 }') -eq 0 ]] 
    do
        runFindAlien $DIR_sif/$rnatri.Sifted.fasta >> $DIR_dec/$rnatri.DecontamRNA.6.log 2>&1 
    done

    echo >&9 
    } & 
done
wait

source $DIR_cnd/bin/deactivate 

source $DIR_cnd/bin/activate $DIR_cnd/envs/rnaseqenv

### Decontamination, Transdecode decontaminated assemblies, and Display transcript origins
# Multithread preparation
tmp_fifofile="/tmp/$$.fifo"
trap "exec 9>&-;exec 9<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile

for ((i=1;i<=$FNP;i++))
do
    echo >&9
done

# 
SiftFasta=$(ls $DIR_dec/*_trinity.Trinity.decontX | sed -e "s#.decontX##g;s#$DIR_dec\/##g")

for rnatri in $SiftFasta
do
    read -u9
    {

    # remove transcripts that are likely to be from unwanted taxa
    while [[ ! -f $DIR_sif/$rnatri.Sifted.DeContX.fasta ]] || [[ $(ls -l $DIR_sif/$rnatri.Sifted.DeContX.fasta | awk '{ print $5 }') -lt 100 ]] 
    do
        runDeCont $DIR_sif/$rnatri.Sifted.fasta >> $DIR_dec/$rnatri.DecontamRNA.6.log 2>&1 
    done
    
    # Transdecode decontaminated assemblies
    if [[ ! -f $DIR_tdc/$(echo $rnatri | sed -e "s/_trinity.Trinity//g").Trans.DX.L.pep.faa ]]; then
        echo "\n========================\nSelecting the longest isoform.\n$(date)\n========================\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log && 
        perl $DIR_cnd/envs/rnaseqenv/opt/trinity-2.13.2/util/misc/get_longest_isoform_seq_per_trinity_gene.pl $DIR_sif/$rnatri.Sifted.DeContX.fasta > $DIR_sif/$rnatri.Sifted.DeContX.L.fasta && 
        
        echo "\n========================\nTransDecoding $rnatri (Sifted+DeContX) LongestORF starts.\n$(date)\n========================\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log && 
        TransDecoder.LongOrfs -t $DIR_sif/$rnatri.Sifted.DeContX.L.fasta >> $DIR_dec/$rnatri.DecontamRNA.6.log 2>&1 && 
        TransDecoder.Predict -t $DIR_sif/$rnatri.Sifted.DeContX.L.fasta >> $DIR_dec/$rnatri.DecontamRNA.6.log 2>&1 && 
        mv $DIR_cur/"$rnatri"*.transdecoder.* $DIR_tdc && 
        mv $DIR_tdc/"$rnatri"*.transdecoder.pep $DIR_tdc/$(echo $rnatri | sed -e "s/_trinity.Trinity//g").Trans.DX.L.pep.faa && 
        rm -rf $DIR_cur/$rnatri*.transdecoder_dir* && 
        echo "\n========================\nTransDecoding $rnatri (Sifted+DeContX) LongestORF finished.\n$(date)\n========================\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log 
    else
        echo -e "\n########################\nTransdecoding has already been accomplished, no need to do it again.\n$(date)\n########################\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log 
    fi

    # Display transcript origins
    if [[ ! -f $DIR_Trc/$rnatri.png ]]; then
        echo -e "\n========================\nDrawing $nrna ...\n$(date)\n========================\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log && 
        $SeqOrinPiePlot --infile $DIR_dec/$rnatri.decontX --out $DIR_Trc --db $TaxDumpDB >> $DIR_dec/$rnatri.DecontamRNA.6.log 2>&1 && 
        echo -e "\n========================\nFinished $nrna ...\n$(date)\n========================\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log         
    else
        echo -e "\n########################\nDrawing has already been accomplished, no need to do it again.\n$(date)\n########################\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log 
    fi

    echo -e "\n########################\nAll data processing for $nrna has been done.\n$(date)\n########################\n" >> $DIR_dec/$rnatri.DecontamRNA.6.log 

    echo >&9 
    } & 
done
wait


