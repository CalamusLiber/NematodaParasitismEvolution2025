#!/bin/bash

DIR_data=/mnt/sdb/SRAData/Coleoptera_zty/Assembly
DIR_current=$(cd $(dirname $0);pwd)
DIR_csv=$DIR_current/*.csv
mkdir $DIR_data
cd $DIR_data

for n in  {2..62}
do
organism=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$1}')
accession=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$2}')
http_download=$(sed -n "$n"p $DIR_csv | awk -F',' '{print$3}')

output_pre="$organism"_"$accession".fna.gz

echo "*****************"
echo "$output_pre"
#axel -a -n 10 $http_download  --output=$output_pre
wget -O $output_pre $http_download
gzip -d $output_pre

done
