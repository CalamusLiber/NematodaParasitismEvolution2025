from Bio import Entrez
from datetime import datetime
from bs4 import BeautifulSoup
from pandas import DataFrame, concat
from math import ceil
import pandas as pd
import argparse
from tqdm import tqdm
Entrez.email ='A.N.Other@example.com'

# def ProcBar(percent, StartStr='', EndStr='', TotalLength=50):
#     bar = ''.join(["\033[0;42m%s\033[0m"%' '] * int(percent * TotalLength)) + ''
#     bar = '\r' + StartStr + bar.ljust(TotalLength) + ' {:0>4.1f}%'.format(percent*100) + EndStr
#     print(bar, end='', flush=True)

def get_assembly_info(id):
    #get info of id
    raw_info_id = Entrez.esummary(db="assembly", id=id)
    record_id = raw_info_id.read()
    id_info = BeautifulSoup(record_id, "lxml")
    AssemblyStatus = id_info.find_all("assemblystatus")[0].string
    # 'Scaffold'
    if str(AssemblyStatus) in ['Contig','Scaffold','Chromosome','Complete Genome']:
        # info
        #print(id + " : " + AssemblyStatus)
        AssemblyAccession = id_info.find_all("assemblyaccession")[0].string
        AssemblyName = id_info.find_all("assemblyname")[0].string
        SpeciesName = id_info.find_all("speciesname")[0].string
        SpeciesTaxid = int(id_info.find_all("speciestaxid")[0].string)
        Coverage = id_info.find_all("coverage")[0].string
        ScaffoldN50 = id_info.find_all("scaffoldn50")[0].string
        for stat in id_info.find_all("stat"):
            if str(stat['category']) == 'total_length':
                total_length = stat.string
        FtpPath = id_info.find_all("ftppath_genbank")[0].string
        Download_Ftp = FtpPath + '/' + str(FtpPath.rsplit('/', 1)[1]) + '_genomic.fna.gz'
    #return_sum
    id_sum = [AssemblyAccession, AssemblyName, SpeciesName,SpeciesTaxid, AssemblyStatus, total_length, Coverage, ScaffoldN50,
              Download_Ftp]
    #return {'accession':accession,'organism':organism,'run_num':run_num,'szie(k)':size,'download_address':download_address}
    return id_sum

def get_taxinfo_df(taxid_list):
    taxinfo_tab=DataFrame(columns=['SpeciesTaxid','Phylum', 'SubPhylum', 'Class', 'Order', 'SubOrder', 'InfraOrder',
                                   'SuperFamily', 'Family', 'SubFamily','ScientificName'])
    Toatal_length=len(taxid_list)
    stp = [x * 10000 for x in range(ceil(Toatal_length / 10000))]
    for i in stp:
        print(' Get data from NCBI: ' + str(i) + " - " + str(i + 10000))
        TaxInfo=Entrez.read(Entrez.efetch(db="taxonomy",retstart=i, id=taxid_list))
        print(' Analyze data information...')
        for num_id in tqdm(range(len(TaxInfo)), colour = 'blue'):
            # ProcBar((num_id) / len(TaxInfo), StartStr='>>>', EndStr='|' + str(len(TaxInfo)) + ' records')
            taxinfo_dict = {}
            tax_id=int(TaxInfo[num_id]['TaxId'])
            taxinfo_dict['SpeciesTaxid'] = tax_id
            taxinfo_dict['ScientificName'] = TaxInfo[num_id]['ScientificName']
            for rank in ['Phylum', 'SubPhylum', 'Class', 'Order', 'SubOrder', 'InfraOrder', 'SuperFamily', 'Family', 'SubFamily']:
                try:
                    info_rank = [i['ScientificName'] for i in TaxInfo[num_id]['LineageEx'] if i['Rank'].lower() == rank.lower()][0]
                except IndexError:
                    info_rank = None
                taxinfo_dict[rank] = info_rank
            taxinfo_tab.loc[tax_id] = taxinfo_dict
        print(' ')
    print('Finally, the number of species is ' + str(len(taxinfo_tab)))
    return taxinfo_tab


def esearch_workfolw(Find_What):
    print("0-Start esearch :"+Find_What)
    FullRecords_id = Entrez.read(Entrez.esearch(db="assembly", RetMax=10000000, term=Find_What+"[Organism]"))
    idlist=FullRecords_id['IdList']
    print("1-The total data :"+str(len(idlist)))
    print("2-Get Assembly information :")
    print(' Getting data information...')
    df_assembly_info = DataFrame(columns=['AssemblyAccession', 'AssemblyName', 'SpeciesName','SpeciesTaxid', 'AssemblyStatus',
                                          'total_length', 'Coverage', 'ScaffoldN50','Download_Ftp'])
    for num_id in tqdm(range(len(idlist)), colour = 'green'):
        #print("Total number"+str(len(idlist)))
        # ProcBar((int(num_id)) / len(idlist), StartStr='>>>', EndStr='|' + str(len(idlist)) + ' records')
        try:
            id_sum=get_assembly_info(idlist[num_id])
            df_assembly_info.loc[idlist[num_id]] = id_sum
        except:
            continue
    print("")
    # print(df_assembly_info)

    print("3-Get taxon info :")
    taxid_list=list(set(list(df_assembly_info['SpeciesTaxid'])))
    print(taxid_list)
    df_taxinfo=get_taxinfo_df(taxid_list)
    print("4-Concat df_taxinfo and df_assembly_info")

    #Summarydf = concat([df_taxinfo, df_assembly_info], axis=1)
    Summarydf = pd.merge(df_taxinfo, df_assembly_info, how='right', right_on="SpeciesTaxid", left_index=True)
    #pd.set_option('display.max_columns', None)
    #可以展示所有数据

    print("5-Output Summary Table")
    #info to excel
    Assembly_Sort_table = Summarydf.sort_values(by=['AssemblyStatus','total_length'], ascending=[True,False])
    raw_table_rows=len(Assembly_Sort_table.index)
    print(" The number of original data items: "+str(raw_table_rows))
    Assembly_final_table = Assembly_Sort_table.drop_duplicates(subset=['SpeciesTaxid'], keep='first')
    filtered_table_rows=len(Assembly_final_table.index)
    print("     >Delete duplicate species data and only keep the maximum length. ")
    print(" The number of filtered data is: "+str(filtered_table_rows))
    #output_rawdata
    data = datetime.now().strftime('%Y%m%d')
    prefix=Find_What
    Assembly_Sort_table.to_excel('0-rawdata_{0}_{1}.xlsx'.format(prefix, data))

    Assembly_final_table.to_excel("1-{0}_Assembly_{1}.xlsx".format(prefix, data))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', '-i',
                        type=str,
                        help='Search content or can be a file containing search content line by line.'
                             'Format requirements according to NCBI')
    args = parser.parse_args()
    esearch_workfolw(args.input)
    #esearch_workfolw('Coleoptera')
    #Staphylinidae

