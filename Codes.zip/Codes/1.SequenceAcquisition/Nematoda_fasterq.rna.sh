#!/bin/bash
#SBATCH --job-name=NMFasterq
#SBATCH --exclusive
#SBATCH --partition=mwvdk
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=8
#SBATCH --mem=350GB

cd /user/work/vn21703/nematoda/data/rnaseq

DIR_current=$(pwd)

rnaseq_list=$(ls *_SRS*)

####Multithread preparation
tmp_fifofile="/tmp/$$.fifo"
trap "exec 6>&-;exec 6<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 6<>$tmp_fifofile 
rm $tmp_fifofile

for ((i=1;i<=8;i++))
do
    echo >&6
done

for rna in $rnaseq_list
do
    read -u6
    {   
    /user/home/vn21703/sratoolkit/bin/fasterq-dump -e 8 -p --split-3 --skip-technical $rna
    
    echo >&6 
    } & 
done
wait
