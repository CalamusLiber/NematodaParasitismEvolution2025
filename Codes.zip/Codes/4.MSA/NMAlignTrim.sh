#!/bin/bash
#SBATCH --job-name=NMBU.x
#SBATCH --exclusive
#SBATCH --partition=mwvdk
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=8
#SBATCH --mem=360GB

NP=$SLURM_CPUS_PER_TASK # 8
NT=$[$SLURM_NNODES*$SLURM_NTASKS_PER_NODE] # 16

# module load apps/iqtree/2.1.3
module load apps/bmge/1.12/
# module load apps/bmge/1.12

IQTREE=/sw/apps/iqtree-2.1.3-Linux/bin/iqtree2
BMGE=/sw/apps/BMGE-1.12/BMGE.jar
# FASconCATg=/user/home/vn21703/FASconCAT-G/FASconCAT-G_v1.05.pl
DIR_cnd=/user/home/vn21703/anaconda3
DIR_united=/user/work/vn21703/nematoda/data/busco/united
DIR_msa=/user/work/vn21703/nematoda/msa
DIR_align=$DIR_msa/align
DIR_trim=$DIR_msa/trim
DIR_matrix=$DIR_msa/matrix
DIR_log=$DIR_msa/log

mkdir -p $DIR_msa
mkdir -p $DIR_align
mkdir -p $DIR_trim
mkdir -p $DIR_trim/sbt
mkdir -p $DIR_trim/nom
mkdir -p $DIR_matrix
mkdir -p $DIR_log

source $DIR_cnd/bin/activate $DIR_cnd/envs/msaenv 

## MAFFT aligning
cd $DIR_united && 
UniteList=$(ls *.faa | sed 's/.faa//g')

tmp_fifofile="/tmp/$$.fifo"
trap "exec 9>&-;exec 9<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile
for ((i=1;i<=$NT;i++))
do
    echo >&9
done

for gene in $UniteList
do 
    read -u9
    {

    if [[ ! -f $DIR_align/$gene.mft.faa ]] || [[ $(ls -l $DIR_align/$gene.mft.faa | awk '{print $5}') -eq 0 ]]; then 
        echo -e "#######################\nAligning, Trimming, and Filtering - 1\n$(date)\n#######################\n\n" >> $DIR_log/$gene.msatreat.log && 
        echo -e "JOB NAME: $SLURM_JOB_NAME\nJob ID: $SLURM_JOBID\nAllocate Nodes: $SLURM_JOB_NODELIST\n" >> $DIR_log/$gene.msatreat.log && 
        echo -e "=======================\nAligning with MAFFT start...\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log && 
        einsi --maxiterate 1000 --reorder --anysymbol --thread $NP $DIR_united/$gene.faa > $DIR_align/$gene.mft.faa && 
        echo -e "=======================\nAligning with MAFFT accomplished.\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log 
    fi

    echo >&9 
    } & 
done
wait 

## BMGE trimming and PhyKit filtering
cd $DIR_trim

tmp_fifofile="/tmp/$$.fifo"
trap "exec 9>&-;exec 9<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile
for ((i=1;i<=$NT;i++))
do
    echo >&9
done

for gene in $UniteList
do 
    read -u9
    {
    
    echo -e "=======================\nTrimming with BMGE (normal) start...\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log && 
    java -Xmx90G -jar $BMGE -i $DIR_align/$gene.mft.faa -t AA -m BLOSUM90 -h 0.4 -s NO -of $DIR_trim/nom/$gene.mft.bmge.nom.faa >> $DIR_log/$gene.msatreat.log 2>&1 && 
    echo -e "=======================\nTrimming with BMGE (normal) accomplished.\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log && 

    echo -e "=======================\nFiltering with PhyKit (for normal BMGE output) start...\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log && 
    ptaxa1=$(grep '^>' $DIR_trim/nom/$gene.mft.bmge.nom.faa | wc -l) && 
    parsisite1=($(phykit parsimony_informative_sites $DIR_trim/nom/$gene.mft.bmge.nom.faa)) && # 3 values
    GCcont1=$(phykit gc_content $DIR_trim/nom/$gene.mft.bmge.nom.faa) && 
    RCV1=$(phykit relative_composition_variability $DIR_trim/nom/$gene.mft.bmge.nom.faa) && 
    EvolRate1=$(phykit pairwise_identity $DIR_trim/nom/$gene.mft.bmge.nom.faa | sed -n 1p | awk '{print $2}') && 
    echo -e "$DIR_trim/nom/$gene.mft.bmge.nom.faa,$ptaxa1,${parsisite1[0]},${parsisite1[1]},${parsisite1[2]},$GCcont1,$RCV1,$EvolRate1" >> $DIR_matrix/LociFilterMeasure.nom.list && 

    echo -e "=======================\nFiltering with PhyKit (for normal BMGE output) accomplished.\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log    
        
    echo >&9 
    } & 
done
wait 

tmp_fifofile="/tmp/$$.fifo"
trap "exec 9>&-;exec 9<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile
for ((i=1;i<=$NT;i++))
do
    echo >&9
done

for gene in $UniteList
do 
    read -u9
    {
    
    echo -e "=======================\nTrimming with BMGE (stationary-based) start...\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log && 
    java -Xmx90G -jar $BMGE -i $DIR_align/$gene.mft.faa -t AA -m BLOSUM90 -h 0.4 -s YES -of $DIR_trim/sbt/$gene.mft.bmge.sbt.faa >> $DIR_log/$gene.msatreat.log 2>&1 && 
    echo -e "=======================\nTrimming with BMGE (stationary-based) accomplished.\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log && 
    
    echo -e "=======================\nFiltering with PhyKit (for stationary-based BMGE output) start...\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log && 
    ptaxa2=$(grep '^>' $DIR_trim/sbt/$gene.mft.bmge.sbt.faa | wc -l) && 
    parsisite2=($(phykit parsimony_informative_sites $DIR_trim/sbt/$gene.mft.bmge.sbt.faa)) && # 3 values
    GCcont2=$(phykit gc_content $DIR_trim/sbt/$gene.mft.bmge.sbt.faa) && 
    RCV2=$(phykit relative_composition_variability $DIR_trim/sbt/$gene.mft.bmge.sbt.faa) && 
    EvolRate2=$(phykit pairwise_identity $DIR_trim/sbt/$gene.mft.bmge.sbt.faa | sed -n 1p | awk '{print $2}') && 
    echo -e "$DIR_trim/sbt/$gene.mft.bmge.sbt.faa,$ptaxa2,${parsisite2[0]},${parsisite2[1]},${parsisite2[2]},$GCcont2,$RCV2,$EvolRate2" >> $DIR_matrix/LociFilterMeasure.sbt.list && 

    echo -e "=======================\nFiltering with PhyKit (for stationary-based BMGE output) accomplished.\n$(date)\n=======================\n\n" >> $DIR_log/$gene.msatreat.log &&         
    
    time1=$(date) && end_sec=$(date --date="$time1" +%s) && 
    dsec=$((end_sec-start_sec)) && dhour=$(echo "scale=4; $dsec / 3600" | bc) 

    echo -e "#######################\nAligning, Trimming, and Filtering - 1 accomplished.\n$time1\nOverall elapsed time: $dsec sec (= $dhour hr).\n#######################\n\n" >> $DIR_log/$gene.msatreat.log 

    echo >&9 
    } & 
done
wait 

