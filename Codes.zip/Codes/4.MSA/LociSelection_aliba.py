#!/user/home/vn21703/anaconda3/bin/python3.9

import numpy as np
import pandas as pd
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--infile', '-i',
                    type=str,
                    help='Input file that should be separated by ",", and should be the output file of NMAlignTrim.sh or same formatted.')
parser.add_argument('--outfile', '-o',
                    type=str,
                    help='Output file that contains the full path of the selected loci only.')
args = parser.parse_args()

infile = args.infile.replace('\\','/')
outfile = args.outfile.replace('\\','/')
LociFilterMeasure=pd.read_table(infile, index_col=None, names=['fastapath', 'ngen', 'pis', 'tot', 'ppis', 'GC', 'RCV', 'erate'], sep=",", engine='python')
SelectedLociPath = LociFilterMeasure.loc[(LociFilterMeasure['ngen']>=np.quantile(LociFilterMeasure['ngen'],0.5)) & (LociFilterMeasure['pis']>=np.quantile(LociFilterMeasure['pis'],0.5)) & (LociFilterMeasure['tot']>=np.quantile(LociFilterMeasure['tot'],0.5)) & (LociFilterMeasure['RCV']<=np.quantile(LociFilterMeasure['RCV'],0.9)) & (LociFilterMeasure['erate']<=np.quantile(LociFilterMeasure['erate'],0.9)), 'fastapath']

SelectedLociPath.to_csv(outfile, index=False, header=False)

