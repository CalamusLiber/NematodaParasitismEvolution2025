#!/user/home/vn21703/anaconda3/bin/python3.9

import numpy as np
import pandas as pd
import os, re
from Bio import AlignIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Align import MultipleSeqAlignment
import matplotlib.pyplot as plt
from matplotlib import axis, gridspec as gs
import argparse

def DropSeq(alignpath, seqstodrop, exclude, outdir, mingenes=1):
    alignname = alignpath.split('/')[-1].split('.')[0]
    if outdir=='':
        outdir = alignpath.split(alignname)[0][:-1]
    Align = AlignIO.read(alignpath, 'fasta')
    seqstodrop = pd.concat([pd.Series(seqstodrop.loc[alignname, 'species']), exclude]) if alignname in seqstodrop.index else exclude
    Align = [seq for seq in Align if seq.id not in set(seqstodrop.values)]
    if len(Align) >= mingenes:
        Align = MultipleSeqAlignment(Align)
        AlignIO.write(Align, outdir + '/' + alignname + '.trbdp.rmsp.faa', 'fasta')
        return pd.Series([seq.seq for seq in Align], index=[seq.id for seq in Align], name=alignname)
    else:
        return pd.Series([], dtype=str)

def ReadSeq(alignpath, exclude, outdir, mingenes=1):
    alignname = alignpath.split('/')[-1].split('.')[0]
    Align = AlignIO.read(alignpath, 'fasta')
    Align = [seq for seq in Align if seq.id not in exclude.values]
    if len(Align) >= mingenes:
        Align = MultipleSeqAlignment(Align)
        AlignIO.write(Align, outdir + '/' + alignname + '.trbdp.faa', 'fasta')
        return pd.Series([seq.seq for seq in Align], index=[seq.id for seq in Align], name=alignname)
    else:
        return pd.Series([], dtype=str)

def ConcatFas2Phy(alignseries, outfile, partitionfile=True, returnaspyobj=True):
    lenlist = alignseries.apply(lambda x: len(x[0]))
    lenlist.sort_values(inplace=True, ascending=False)
    missingseq = lenlist.apply(lambda x: Seq('?' * x))
    alignseries = alignseries[lenlist.index]
    alignframe = pd.concat(alignseries.tolist(), axis=1, join='outer', ignore_index=False)
    for x in alignframe.columns:
        for y in alignframe.loc[alignframe.loc[:, x].isna(), x].index:
            alignframe.loc[y, x] = missingseq[x]
    alignframe.sort_index(axis=0,inplace=True)
    alignments = MultipleSeqAlignment(alignframe.apply(lambda x: SeqRecord(Seq(''.join([str(s) for s in x])), id=x.name), axis=1).tolist())
    AlignIO.write(alignments, outfile+'.phy', 'phylip-relaxed')
    AlignIO.write(alignments, outfile+'.faa', 'fasta')
    if partitionfile:
        xlength=pd.concat([pd.Series(0), lenlist]).cumsum()
        ptflines = ['  charset ' + xlength.index[i+1] + ' = ' + str(xlength.iloc[i]+1) + '-' + str(xlength.iloc[i+1]) + ';\n' for i in range(len(xlength)-1)]
        ptf = open(outfile+'.partition.nex', mode='w', newline='\n')
        ptf.write('#nexus\nbegin sets;\n')
        ptf.writelines(ptflines)
        ptf.write('end;\n')
        ptf.close()
    if returnaspyobj:
        totlen = sum(lenlist)
        totspp = alignframe.shape[0]
        alignlength = alignframe.applymap(lambda x: sum([p.isalnum() for p in x]))
        alignlengthout = alignlength.copy()
        alignlengthout.loc[:, 'Integrity(%,total='+str(totlen)+')'] = alignlength.apply(lambda x: round(sum(x) / totlen * 100, 2), axis=1)
        alignlengthout.loc[:, 'NumGenes'] = alignlength.apply(lambda x: sum([i > 0 for i in x]), axis=1)
        alignlengthout.loc['Integrity(%)', :] = round(alignlength.apply(lambda x: sum(x)/totspp, axis=0) / lenlist * 100, 2)
        alignlengthout.loc['MissingGenes', :] = alignlength.apply(lambda x: sum([i == 0 for i in x]), axis=0)
        return alignlengthout

def HeatMap(taxastat, outfile, dpi=300, nfsize=50, tickstep=10):
    ts_log = taxastat.iloc[:-2,:-2].apply(np.log).fillna(0)
    ts_bin = taxastat.iloc[:-2,:-2].applymap(lambda x: x > 0)
    xlabpos = np.arange(len(ts_log.columns), step=tickstep*3)
    ylabpos = np.arange(len(ts_log.index), step=tickstep)
    # plt.rc('xtick',labelsize=3)
    # plt.rc('ytick',labelsize=3)
    fig = plt.figure(figsize=(3*nfsize,2*nfsize)) # width, height
    gsp = gs.GridSpec(3, 1, height_ratios=[1, 1, 1])
    axes0 = plt.subplot(gsp[0])
    htp0 = axes0.imshow(ts_log, cmap=plt.cm.jet, aspect='auto')
    axes0.set_title('Log ungappy length of gene vs. taxon', fontdict={'fontsize':25})
    axes0.set_xticks([])
    axes0.set_yticks(ylabpos)
    axes0.set_yticklabels(labels=ts_log.index[ylabpos].tolist(), fontdict={'fontsize':3})
    axes0.set_ylabel('Taxon', fontdict={'fontsize':18})
    axes1 = plt.subplot(gsp[1])
    htp1 = axes1.imshow(ts_bin, cmap=plt.cm.gray, aspect='auto')
    axes1.set_title('Presence of gene vs. taxon', fontdict={'fontsize':25})
    axes1.set_xticks([])
    axes1.set_yticks(ylabpos)
    axes1.set_yticklabels(labels=ts_bin.index[ylabpos].tolist(), fontdict={'fontsize':3})
    axes1.set_ylabel('Taxon', fontdict={'fontsize':18})
    axes2 = plt.subplot(gsp[2])
    axes2.bar(taxastat.iloc[-1,2:].index, taxastat.iloc[-1,2:], width=1, color='orange')
    axes2.margins(x=0)
    axes2.set_xlabel('Trimmed Alignment of BUSCO Genes', fontdict={'fontsize':18})
    axes2.set_ylabel('Missing', fontdict={'fontsize':18})
    axes2.set_title('Count of missing genes', fontdict={'fontsize':25})
    axes2.set_xticks(xlabpos)
    axes2.set_xticklabels(labels=ts_bin.columns[xlabpos].tolist(), fontdict={'fontsize':3})
    plt.setp(axes2.get_xticklabels(), rotation=270)
    fig.tight_layout()
    plt.subplots_adjust(hspace=0.2)
    fig.savefig(outfile, dpi=dpi)
    # fig.show()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--alignmentmeasure', '-a',
                        type=str,
                        help='Input file that should be separated by ",", and should be the output file of NMAlignTrim.sh or same formatted. This file contains 8 columns of five assessment indeces that were calculated from genewise alignments.')
    parser.add_argument('--genetreemeasure', '-g',
                        type=str,
                        help='Input file that should be separated by ",", and should be the output file of NMFilterConcat.sh or same formatted. This file contains 6 columns of five assessment indeces that were calculated from gene trees.')
    parser.add_argument('--spurioushomolog', '-s',
                        type=str,
                        default='',
                        help='Input file that should be separated by ",", and should be the output file of NMFilterConcat.sh or same formatted. This file contains 5 columns of the names of gene trees and the "spurious homologs" found in those gene trees.')
    parser.add_argument('--outdir', '-o',
                        type=str,
                        default='./',
                        help='Output directory.')
    parser.add_argument('--exclude', '-e',
                        type=str,
                        default='',
                        help='Comma-separated list (no space break) of the taxa you want to be excluded from final dataset.')
    args = parser.parse_args()

    alignmentmeasure = args.alignmentmeasure.replace('\\','/')
    # symtest = args.symtest.replace('\\','/')
    genetreemeasure = args.genetreemeasure.replace('\\','/')
    outdir = args.outdir.replace('\\','/')
    curdir = os.getcwd().replace('\\','/')
    if not os.path.isabs(outdir):
        outdir = curdir + '/' + outdir.replace('./','')
    if not os.path.exists(outdir):
        os.makedirs(outdir, mode=0o777, exist_ok=True)  
    if args.exclude != '':
        excl = pd.Series(args.exclude.split(','), dtype=str)
    else:
        excl = pd.Series([], dtype=str)
    AlignmentMeasure = pd.read_table(alignmentmeasure, index_col=None, names=['fastapath', 'nGene', 'nPIS', 'TrimAlignLength', 'pPIS', 'GC', 'RCV', 'EvoRate'], sep=",", engine='python')
    AlignmentMeasure.index = AlignmentMeasure['fastapath'].apply(lambda x: x.split('/')[-1].split('.')[0])
    # SymTest = pd.read_table(symtest, index_col=None, skiprows=14, header=0, usecols=[0, 4], sep=",", engine='python')
    # SymTest.index = SymTest['Name'].apply(lambda x: x.split('.')[0])
    GenetreeMeasure = pd.read_table(genetreemeasure, index_col=None, names=['genetree', 'AvgBoots', 'Treeness', 'RCV', 'TOR', 'DVMC'], sep=",", engine='python')
    GenetreeMeasure.index = GenetreeMeasure['genetree'].apply(lambda x: x.split('/')[-1].split('.')[0])
    
    AdwiseLociMeasure = pd.concat([AlignmentMeasure, GenetreeMeasure], axis=1, join='inner', ignore_index=False)
    
    SelectedLoci = AdwiseLociMeasure.loc[(AdwiseLociMeasure['AvgBoots']>=np.quantile(AdwiseLociMeasure['AvgBoots'],0.1)) & (AdwiseLociMeasure['TOR']>=np.quantile(AdwiseLociMeasure['TOR'],0.1)) & (AdwiseLociMeasure['DVMC']<=np.quantile(AdwiseLociMeasure['DVMC'],0.9)), :].sort_index()
    # SelectedLoci = AdwiseLociMeasure.sort_index()
    SelectedLoci[['nGene', 'TrimAlignLength', 'nPIS', 'pPIS', 'RCV', 'EvoRate', 'AvgBoots', 'Treeness', 'TOR', 'DVMC']].to_excel(outdir + '/FinalSelectedGenes.xlsx')

    if args.spurioushomolog != '':
        spurioushomolog = args.spurioushomolog.replace('\\','/')
        if os.path.exists(spurioushomolog):
            SpuriousHomolog = pd.read_table(spurioushomolog, index_col=None, names=['genetree', 'species', 'termbranchlength', 'threshold', 'medianbranchlength'], sep=",", engine='python')
            SpuriousHomolog.index = SpuriousHomolog['genetree'].apply(lambda x: x.split('/')[-1].split('.')[0])
            dq = lambda x: DropSeq(x, SpuriousHomolog, exclude=excl, outdir=outdir, mingenes=1)
            AlignSeries = list(map(dq, SelectedLoci['fastapath']))
            AlignSeries = pd.Series(AlignSeries, index=[x.name for x in AlignSeries])
            AlignSeries = AlignSeries[AlignSeries.apply(len)>=10]
            AlignLength = ConcatFas2Phy(AlignSeries, outfile=outdir + '/ConcatenatedMatrix.rmsp', partitionfile=True, returnaspyobj=True)
            AlignLength.to_excel(outdir + '/MultipleSequenceAlignmentsLogLength.rmsp.xlsx')
            HeatMap(AlignLength, outfile=outdir+'/TaxaGeneIntegrity.rmsp.png', dpi=300, nfsize=30, tickstep=1)
    else:
        dq = lambda x: ReadSeq(x, exclude=excl, outdir=outdir, mingenes=1)
        AlignSeries = list(map(dq, SelectedLoci['fastapath']))
        AlignSeries = pd.Series(AlignSeries, index=[x.name for x in AlignSeries])
        AlignSeries = AlignSeries[AlignSeries.apply(len)>=10]
        AlignLength = ConcatFas2Phy(AlignSeries, outfile=outdir + '/ConcatenatedMatrix', partitionfile=True, returnaspyobj=True)
        AlignLength.to_excel(outdir + '/MultipleSequenceAlignmentsLogLength.xlsx')
        HeatMap(AlignLength, outfile=outdir + '/TaxaGeneIntegrity.png', dpi=300, nfsize=30, tickstep=1)
    

