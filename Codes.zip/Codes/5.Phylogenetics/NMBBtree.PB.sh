#!/bin/bash

module load apps/bmge/1.12/

cd /user/work/vn21703/nematoda/phylo/AllBackbone.nom.rmsp

BMGE=/sw/apps/BMGE-1.12/BMGE.jar

echo -e "=======================\nTrimming with BMGE (normal) start...\n$(date)\n=======================\n\n" >> BBmsa.bmge.log && 
java -Xmx90G -jar $BMGE -i ./ConcatenatedMatrix.rmsp.faa -t AA -m BLOSUM90 -h 0.4 -s NO -op ./ConcatenatedMatrix.rmsp.bmge.phy >> BBmsa.bmge.log 2>&1 && 
echo -e "=======================\nTrimming with BMGE (normal) accomplished.\n$(date)\n=======================\n\n" >> BBmsa.bmge.log

chmod -R 777 ./NMPB.x.sh

for run in {1..4} 
do 
    sbatch --partition=compute ./NMPB.x.sh $run 
done


