#!/bin/bash

NP=64 # 16
# NT=$[$SLURM_NNODES*$SLURM_NTASKS_PER_NODE] # 4

# module load apps/iqtree/2.1.3
# IQTREE=/sw/apps/iqtree-2.1.3-Linux/bin/iqtree2
IQTREE=/public4/home/sc56777/apps/iqtree2/bin/iqtree2

DIR_phylo=/public4/home/sc56777/Data/nmtd/phylo
# OutGroup=PF_Amphimedon_queenslandica

cd $DIR_phylo
Dataset=$(ls -d EcdyLoci*)

# for DS in $Dataset
# do    
#     # mixture model: guide tree
#     if [[ ! -f $DIR_phylo/$DS/Nema.$DS.C60.contree ]]; then 
#         (srun --job-name=NMIQTmix --exclusive --partition=amd_2T --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.rmsp.phy --seqtype AA -m C60+F+R --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --prefix $DIR_phylo/$DS/Nema.$DS.C60 &)
#     fi
# done 

# for DS in $Dataset
# do    
#     # mixture model: mixture site distribution profile
#     if [[ ! -f $DIR_phylo/$DS/Nema.$DS.C60.siteprof.sitefreq ]]; then 
#         (srun --job-name=NMIQTmix --exclusive --partition=amd_2T --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.rmsp.phy --seqtype AA -m LG+C60+FO+R -ft $DIR_phylo/$DS/Nema.$DS.C60.contree -n 0 -T $NP --prefix $DIR_phylo/$DS/Nema.$DS.C60.siteprof &)
#     fi
# done 

for DS in $Dataset
do    
    # mixture model: PMSF tree and bootstrap
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.C60.PMSF.contree ]]; then 
        (srun --job-name=NMIQTmix --exclusive --partition=amd_256 --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.rmsp.phy --seqtype AA -m LG+C60+FO+R -fs $DIR_phylo/$DS/Nema.$DS.C60.siteprof.sitefreq -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --prefix $DIR_phylo/$DS/Nema.$DS.C60.PMSF &)
    fi
done 
