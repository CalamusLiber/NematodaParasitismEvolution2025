#!/bin/bash
#SBATCH --job-name=NMPBmod
#SBATCH --partition=compute
#SBATCH --nodes=3
#SBATCH --ntasks-per-node=24
#SBATCH --mem=360GB
#SBATCH --account=gely025283

DIR=$(pwd)
NP=36
# DIR_cnd=/public1/home/scb4616/apps/anaconda3
DIR_cnd=/user/home/vn21703/anaconda3
# DIR_cnd=/usr/local/anaconda3 
PY_loocv=$DIR_cnd/pkgs/phylobayes-mpi-1.9-h5c6ebe3_0/scripts/read_loocv_waic.py 
PY=$DIR_cnd/bin/python3.9 
source $DIR_cnd/bin/activate phylobayes 
# conda activate phylobayes

cd $DIR/AllBackbone$1.nom.rmsp

nohup mpirun -np $NP pb_mpi CatGtrG4.chain1 & 
nohup mpirun -np $NP pb_mpi CatGtrG4.chain2 & 

wait 

# Leave-one-out cross-validation and the wAIC
tracecomp -x 1000 CatGtrG4.chain1 CatGtrG4.chain2 > CatGtrG4.tracecomp.log 2>&1 

nohup mpirun -np $NP readpb_mpi -x 1000 30 -sitelogl CatGtrG4.chain1 & 
nohup mpirun -np $NP readpb_mpi -x 1000 30 -sitelogl CatGtrG4.chain2 & 

wait 

$PY $PY_loocv $DIR/AllBackbone$1.nom.rmsp/CatGtrG4.chain?.sitelogl > $DIR/AllBackbone$1.nom.rmsp/AllBackbone$1.nom.rmsp.pb.CatGtrG4.loocv 2>&1 & 

# Posterior predictive model checking for adequacy (MCMC chains should be at stationarity)
wait 
cd $DIR/AllBackbone$1.nom.rmsp

mpirun -np $NP readpb_mpi -x 1000 30 -allppred CatGtrG4.chain1 

# wait
