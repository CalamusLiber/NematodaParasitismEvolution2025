#!/bin/bash

cd /user/work/vn21703/nematoda/phylo

chmod -R 777 ./NMPB.x.sh

for i in {1..4} 
do 
    sbatch --partition=compute ./NMPB.x.sh EcdyLoci.nom.rmsp $i 
done

