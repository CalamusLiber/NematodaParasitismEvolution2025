#!/bin/bash
#SBATCH --job-name=NMIQTREE
#SBATCH --exclusive
#SBATCH --partition=mwvdk
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --mem=350GB

NP=$SLURM_CPUS_PER_TASK # 32
NT=$[$SLURM_NNODES*$SLURM_NTASKS_PER_NODE] # 4

module load apps/iqtree/2.1.3
IQTREE=/sw/apps/iqtree-2.1.3-Linux/bin/iqtree2

DIR_matrix=$DIR_msa/matrix
DIR_phylo=/user/work/vn21703/nematoda/phylo
OutGroup=PF_Amphimedon_queenslandica

cd $DIR_phylo
Dataset=$(ls -d TBDL.*)

tmp_fifofile="/tmp/$$.fifo"
trap "exec 9>&-;exec 9<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile
for ((i=1;i<=$NT;i++))
do
    echo >&9
done

for DS in $Dataset
do 
    read -u9
    {

    echo -e "#######################\nBuilding Maximum Likelihood Phylogenetic Trees Using IQTREE2.1.3...\nDataset: $DS\n$(date)\n#######################\n\n" >> $DIR_phylo/$DS/TreeBuilding.log && 
   
    # partitioning
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.mp.contree ]]; then 
        echo -e "=======================\nMerged Partition start...\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log && 

        $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.phy --seqtype AA -p $DIR_phylo/$DS/ConcatenatedMatrix.partition.nex -m MF+MERGE --rclusterf 10 -rcluster-max 1000 --msub nuclear --mset LG --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP -o $OutGroup --prefix $DIR_phylo/$DS/Nema.$DS.mp && 

        echo -e "=======================\nMerged Partition finished.\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log 
    fi

    echo >&9 
    } & 
done
wait 

summarizeIQTREE(){
    local iqtreefile=$1 
    if [ ! -f ./sumIQTREE.csv ]; then
        echo "DataModel,nTaxa,nSites,nInvSites,pInvSites(%),nParsiInfSites,nDistSitePat,nPartitions,pMissingData(%),FreeRate(nCAT),LgLikMLTree,LgLikNoTree,LgLikConTree,RFDist,nParas,AIC,AICc,BIC,SumBrLen,SumIntNrLen,pIntNrLen(%)" > ./sumIQTREE.csv 
    fi
    local DM=$(echo $iqtreefile | sed -e "s/Nema.//g;s/.iqtree//g")
    if [[ $DM =~ '.fp' ]] || [[ $DM =~ '.mp' ]]; then 
        local L1=$(grep "Input data: " $iqtreefile)
        local nTaxa=$(echo $L1 | awk '{ print $3 }')
        local nSites=$(echo $L1 | awk '{ print $9 }')
        local nInvSites=""
        local pInvSites=""
        local nParsiInfSites=""
        local nDistSitePat=""
        local nPartitions=$(echo $L1 | awk '{ print $6 }')
        local pMissingData=$(echo $L1 | awk -F "[(%]" '{ print $2 }')
        local FreeRate=""
    else
        local L1=$(grep "Input data: " $iqtreefile)
        local nTaxa=$(echo $L1 | awk '{ print $3 }')
        local nSites=$(echo $L1 | awk '{ print $6 }')
        local L2=$(grep "Number of invariant (constant or ambiguous constant) sites: " $iqtreefile | sed -e "s/Number of invariant (constant or ambiguous constant) sites: //g;s/%//g")
        local nInvSites=$(echo $L2 | awk '{ print $1 }')
        local pInvSites=$(echo $L2 | awk '{ print $3 }')
        local nParsiInfSites=$(grep "Number of parsimony informative sites: " $iqtreefile | sed -e "s/Number of parsimony informative sites: //g")
        local nDistSitePat=$(grep "Number of distinct site patterns: " $iqtreefile | sed -e "s/Number of distinct site patterns: //g")
        local nPartitions=1
        local pMissingData=""
        local FreeRate=$(grep "Model of rate heterogeneity: FreeRate with " $iqtreefile | sed -e "s/Model of rate heterogeneity: FreeRate with //g" | awk '{ print $1 }')
    fi
    local LgLikMLTree=$(grep "Log-likelihood of the tree: " $iqtreefile | sed -e "s/Log-likelihood of the tree: //g" | awk '{ print $1 }')
    local LgLikNoTree=$(grep "Unconstrained log-likelihood (without tree): " $iqtreefile | sed -e "s/Unconstrained log-likelihood (without tree): //g")
    local LgLikConTree=$(grep "Log-likelihood of consensus tree: " $iqtreefile | sed -e "s/Log-likelihood of consensus tree: //g")
    local RFDist=$(grep "Robinson-Foulds distance between ML tree and consensus tree: " $iqtreefile | sed -e "s/Robinson-Foulds distance between ML tree and consensus tree: //g")
    local nParas=$(grep "Number of free parameters (#branches + #model parameters): " $iqtreefile | sed -e "s/Number of free parameters (#branches + #model parameters): //g")
    local AIC=$(grep "Akaike information criterion (AIC) score: " $iqtreefile | sed -e "s/Akaike information criterion (AIC) score: //g")
    local AICc=$(grep "Corrected Akaike information criterion (AICc) score: " $iqtreefile | sed -e "s/Corrected Akaike information criterion (AICc) score: //g")
    local BIC=$(grep "Bayesian information criterion (BIC) score: " $iqtreefile | sed -e "s/Bayesian information criterion (BIC) score: //g")
    local SumBrLen=$(grep "Total tree length (sum of branch lengths): " $iqtreefile | sed -e "s/Total tree length (sum of branch lengths): //g")
    local L3=$(grep "Sum of internal branch lengths: " $iqtreefile | sed -e "s/Sum of internal branch lengths: //g;s/% of tree length)//g")
    local SumIntNrLen=$(echo $L3 | awk '{ print $1 }')
    local pIntNrLen=$(echo $L3 | awk -F "(" '{ print $2 }')
    echo -e "$DM,$nTaxa,$nSites,$nInvSites,$pInvSites,$nParsiInfSites,$nDistSitePat,$nPartitions,$pMissingData,$FreeRate,$LgLikMLTree,$LgLikNoTree,$LgLikConTree,$RFDist,$nParas,$AIC,$AICc,$BIC,$SumBrLen,$SumIntNrLen,$pIntNrLen" >> ./sumIQTREE.csv 
}

cd $DIR_phylo/AllIqtreeFiles
IQT=$(ls Nema.*.iqtree)

for iqt in $IQT
do
    summarizeIQTREE $iqt
done
