#!/bin/bash
NP=24 # 24
# NT=$[$SLURM_NNODES*$SLURM_NTASKS_PER_NODE] # 4

module load apps/iqtree/2.1.3
IQTREE=/sw/apps/iqtree-2.1.3-Linux/bin/iqtree2

DIR_matrix=$DIR_msa/matrix
DIR_phylo=/user/work/vn21703/nematoda/phylo
# OutGroup=PF_Amphimedon_queenslandica

cd $DIR_phylo
Dataset=$(ls -d EcdyLoci.*)

for DS in $Dataset
do 

    # no partition
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.np.contree ]]; then 
        (srun --job-name=NMIQTREE --exclusive --partition=compute --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP --mem=180GB $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.phy --seqtype AA -m MFP --msub nuclear --mset LG --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --runs 4 --prefix $DIR_phylo/$DS/Nema.$DS.np &)
    fi

    # separated genes
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.fp.contree ]]; then 
        (srun --job-name=NMIQTREE --exclusive --partition=compute --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP --mem=180GB $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.phy --seqtype AA -p $DIR_phylo/$DS/ConcatenatedMatrix.partition.nex -m MFP --msub nuclear --mset LG --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --runs 4 --prefix $DIR_phylo/$DS/Nema.$DS.fp &)
    fi

    # partitioning
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.mp.contree ]]; then 
        (srun --job-name=NMIQTREE --exclusive --partition=compute --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP --mem=180GB $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.phy --seqtype AA -p $DIR_phylo/$DS/ConcatenatedMatrix.partition.nex -m MFP --merge --rclusterf 10 --msub nuclear --mset LG --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --runs 4 --prefix $DIR_phylo/$DS/Nema.$DS.mp &)
    fi
done

