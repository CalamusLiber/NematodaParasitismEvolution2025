#!/bin/bash
#SBATCH --job-name=NMIQTREE
#SBATCH --exclusive
#SBATCH --partition=mwvdk
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --mem=350GB

NP=$SLURM_CPUS_PER_TASK # 32
NT=$[$SLURM_NNODES*$SLURM_NTASKS_PER_NODE] # 4

module load apps/iqtree/2.1.3
IQTREE=/sw/apps/iqtree-2.1.3-Linux/bin/iqtree2

DIR_matrix=$DIR_msa/matrix
DIR_phylo=/user/work/vn21703/nematoda/phylo
OutGroup=PF_Amphimedon_queenslandica

cd $DIR_phylo
Dataset=$(ls -d TBDL.*)

tmp_fifofile="/tmp/$$.fifo"
trap "exec 9>&-;exec 9<&-;exit 0" 2
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile
for ((i=1;i<=$NT;i++))
do
    echo >&9
done

for DS in $Dataset
do 
    read -u9
    {

    echo -e "#######################\nBuilding Maximum Likelihood Phylogenetic Trees Using IQTREE2.1.3...\nDataset: $DS\n$(date)\n#######################\n\n" >> $DIR_phylo/$DS/TreeBuilding.log && 
    # no partition
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.np.contree ]]; then 
        echo -e "=======================\nNo Partition start...\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log && 

        $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.phy --seqtype AA -m MFP --msub nuclear --mset LG,WAG --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --runs 4 -o $OutGroup --prefix $DIR_phylo/$DS/Nema.$DS.np && 

        echo -e "=======================\nNo Partition finished.\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log 
    fi
    
    # partitioning
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.mp.contree ]]; then 
        echo -e "=======================\nMerged Partition start...\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log && 

        $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.phy --seqtype AA -p $DIR_phylo/$DS/ConcatenatedMatrix.partition.nex -m MFP --merge --rclusterf 10 --msub nuclear --mset LG,WAG --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --runs 4 -o $OutGroup --prefix $DIR_phylo/$DS/Nema.$DS.mp && 

        echo -e "=======================\nMerged Partition finished.\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log 
    fi

    # separated genes
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.fp.contree ]]; then 
        echo -e "=======================\nFully-separated Partition start...\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log && 

        $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.phy --seqtype AA -p $DIR_phylo/$DS/ConcatenatedMatrix.partition.nex -m MFP+MERGE --msub nuclear --mset LG,WAG --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --runs 4 -o $OutGroup --prefix $DIR_phylo/$DS/Nema.$DS.fp && 

        echo -e "=======================\nFully-separated Partition finished.\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log 
    fi

    echo >&9 
    } & 
done
wait 

for DS in $Dataset
do 
   
    # mixture model
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.mx.contree ]]; then 
        echo -e "=======================\nMixture Models start...\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log && 

        $IQTREE -s $DIR_phylo/$DS/ConcatenatedMatrix.phy --seqtype AA -m MFP --msub nuclear --mset C20,C60,EX2,EX3,EHO,UL2,UL3,EX_EHO,LG4M,LG4X --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $[$NP*$NT/2] --runs 4 -o $OutGroup --prefix $DIR_phylo/$DS/Nema.$DS.mx && 

        echo -e "=======================\nMixture Partition finished.\n$(date)\n=======================\n\n" >> $DIR_phylo/$DS/TreeBuilding.log && 

        echo -e "#######################\nTree Building Accomplished\n$(date)\n#######################\n\n" >> $DIR_phylo/$DS/TreeBuilding.log 
    fi

done 
