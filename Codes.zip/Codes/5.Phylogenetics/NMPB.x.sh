#!/bin/bash
#SBATCH --job-name=NMPB
#SBATCH --nodes=1
#SBATCH --ntasks=24
#SBATCH --mem=180GB
#SBATCH --exclusive

DIR_cnd=/user/home/vn21703/anaconda3

module load apps/phylobayes/mpi.1.8 
# module load apps/phylobayes/mpi-ncat
# module load lib/openmpi/4.0.2-gcc.4.8.5 
source $DIR_cnd/bin/activate $DIR_cnd/envs/makerenv

mpirun -np $SLURM_NTASKS pb_mpi -d ./ConcatenatedMatrix.rmsp.bmge.phy -cat -gtr -dgam 4 -x 2 10000 AllBackbone.nom.rmsp.pb.chain$1 

# mpirun -np $SLURM_NTASKS pb_mpi AllBackbone.nom.rmsp.pb.chain$1 

#bpcomp -x 500 2 chain2 chain3 > bpcomp.log
#tracecomp -x 500 4 chain2 chain3 > tracecomp.log
