#!/bin/bash

NP=64 # 16
# NT=$[$SLURM_NNODES*$SLURM_NTASKS_PER_NODE] # 4

# module load apps/iqtree/2.1.3
# IQTREE=/sw/apps/iqtree-2.1.3-Linux/bin/iqtree2
IQTREE=/public4/home/sc56777/apps/iqtree2/bin/iqtree2

DIR_phylo=/public4/home/sc56777/Data/nmtd/TBDL.nom.rmsp
# OutGroup=PF_Amphimedon_queenslandica

cd $DIR_phylo
DS=TBDL.nom.rmsp

    # mixture model: guide tree
        (srun --job-name=NMIQTmix --exclusive --partition=amd_2T --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP $IQTREE -s $DIR_phylo/ConcatenatedMatrix.phy --seqtype AA -m C60+FO+R --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --runs 4 --prefix $DIR_phylo/Nema.$DS.C60 &) 

    # mixture model: mixture site distribution profile
#        (srun --job-name=NMIQTmix --exclusive --partition=amd_2T --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP $IQTREE -s $DIR_phylo/ConcatenatedMatrix.phy --seqtype AA -m LG+C60+FO+R -ft $DIR_phylo/Nema.$DS.C60.treefile -n 0 -T $NP --runs 4 --prefix $DIR_phylo/Nema.$DS.C60.siteprof > $DIR_phylo/Nema.$DS.C60.siteprof.full.log 2>&1 &) 

    # mixture model: PMSF tree and bootstrap
#        (srun --job-name=NMIQTmix --exclusive --partition=amd_256 --nodes=1 --ntasks-per-node=1 --cpus-per-task=$NP $IQTREE -s $DIR_phylo/ConcatenatedMatrix.phy --seqtype AA -m LG+C60+FO+R -fs $DIR_phylo/Nema.$DS.C60.siteprof.sitefreq -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T $NP --prefix $DIR_phylo/Nema.$DS.C60.PMSF > $DIR_phylo/Nema.$DS.C60.PMSF.full.log 2>&1 &)

