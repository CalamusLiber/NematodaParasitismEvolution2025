#!/bin/bash
NP=54 # 54
# NT=$[$SLURM_NNODES*$SLURM_NTASKS_PER_NODE] # 4

IQTREE=/apps/iqtree2/bin/iqtree2

DIR_phylo=/mnt/data/TBDL.nom.rmsp
# OutGroup=PF_Amphimedon_queenslandica

cd $DIR_phylo
Dataset=Nema.TBDL.nom.rmsp.mp.5p

# Multithread preparation
tmp_fifofile="/tmp/$$.fifo" 
trap "exec 9>&-;exec 9<&-;exit 0" 2 
mkfifo $tmp_fifofile
exec 9<>$tmp_fifofile 
rm $tmp_fifofile

for ((i=1;i<=5;i++))
do
    echo >&9
done

for Pt in {1..5} 
do 
    read -u9
    {

    # partitioning
    if [[ ! -f $DIR_phylo/$DS/Nema.$DS.mp.contree ]]; then 
        $IQTREE -s $Dataset$Pt.faa -m MFP --msub nuclear --mset LG,WAG --rate --mlrate -B 1000 --wbtl --alrt 1000 --abayes --lbp 1000 -T 10 --runs 4 --prefix $Dataset$Pt 
    fi

    echo >&9 
    } & 

done
wait

