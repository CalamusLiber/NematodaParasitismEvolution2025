## Loading libraries----
library(mvnormtest);library(biotools);library(car)
library(rrr);library(rrpack);library(VGAM);library(brglm)

## Factors that determine the time estimation (reduced-rank regression)----
# BrTimePC123 <- pca_res$x[,1:3]
dfBrTimeMCMC <- cbind(as.data.frame(BrTime), mcmc)





set.seed(20230826)
# trains <- createDataPartition(y=dfBrTimeMCMC[,1:184], p=0.75, list = F)
trains <- sample(1:nrow(dfBrTimeMCMC), ceiling(nrow(dfBrTimeMCMC) * 0.75))
TrainDataX <- dfBrTimeMCMC[trains,-1:-184]
TrainDataY <- as.data.frame(dfBrTimeMCMC[trains,1:184])
TestDataX <- dfBrTimeMCMC[-trains,-1:-184]
TestDataY <- dfBrTimeMCMC[-trains,1:184]

form_reg <- as.formula(paste(paste(colnames(TrainDataY), collapse = '+'), '~', paste(colnames(TrainDataX), collapse = '+')))

fit_rf_reg <- cforest(form_reg, data = dfBrTimeMCMC[trains,], ntree= 1000, cores = 8, mtry = 6, importance=T)

future::plan(multisession, workers = 8)
mod <- Predictor$new(fit_rf_reg, data=TrainDataX, y= TrainDataY)
imp <- FeatureImp$new(mod, loss = "mae", compare = "difference")
plot(imp)
