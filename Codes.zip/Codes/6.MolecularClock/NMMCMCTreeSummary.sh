#!/bin/bash

DIR_rt=$(pwd)

Topo=$(echo $(pwd) | awk -v FS='/' '{print $NF}' | awk -v FS='.BD' '{print $1}')
TreeCalibration=$(ls *.tre | sed "s#\/##g;s#Nema.${Topo}.##g;s#.tre##g")
ClockModel='IR AR'
Partition='1P 5P'
rgene_gamma='15 20 25'

# Run SumMCMCtree.py
for TreCali in $TreeCalibration
do 
    for Part in $Partition 
    do
        for Clock in $ClockModel
        do 
            for Rgene in $rgene_gamma
            do 
                DIR_cur=$DIR_rt/${TreCali}.${Part}.${Clock}.rg${Rgene}
                cd $DIR_cur
                if [ $(find . -type f -name "*MCMCtree_final_report.txt" | wc -l) -lt 1 -a $(find . -type f -name FigTree.tre | wc -l) -eq 8 -a $(find . -type f -name mcmc.txt | wc -l) -eq 8 ] 
                then 
                    cp /user/work/vn21703/nematoda/SumMCMCtree.py . 
                    chmod -R 777 ./SumMCMCtree.py 
                    px=$(echo $DIR_cur | sed -s 's#/user/work/vn21703/nematoda/#NMtimetree_#g;s#\/#.#g') 
                    sbatch ./SumMCMCtree.py --postdir $DIR_cur/DIR_DIV --priodir $DIR_cur/DIR_PRD --classification /user/work/vn21703/nematoda/Classification.xlsx --tipcolor /user/work/vn21703/nematoda/tipcolors.xlsx --prefix $px --burnin 50000 --select_chains --good_ess 50 --rm_mcmc none 
                fi 
            done
        done
    done
done

