## Best time estimation based on density classification----
# Loading libraries----
library(ape)
library(ggtree);library(ggplot2);library(ggalt);library(patchwork)
library(treeio);library(pracma)
library(fpc);library(factoextra);library(dbscan);library(Rtsne)
library(torch);library(brulee)
library(doParallel)

options(max.print = 8000 )

setwd('/mnt/hdd2/Nematoda/timing/20241203/Res_posttrees')

## PCA of Branching times----
pca_res <- prcomp(BrTime[mcmc$cvg=='G', -1], center = T, scale. = T)
pca_res.sum <- summary(pca_res)
# Importance of components:
#                            PC1    PC2     PC3     PC4     PC5     PC6     PC7     PC8    PC9    PC10    PC11    PC12    PC13
# Standard deviation     12.0560 4.6257 3.1611 1.19905 1.13285 1.04839 0.85478 0.65689 0.50393 0.47992 0.40032 0.33483 0.30956
# Proportion of Variance  0.7943 0.1169 0.0546 0.00786 0.00701 0.00601 0.00399 0.00236 0.00139 0.00126 0.00088 0.00061 0.00052
# Cumulative Proportion   0.7943 0.9112 0.9658 0.97363 0.98064 0.98665 0.99064 0.99300 0.99439 0.99565 0.99652 0.99713 0.99766

# Grouping by HDBSCAN method (Campello et al., 2013)----
# Using the first 3 PCs
BrTimePC1to3 <- pca_res$x[, 1:3]

# Fixing minPts = 2 * dim(dataset) = 6 (Sander et al., 1998)
# Calculating and plotting k-Nearest Neighbor Distances by fixing k = minPts - 1 = 5
findKnee <- function(Cv, method='maxPerpend'){
    if (method=='maxPerpend'){ # it is actually to maximize the parallelepiped areas instead of the perpendicular lines.
        CvVect1 <- rbind(Cv[,1]-Cv,0)
        CvVect2 <- rbind(Cv[,ncol(Cv)]-Cv,0)
        crsprod <- pracma::cross(CvVect1,CvVect2)
        knee_id <- which.max(apply(crsprod, 2, FUN = function(x){sqrt(sum(x^2))}))
        return(c(knee_id, Cv[2,knee_id]))
    }else if (method=='paraTangent'){
        CvTan <- c(diff(Cv[2,], lag=1)/diff(Cv[1,], lag=1), Inf)
        blTan <- (Cv[2,ncol(Cv)]-Cv[2,1])/(Cv[1,ncol(Cv)]-Cv[1,1])
        knee_id <- which.min(abs(CvTan-blTan))
        return(c(knee_id, Cv[2,knee_id]))
    }
}

knn <- sort(kNNdist(dist(BrTimePC1to3, 'euclidean'), k=2 * ncol(BrTimePC1to3) - 1))
eps_opt_id <- findKnee(Cv=rbind(point=1:length(knn),knn), method='maxPerpend')[1]
eps_opt_pca <- knn[eps_opt_id]

svg(filename = 'k-Nearest Neighbor Distances plot for PCA-DBSCAN.svg', width = 8, height = 6, bg = 'white', pointsize = 12)
kNNdistplot(dist(BrTimePC1to3, 'euclidean'), k=2 * ncol(BrTimePC1to3) - 1, minPts = 2 * ncol(BrTimePC1to3))
lines(cbind(c(1,length(knn)),knn[c(1,length(knn))]), lty = 'dotted', lwd=2, col = 'blue')
abline(h=eps_opt_pca, col='red', lty = 'dashed')
abline(v=eps_opt_id, col='red', lty = 'dashed')
points(x=eps_opt_id, y=eps_opt_pca, col='red', pch=16)
title('k-Nearest Neighbor Distances Plot for PCA-DBSCAN')
dev.off()

# PCA-DBSCAN-clustering using optimal epsilon----
pca_db <- dbscan::dbscan(dist(BrTimePC1to3, 'euclidean'), minPts = 2 * ncol(BrTimePC1to3), eps = eps_opt_pca)
# pca_db <- dbscan::hdbscan(dist(BrTimePC1to3, 'euclidean'), minPts = 2 * ncol(BrTimePC1to3), gen_hdbscan_tree = TRUE)
# class(pca_db) <- 'dbscan'

svg(filename = 'DBSCAN-clustering using PCA-axes 1-3 (shown on axis 1-2).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(pca_db, BrTimePC1to3[,c(1,2)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, geom = 'point', main = 'DBSCAN-clustering using PCA-axes 1:3 (shown on axis 1 & 2)')
dev.off()
svg(filename = 'DBSCAN-clustering using PCA-axes 1-3 (shown on axis 1-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(pca_db, BrTimePC1to3[,c(1,3)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, geom = 'point', main = 'DBSCAN-clustering using PCA-axes 1:3 (shown on axis 1 & 3)')
dev.off()
svg(filename = 'DBSCAN-clustering using PCA-axes 1-3 (shown on axis 2-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(pca_db, BrTimePC1to3[,c(2,3)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, geom = 'point', main = 'DBSCAN-clustering using PCA-axes 1:3 (shown on axis 2 & 3)')
dev.off()

pca_group <- rep(-1, nrow(mcmc))
pca_group[mcmc$cvg=='G'] <- pca_db$cluster
pca_table <- addmargins(table(pca_group, mcmc$cst, mcmc$fp, mcmc$part, mcmc$corr, dnn = c('group', 'cst', 'fp', 'part', 'corr')))

sink('FreqTables.PCA-DBSCAN.txt')
cat('====PCA-DBSCAN parameters====\n')
pca_db

cat('\n====PCA grouping vs. Calibration Strategy vs. Calibration Coverage====\n')
pca_table

cat('\n====BirthDeath vs. RgeneRate vs. Convergence====\n')
addmargins(table(mcmc$sf, mcmc$rg, mcmc$cvg, dnn = c('sf', 'rg', 'cvg')))

cat('\n====Calibration Strategy vs. Calibration Coverage vs. Convergence====\n')
addmargins(table(mcmc$cst, mcmc$fp, mcmc$cvg, dnn = c('cst', 'fp', 'cvg')))

cat('\n====Data Partition vs. Clock Model vs. Convergence====\n')
addmargins(table(mcmc$part, mcmc$corr, mcmc$cvg, dnn = c('part', 'corr', 'cvg')))
sink()

# t-SNE of Branching times----
tsne_res <- Rtsne(BrTime[mcmc$cvg=='G', -1], dims = 3, theta = 0, pca = TRUE, pca_center = TRUE, pca_scale = TRUE)
tsne_res.sum <- summary(tsne_res)
BrTimeTSNE3d <- tsne_res$Y
colnames(BrTimeTSNE3d) <- c('tSNE1', 'tSNE2', 'tSNE3')

knn <- sort(kNNdist(dist(BrTimeTSNE3d, 'euclidean'), k=2 * ncol(BrTimeTSNE3d) - 1))
eps_opt_id <- findKnee(Cv=rbind(point=1:length(knn),knn), method='maxPerpend')[1]
eps_opt_tsne <- knn[eps_opt_id]

svg(filename = 'k-Nearest Neighbor Distances plot for tSNE-DBSCAN.svg', width = 8, height = 6, bg = 'white', pointsize = 12)
kNNdistplot(dist(BrTimeTSNE3d, 'euclidean'), k=2 * ncol(BrTimeTSNE3d) - 1, minPts = 2 * ncol(BrTimeTSNE3d))
lines(cbind(c(1,length(knn)),knn[c(1,length(knn))]), lty = 'dotted', lwd=2, col = 'blue')
abline(h=eps_opt_tsne, col='red', lty = 'dashed')
abline(v=eps_opt_id, col='red', lty = 'dashed')
points(x=eps_opt_id, y=eps_opt_tsne, col='red', pch=16)
title('k-Nearest Neighbor Distances Plot for tSNE-DBSCAN')
dev.off()

## tSNE-DBSCAN-clustering using optimal epsilon----
tsne_db <- dbscan::dbscan(dist(BrTimeTSNE3d, 'euclidean'), minPts = 2 * ncol(BrTimeTSNE3d), eps = eps_opt_tsne)
# tsne_db <- dbscan::hdbscan(dist(BrTimePC1to3, 'euclidean'), minPts = 2 * ncol(BrTimeTSNE3d), gen_hdbscan_tree = TRUE)
# class(tsne_db) <- 'dbscan'

# exchange the positions of cluster 2 and 5 for making bueatiful graph
# tsne_db$cluster[tsne_db$cluster==2] <- -1
# tsne_db$cluster[tsne_db$cluster==5] <- 2
# tsne_db$cluster[tsne_db$cluster==-1] <- 5

svg(filename = 'DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 1-2).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(tsne_db, BrTimeTSNE3d[,c(1,2)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-8, 10), ylim=c(-6, 6), geom = 'point', main = 'DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 1 & 2)')
dev.off()
svg(filename = 'DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 1-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(tsne_db, BrTimeTSNE3d[,c(1,3)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-8, 10), ylim=c(-6, 8), geom = 'point', main = 'DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 1 & 3)')
dev.off()
svg(filename = 'DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 2-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(tsne_db, BrTimeTSNE3d[,c(2,3)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-6, 6), ylim=c(-6, 8), geom = 'point', main = 'DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 2 & 3)')
dev.off()

tsne_group <- rep(-1, nrow(mcmc))
tsne_group[mcmc$cvg=='G'] <- tsne_db$cluster
tsne_table <- addmargins(table(tsne_group, mcmc$cst, mcmc$fp, mcmc$part, mcmc$corr, dnn = c('group', 'cst', 'fp', 'part', 'corr')))

sink('FreqTables.tSNE-DBSCAN.txt')
cat('====tSNE-DBSCAN parameters====\n')
tsne_db

cat('\n====tSNE grouping vs. Calibration Strategy vs. Calibration Coverage====\n')
tsne_table

cat('\n====BirthDeath vs. RgeneRate vs. Convergence====\n')
addmargins(table(mcmc$sf, mcmc$rg, mcmc$cvg, dnn = c('sf', 'rg', 'cvg')))

cat('\n====Calibration Strategy vs. Calibration Coverage vs. Convergence====\n')
addmargins(table(mcmc$cst, mcmc$fp, mcmc$cvg, dnn = c('cst', 'fp', 'cvg')))

cat('\n====Data Partition vs. Clock Model vs. Convergence====\n')
addmargins(table(mcmc$part, mcmc$corr, mcmc$cvg, dnn = c('part', 'corr', 'cvg')))
sink()

## DBSCAN-clustering using customized range distance matrix between paired matrices----
RangeDist <- function(mat1, mat2, w=1, dtype='t', byrow=TRUE){
    if (! byrow){
        mat1 <- t(mat1)
        mat2 <- t(mat2)
    }
    mat1 <- apply(mat1, 2, sort)
    mat2 <- apply(mat2, 2, sort)
    if (length(mat1)==3){
        mat1[3,] <- apply(mat1, 2, function(x){x[3]*diff(x)[1]/diff(x)[2]})
        mat2[3,] <- apply(mat2, 2, function(x){x[3]*diff(x)[1]/diff(x)[2]})
        mat1 <- mat1[-2,]
        mat2 <- mat2[-2,]
    }
    if (length(w)==ncol(mat1)){
        w <- w
    }else if (length(w)==1){
        w <- rep(w, ncol(mat1))
    }else{
        break
    }
    if (dtype=='t'){
        d <- abs(mat1[2,] - mat2[2,]) + abs(mat1[1,] - mat2[1,])
    }else if (dtype=='r'){
        d <- abs(mat1[2,] - mat2[1,]) / abs(mat1[1,] - mat2[2,])
        d[d<1] <- 1 / d[d<1]
    }else{
        break
    }
    return(sum(d * w)/sum(w))
}

nodewight <- unlist(lapply(subtrees(AllTrees[[1]]@phylo),Nnode))[-1]/unlist(lapply(subtrees(AllTrees[[1]]@phylo),Nnode))[1]

TreeDistMatrix <- matrix(NA, nrow = length(TimeRange3[mcmc$cvg=='G']), ncol = length(TimeRange3[mcmc$cvg=='G']))

GoodTimeRange3 <- TimeRange3[mcmc$cvg=='G']

cl <- makeCluster(detectCores())
registerDoParallel(cl)

TreeDistMatrix <- foreach (i = 1:length(GoodTimeRange3), .combine = rbind) %dopar% {
    Reduce(c, lapply(GoodTimeRange3, function(x){RangeDist(GoodTimeRange3[[i]], x, w=nodewight, dtype = 't')}))
}

stopCluster(cl)

knn <- sort(kNNdist(TreeDistMatrix, k=2 * 3 - 1))
eps_opt_id <- findKnee(Cv=rbind(point=1:length(knn),knn), method='maxPerpend')[1]
eps_opt_prd <- knn[eps_opt_id]

svg(filename = 'k-Nearest Neighbor Distances plot for PRD-DBSCAN.svg', width = 8, height = 6, bg = 'white', pointsize = 12)
kNNdistplot(TreeDistMatrix, k=2 * 3 - 1, minPts = 2 * 3)
lines(cbind(c(1,length(knn)),knn[c(1,length(knn))]), lty = 'dotted', lwd=2, col = 'blue')
abline(h=eps_opt_prd, col='red', lty = 'dashed')
abline(v=eps_opt_id, col='red', lty = 'dashed')
points(x=eps_opt_id, y=eps_opt_prd, col='red', pch=16)
title('k-Nearest Neighbor Distances Plot for PRD-DBSCAN')
dev.off()

## PRD-DBSCAN-clustering using optimal epsilon----
prd_db <- dbscan::dbscan(TreeDistMatrix, minPts = 2 * 3, eps = eps_opt_prd)

svg(filename = 'PRD-DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 1-2).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(prd_db, BrTimeTSNE3d[,c(1,2)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-8, 10), ylim=c(-6, 6), geom = 'point', main = 'PRD-DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 1 & 2)')
dev.off()
svg(filename = 'PRD-DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 1-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(prd_db, BrTimeTSNE3d[,c(1,3)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-8, 10), ylim=c(-6, 8), geom = 'point', main = 'PRD-DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 1 & 3)')
dev.off()
svg(filename = 'PRD-DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 2-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(prd_db, BrTimeTSNE3d[,c(2,3)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-6, 6), ylim=c(-6, 8), geom = 'point', main = 'PRD-DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 2 & 3)')
dev.off()

prd_group <- rep(-1, nrow(mcmc))
prd_group[mcmc$cvg=='G'] <- prd_db$cluster
prd_table <- addmargins(table(prd_group, mcmc$cst, mcmc$fp, mcmc$part, mcmc$corr, dnn = c('group', 'cst', 'fp', 'part', 'corr')))

sink('FreqTables.PRD-DBSCAN.txt')
cat('====PRD-DBSCAN parameters====\n')
prd_db

cat('\n====PRD grouping vs. Calibration Strategy vs. Calibration Coverage====\n')
prd_table

cat('\n====BirthDeath vs. RgeneRate vs. Convergence====\n')
addmargins(table(mcmc$sf, mcmc$rg, mcmc$cvg, dnn = c('sf', 'rg', 'cvg')))

cat('\n====Calibration Strategy vs. Calibration Coverage vs. Convergence====\n')
addmargins(table(mcmc$cst, mcmc$fp, mcmc$cvg, dnn = c('cst', 'fp', 'cvg')))

cat('\n====Data Partition vs. Clock Model vs. Convergence====\n')
addmargins(table(mcmc$part, mcmc$corr, mcmc$cvg, dnn = c('part', 'corr', 'cvg')))
sink()

## DBSCAN-clustering using AutoEncoder clustering (AEC) with 95HPD distance matrix----
MatEncoder <- function(mat, outdim=1, epochs=50){
    torch_manual_seed('20250410')
    # 转换为 torch 张量
    data <- torch_tensor(mat, dtype = torch_float())
    # 定义自动编码器模型
    autoencoder <- nn_module(
        initialize = function() {
            self$encoder <- nn_sequential(
                nn_linear(ncol(mat), outdim),  # 压缩到1维
                nn_relu()
            )
            self$decoder <- nn_sequential(
                nn_linear(outdim, ncol(mat)),  # 恢复到原始维度
                nn_sigmoid()
            )
        },
        forward = function(x) {
            encoded <- self$encoder(x)  # 编码
            decoded <- self$decoder(encoded)  # 解码
            list(encoded, decoded)  # 返回编码和解码结果
        }
    )
    # 创建模型实例
    model <- autoencoder()
    # 定义损失函数和优化器
    criterion <- nn_mse_loss()  # 使用均方误差损失
    optimizer <- optim_adam(model$parameters, lr = 0.01)
    # 训练模型
    batch_size <- 1
    num_batches <- nrow(data) / batch_size
    cat('\n==== AutoEncoder Training ====\n')
    for (epoch in 1:epochs) {
        model$train()
        total_loss <- 0
        for (i in seq(1, nrow(data), by = batch_size)) {
            batch <- data[i:(i + batch_size - 1), ]
            optimizer$zero_grad()
            outputs <- model(batch)
            encoded <- outputs[[1]]  # 提取潜在特征
            decoded <- outputs[[2]]
            loss <- criterion(decoded, batch)
            loss$backward()
            optimizer$step()
            total_loss <- total_loss + loss$item()
        }
        cat(sprintf("Epoch %d, Loss: %.4f\n", epoch, total_loss / num_batches))
    }
    # 使用编码器提取潜在特征
    # model$eval()
    return(as.numeric(model$encoder(data)))
}

sink('AutoEncoder-training.log')
aec_res <- Reduce(rbind, lapply(GoodTimeRange3, MatEncoder, epochs=200))
sink()

colnames(aec_res) <- c('AEC1', 'AEC2', 'AEC3')

# rm(GoodTimeRange3)

knn <- sort(kNNdist(dist(aec_res, 'euclidean'), k=2 * ncol(aec_res) - 1))
eps_opt_id <- findKnee(Cv=rbind(point=1:length(knn),knn), method='maxPerpend')[1]
eps_opt_aec <- knn[eps_opt_id]

svg(filename = 'k-Nearest Neighbor Distances plot for AEC-DBSCAN.svg', width = 8, height = 6, bg = 'white', pointsize = 12)
kNNdistplot(dist(aec_res, 'euclidean'), k=2 * ncol(aec_res) - 1, minPts = 2 * ncol(aec_res))
lines(cbind(c(1,length(knn)),knn[c(1,length(knn))]), lty = 'dotted', lwd=2, col = 'blue')
abline(h=eps_opt_aec, col='red', lty = 'dashed')
abline(v=eps_opt_id, col='red', lty = 'dashed')
points(x=eps_opt_id, y=eps_opt_aec, col='red', pch=16)
title('k-Nearest Neighbor Distances Plot for AEC-DBSCAN')
dev.off()

## AEC-DBSCAN-clustering using optimal epsilon----
aec_db <- dbscan::dbscan(dist(aec_res, 'euclidean'), minPts = 2 * ncol(aec_res), eps = eps_opt_aec)

svg(filename = 'AEC-DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 1-2).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(aec_db, BrTimeTSNE3d[,c(1,2)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-8, 10), ylim=c(-6, 6), geom = 'point', main = 'AEC-DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 1 & 2)')
dev.off()
svg(filename = 'AEC-DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 1-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(aec_db, BrTimeTSNE3d[,c(1,3)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-8, 10), ylim=c(-6, 8), geom = 'point', main = 'AEC-DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 1 & 3)')
dev.off()
svg(filename = 'AEC-DBSCAN-clustering using tSNE-axes 1-3 (shown on axis 2-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(aec_db, BrTimeTSNE3d[,c(2,3)], show.clust.cent = F, stand = F, ellipse = T, ellipse.type = 'norm', labelsize = 2, shape=16, xlim=c(-6, 6), ylim=c(-6, 8), geom = 'point', main = 'AEC-DBSCAN-clustering using tSNE-axes 1:3 (shown on axis 2 & 3)')
dev.off()

svg(filename = 'DBSCAN-clustering using logAEC-axes 1-3 (shown on axis 1-2).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(aec_db, log(aec_res[,c(1,2)]), show.clust.cent = F, stand = F, ellipse = T, labelsize = 2, ellipse.type = 'norm', shape=16, geom = 'point', main = 'DBSCAN-clustering using AEC-axes 1:3 (shown on axis 1 & 2)')
dev.off()
svg(filename = 'DBSCAN-clustering using logAEC-axes 1-3 (shown on axis 1-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(aec_db, log(aec_res[,c(1,3)]), show.clust.cent = F, stand = F, ellipse = T, labelsize = 2, ellipse.type = 'norm', shape=16, geom = 'point', main = 'DBSCAN-clustering using AEC-axes 1:3 (shown on axis 1 & 3)')
dev.off()
svg(filename = 'DBSCAN-clustering using logAEC-axes 1-3 (shown on axis 2-3).svg', width = 8, height = 6, bg = 'white', pointsize = 12)
fviz_cluster(aec_db, log(aec_res[,c(2,3)]), show.clust.cent = F, stand = F, ellipse = T, labelsize = 2, ellipse.type = 'norm', shape=16, geom = 'point', main = 'DBSCAN-clustering using AEC-axes 1:3 (shown on axis 2 & 3)')
dev.off()

aec_group <- rep(-1, nrow(mcmc))
aec_group[mcmc$cvg=='G'] <- aec_db$cluster
aec_table <- addmargins(table(aec_group, mcmc$cst, mcmc$fp, mcmc$part, mcmc$corr, dnn = c('group', 'cst', 'fp', 'part', 'corr')))

sink('FreqTables.AEC-DBSCAN.txt')
cat('====AEC-DBSCAN parameters====\n')
aec_db

cat('\n====AEC grouping vs. Calibration Strategy vs. Calibration Coverage====\n')
aec_table

cat('\n====BirthDeath vs. RgeneRate vs. Convergence====\n')
addmargins(table(mcmc$sf, mcmc$rg, mcmc$cvg, dnn = c('sf', 'rg', 'cvg')))

cat('\n====Calibration Strategy vs. Calibration Coverage vs. Convergence====\n')
addmargins(table(mcmc$cst, mcmc$fp, mcmc$cvg, dnn = c('cst', 'fp', 'cvg')))

cat('\n====Data Partition vs. Clock Model vs. Convergence====\n')
addmargins(table(mcmc$part, mcmc$corr, mcmc$cvg, dnn = c('part', 'corr', 'cvg')))
sink()

## find the center point of the highest density of points of all groups----
pca_centpoints.ind <- as.vector(sapply(1:max(pca_db$cluster), 
                                       FUN=function(x){
                                           which.min(apply(as.matrix(dist(BrTimePC1to3[pca_db$cluster==x,], diag = T, upper = T)), MARGIN = 1, sum))
                                       }, 
                                       simplify = T, USE.NAMES = F))
pca_centpoints.tre <- apply(cbind(1:max(pca_db$cluster),pca_centpoints.ind), 1, 
                            FUN=function(x){
                                mcmc[pca_group==x[1],][x[2],]
                            })
pca_centpoints.tre <- Reduce(rbind,pca_centpoints.tre)

tsne_centpoints.ind <- as.vector(sapply(1:max(tsne_db$cluster), 
                                        FUN=function(x){
                                            which.min(apply(as.matrix(dist(BrTimeTSNE3d[tsne_db$cluster==x,], diag = T, upper = T)), MARGIN = 1, sum))
                                        }, 
                                        simplify = T, USE.NAMES = F))
tsne_centpoints.tre <- apply(cbind(1:max(tsne_db$cluster),tsne_centpoints.ind), 1, 
                             FUN=function(x){
                                 mcmc[tsne_group==x[1],][x[2],]
                             })
tsne_centpoints.tre <- Reduce(rbind,tsne_centpoints.tre)

prd_centpoints.ind <- as.vector(sapply(1:max(prd_db$cluster), 
                                       FUN=function(x){
                                           which.min(apply(TreeDistMatrix[prd_db$cluster==x,prd_db$cluster==x], MARGIN = 1, sum))
                                       }, 
                                       simplify = T, USE.NAMES = F))
prd_centpoints.tre <- apply(cbind(1:max(prd_db$cluster),prd_centpoints.ind), 1, 
                            FUN=function(x){
                                mcmc[prd_group==x[1],][x[2],]
                            })
prd_centpoints.tre <- Reduce(rbind,prd_centpoints.tre)

aec_centpoints.ind <- as.vector(sapply(1:max(aec_db$cluster), 
                                       FUN=function(x){
                                           which.min(apply(as.matrix(dist(aec_res[aec_db$cluster==x,], diag = T, upper = T)), MARGIN = 1, sum))
                                       }, 
                                       simplify = T, USE.NAMES = F))
aec_centpoints.tre <- apply(cbind(1:max(aec_db$cluster),aec_centpoints.ind), 1, 
                            FUN=function(x){
                                mcmc[aec_group==x[1],][x[2],]
                            })
aec_centpoints.tre <- Reduce(rbind,aec_centpoints.tre)

mcmc.class.report <- mcmc
mcmc.class.report$pca.group <- pca_group
mcmc.class.report$pca.group[mcmc.class.report$pca.group == -1] <- NA
mcmc.class.report$pca.centroid <- rep(NA, nrow(mcmc.class.report))
mcmc.class.report$pca.centroid[as.numeric(row.names(pca_centpoints.tre))] <- '*'
mcmc.class.report$tsne.group <- tsne_group
mcmc.class.report$tsne.group[mcmc.class.report$tsne.group == -1] <- NA
mcmc.class.report$tsne.centroid <- rep(NA, nrow(mcmc.class.report))
mcmc.class.report$tsne.centroid[as.numeric(row.names(tsne_centpoints.tre))] <- '*'
mcmc.class.report$prd.group <- prd_group
mcmc.class.report$prd.group[mcmc.class.report$prd.group == -1] <- NA
mcmc.class.report$prd.centroid <- rep(NA, nrow(mcmc.class.report))
mcmc.class.report$prd.centroid[as.numeric(row.names(prd_centpoints.tre))] <- '*'
mcmc.class.report$aec.group <- aec_group
mcmc.class.report$aec.group[mcmc.class.report$aec.group == -1] <- NA
mcmc.class.report$aec.centroid <- rep(NA, nrow(mcmc.class.report))
mcmc.class.report$aec.centroid[as.numeric(row.names(aec_centpoints.tre))] <- '*'
write.csv(mcmc.class.report, file = 'mcmc.filtering.and.classification.report.csv', na = '')
rm(knn, eps_opt_id)

## tree plotting and writing functions----
PlotSaveGroupTrees <- function(good_trees, cluster, centpoints, fileprefix){
    BrTime <- Reduce(rbind, lapply(good_trees, function(x){branching.times(x@phylo)}))
    # mean of MCMC-means
    MuMedians <- t(sapply(1:max(cluster), 
                          FUN=function(x){
                              apply(BrTime[cluster==x,], MARGIN = 2, mean)
                          }))
    colnames(MuMedians) <- as.character(seq(1, good_trees[[1]]@phylo$Nnode)+Ntip(good_trees[[1]]@phylo))
    
    # SE of MCMC-means
    SEMedians <- t(sapply(1:max(cluster), 
                          FUN=function(x){
                              apply(BrTime[cluster==x,], MARGIN = 2, sd)
                          }))
    colnames(SEMedians) <- as.character(seq(1, good_trees[[1]]@phylo$Nnode)+Ntip(good_trees[[1]]@phylo))
    
    # HPD95
    time2edgelength <- function(branchingtimes, edges, rooted = F){
        if (rooted){
            if (length(branchingtimes) == 0.5 * (nrow(edges) - 1)){
                branchingtimes <- c(branchingtimes[1], branchingtimes)
            }
            times <- c(rep(0, 0.5 * (nrow(edges) + 1)), branchingtimes)
        }else{
            times <- c(rep(0, 0.5 * (nrow(edges) + 2)), branchingtimes)
        }
        new.edges <- apply(edges, 1, FUN = function(x){times[x[1]] - times[x[2]]})
        return(new.edges)
    }
    
    GrpAvgTrees <- NULL
    GrpCntTrees <- NULL
    
    for (i in sort(unique(cluster))[-1]){
        GrpTrees <- good_trees[cluster==i]
        HPD95.L <- Reduce(rbind, lapply(GrpTrees, function(x){Reduce(rbind, x@data$`0.95HPD`)[,1]}))
        HPD95.L.min <- apply(HPD95.L, 2, min)
        HPD95.L.max <- apply(HPD95.L, 2, max)
        HPD95.U <- Reduce(rbind, lapply(GrpTrees, function(x){Reduce(rbind, x@data$`0.95HPD`)[,2]}))
        HPD95.U.min <- apply(HPD95.U, 2, min)
        HPD95.U.max <- apply(HPD95.U, 2, max)
        HPD95.str <- apply(cbind(HPD95.L.max, HPD95.U.min), 1, list)
        HPD95.str <- lapply(HPD95.str, function(x){unlist(x, use.names = F)})
        HPD95.rlx <- apply(cbind(HPD95.L.min, HPD95.U.max), 1, list)
        HPD95.rlx <- lapply(HPD95.rlx, function(x){unlist(x, use.names = F)})
        ETI95.L <- Reduce(rbind, lapply(GrpTrees, function(x){Reduce(rbind, x@data$`0.95ETI`)[,1]}))
        ETI95.L.min <- apply(ETI95.L, 2, min)
        ETI95.L.max <- apply(ETI95.L, 2, max)
        ETI95.U <- Reduce(rbind, lapply(GrpTrees, function(x){Reduce(rbind, x@data$`0.95ETI`)[,2]}))
        ETI95.U.min <- apply(ETI95.U, 2, min)
        ETI95.U.max <- apply(ETI95.U, 2, max)
        ETI95.str <- apply(cbind(ETI95.L.max, ETI95.U.min), 1, list)
        ETI95.str <- lapply(ETI95.str, function(x){unlist(x, use.names = F)})
        ETI95.rlx <- apply(cbind(ETI95.L.min, ETI95.U.max), 1, list)
        ETI95.rlx <- lapply(ETI95.rlx, function(x){unlist(x, use.names = F)})
        tredat <- GrpTrees[[centpoints[i]]]
        tredat@phylo$edge.length <- time2edgelength(MuMedians[i,], tredat@phylo$edge, rooted = T)
        tredat@data[,1:11] <- NULL
        tredat@data$EPSILON <- SEMedians[i,-1][GrpTrees[[centpoints[i]]]@data$node]
        tredat@data$`0.95HPD_STR` <- HPD95.str
        tredat@data$`0.95HPD_RLX` <- HPD95.rlx
        tredat@data$`0.95ETI_STR` <- ETI95.str
        tredat@data$`0.95ETI_RLX` <- ETI95.rlx
        tredat@file <- paste('AverageTree_Grp_',i,'.tre',sep = '')
        tredat@treetext <- ''
        GrpAvgTrees[[i]] <- tredat
        write.beast(tredat, file = paste(fileprefix,'-AverageTree_Grp_',i,'.tre',sep = ''), translate = F, tree.name = paste('AvgGrp_',i,sep = ''))
        GrpTrees[[centpoints[i]]]@data$MU <- MuMedians[i,-1][GrpTrees[[centpoints[i]]]@data$node]
        GrpTrees[[centpoints[i]]]@data$EPSILON <- SEMedians[i,-1][GrpTrees[[centpoints[i]]]@data$node]
        GrpTrees[[centpoints[i]]]@data$`0.95HPD_STR` <- HPD95.str
        GrpTrees[[centpoints[i]]]@data$`0.95HPD_RLX` <- HPD95.rlx
        GrpTrees[[centpoints[i]]]@data$`0.95ETI_STR` <- ETI95.str
        GrpTrees[[centpoints[i]]]@data$`0.95ETI_RLX` <- ETI95.rlx
        GrpCntTrees[[i]] <- GrpTrees[[centpoints[i]]]
        write.beast(GrpTrees[[centpoints[i]]], file = paste(fileprefix,'-CentroidTree_Grp_',i,'.tre',sep = ''), translate = F, tree.name = paste('CentroidGrp_',i,sep = ''))
    }
    
    # print figure
    ColorX <- c('#cc8cbc','#95a7a4','#948f6c','#609c70','#f05d4a','#aedbe1','#90447c','#002468','#194f1d','#5d1d07','#edc720','#dccaa8','#b59af2','#b56710','#dc6626','#42e476','#d0aca2','#6fc8d8','#a68a8d','#32a04d','#d7c1c0','#9d0000','#7c664e','#1d4d66','#8b4c39','#2982a2','#ba8547','#846671','#5f6b6b','#584f31','#4525b1','#cdcd00','#c4bda5','#ebd261','#ac9f77','#627f89','#9d5d8c','#aea88f','#146d1e','#71542b','#bfbfb4','#8b7a50','#1cbcd5','#bab590','#553e2d','#92310f','#00868b','#591618','#978466','#a4915c','#e29873','#36648b','#693e5a','#327570','#8c571b','#ba6452','#a787a1','#b5a49e','#ba3000','#646d4f','#d21111','#7c9d9e','#3c3520','#be9e1e','#c380d9','#579261','#90988e','#7f7f66','#ffdcca','#917a63','#b6cd2b','#bda683') 
    
    EdgeColors <- function(tree, cat){
        tips <- tree$tip.label
        Colors <- rep('black', nrow(tree$edge))
        CAT0 <- cbind(ColorX[1:length(unique(cat))], unique(cat))
        rownames(CAT0) <- unique(cat)
        cat <- cat[tips]
        CAT0 <- CAT0[unique(cat), ]
        CAT1 <- NULL
        for (i in 1:nrow(CAT0)){
            xxx <- which(cat==CAT0[i,2])
            icat <- c(1, which(diff(xxx) > 1) + 1)
            if (length(icat) > 1){
                newcat <- paste(CAT0[i,2], '(', as.character(1:length(icat)), ')', sep = '')
                CAT1 <- rbind(CAT1, cbind(CAT0[i,1], newcat))
                for (j in 1:length(icat)){
                    cat[xxx[icat[j]:length(xxx)]] <- newcat[j]
                }
            }else{
                CAT1 <- rbind(CAT1, cbind(CAT0[i,1], CAT0[i,2]))
            }
        }
        SppYPos <- node.height(tree)[1:length(tips)]
        names(SppYPos) <- tips
        ncat1 <- nrow(CAT1)
        BarTxtPos <- data.frame(by0 = rep(NA, nrow = ncat1),
                                by1 = rep(NA, nrow = ncat1),
                                ty = rep(NA, nrow = ncat1),
                                btc = rep('black', nrow = ncat1))
        m <- mrca(tree)
        for (i in 1:ncat1){
            ed <- unique(as.vector(m[tips[cat==CAT1[i,2]],tips[cat==CAT1[i,2]]]))
            Colors[tree$edge[,2] %in% ed] <- CAT1[i,1]
            BarTxtPos[i,4] <- CAT1[i,1]
            BarTxtPos[i,3] <- max(SppYPos[tips[cat==CAT1[i,2]]]) 
            BarTxtPos[i,2] <- BarTxtPos[i,3] + 0.1
            BarTxtPos[i,1] <- min(SppYPos[tips[cat==CAT1[i,2]]]) - 0.1
        }
        return(list(Colors, BarTxtPos, CAT0, CAT1[,2]))
    }
    
    xxx <- unlist(lapply(GrpCntTrees, function(x){max(branching.times(x@phylo))}))
    MaxBrTimeCompan <- max(xxx)-xxx
    xxx <- unlist(lapply(GrpAvgTrees, function(x){max(branching.times(x@phylo))}))
    MaxBrTimeCompan <- list(MaxBrTimeCompan, max(xxx)-xxx)
    rm(xxx)
    
    svg(filename = paste(fileprefix,'-MarkedGroupCentroidTrees.svg',sep=''), width = 40, height = 80, pointsize = 12)
    layout(mat = matrix(c(1:length(GrpCntTrees)),nrow = length(GrpCntTrees)))
    for (i in 1:length(GrpCntTrees)){
        lad.tree <- ladderize(GrpCntTrees[[i]]@phylo, right = T)
        # lad.tree <- GrpCntTrees[[i]]@phylo
        if (i == 1){
            EdgeBarTxtColors <- EdgeColors(lad.tree, ClassShort)
        }
        nodebar_pos <- max(branching.times(lad.tree)) - Reduce(rbind, GrpCntTrees[[i]]@data$`0.95HPD`[order(as.numeric(GrpCntTrees[[i]]@data$node))])
        nodebar_pos <- cbind(nodebar_pos, node.height(lad.tree)[-c(1:(Ntip(lad.tree)+1))])
        avgnodes <- GrpCntTrees[[i]]@data[order(as.numeric(GrpCntTrees[[i]]@data$node)),c('MU','EPSILON')]
        hpd95 <- unlist(GrpCntTrees[[i]]@data[order(as.numeric(GrpCntTrees[[i]]@data$node)),'0.95HPD']) %>% matrix(ncol = 2, byrow = T)
        
        plot(lad.tree, edge.color = EdgeBarTxtColors[[1]], show.tip.label = FALSE, x.lim = c(0,750)-MaxBrTimeCompan[[1]][i], main = paste('Centroid Tree of Cluster ', as.character(i), ': ', GrpCntTrees[[i]]@file, sep = ''), cex.main = 3, edge.width = 4)
        abline(v=max(branching.times(lad.tree))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
        abline(v=max(branching.times(lad.tree))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
        segments(x0=nodebar_pos[,1], y0=nodebar_pos[,3], x1=nodebar_pos[,2], y1=nodebar_pos[,3], lwd = 4, col = 'royalblue', lend = 'butt')
        points(x=max(branching.times(lad.tree)) - avgnodes$MU, y=nodebar_pos[,3], pch = ifelse(avgnodes$MU >= hpd95[,1] & avgnodes$MU <= hpd95[,2], 18, 23), cex = 3, col = ifelse(branching.times(lad.tree)[-1] >= avgnodes$MU, 'darkolivegreen','orange'))
        nodelabels(node = as.numeric(unlist(strsplit(lad.tree$node.label[grep('@',lad.tree$node.label)], '@'))) + ifelse(is.rooted(lad.tree), 1, 0), frame = 'none', pch = 8, adj = c(1.5,1), cex = 3)
        segments(x0 = max(branching.times(lad.tree)) + 7, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree)) + 7, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 8, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
        if (i == 1){
            text(x = max(branching.times(lad.tree)) + 14, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 4, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
            rect(max(branching.times(lad.tree))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 185, max(branching.times(lad.tree))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 191, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
            text(x=max(branching.times(lad.tree))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
        }
        if (i == length(GrpCntTrees)){
            axisPhylo(cex.axis=3, lwd = 3, padj = 1)
            mtext('Ma', side=1, at = 640, cex = 2, padj = 1.5)
            legend(x = 'bottomleft', legend = c('Cluster averaged median (<= node age, dropped in 95%HPD)', 'Cluster averaged median (<= node age, out of 95%HPD)', 'Cluster averaged median (> node age, dropped in 95%HPD)', 'Cluster averaged median (> node age, out of 95%HPD)', 'Calibrated nodes', EdgeBarTxtColors[[3]][,2]), pch = c(18, 23, 18, 23, 8, rep(15, nrow(EdgeBarTxtColors[[3]]))), col = c('darkolivegreen', 'darkolivegreen', 'orange', 'orange', 'black', EdgeBarTxtColors[[3]][,1]), text.col = c('darkolivegreen', 'darkolivegreen', 'orange', 'orange', 'black', EdgeBarTxtColors[[3]][,1]), cex = 2, bg = 'white', box.lwd =3)
        }
    }
    dev.off()
    
    svg(filename = paste(fileprefix,'-MarkedGroupAverageTrees.svg',sep=''), width = 40, height = 80, pointsize = 12)
    layout(mat = matrix(c(1:length(GrpAvgTrees)),nrow = length(GrpAvgTrees)))
    for (i in 1:length(GrpAvgTrees)){
        lad.tree <- ladderize(GrpAvgTrees[[i]]@phylo, right = T)
        # lad.tree <- GrpAvgTrees[[i]]@phylo
        if (i == 1){
            EdgeBarTxtColors <- EdgeColors(lad.tree, ClassShort)
        }
        nodebar_pos <- cbind(max(branching.times(lad.tree)) - Reduce(rbind, GrpAvgTrees[[i]]@data$`0.95HPD_RLX`[order(as.numeric(GrpAvgTrees[[i]]@data$node))]), 
                             max(branching.times(lad.tree)) - Reduce(rbind, GrpAvgTrees[[i]]@data$`0.95HPD_STR`[order(as.numeric(GrpAvgTrees[[i]]@data$node))]), 
                             node.height(lad.tree)[-c(1:(Ntip(lad.tree)+1))])
        avgnodes <- GrpAvgTrees[[i]]@data[order(as.numeric(GrpAvgTrees[[i]]@data$node)),'EPSILON']
        
        plot(lad.tree, edge.color = EdgeBarTxtColors[[1]], show.tip.label = FALSE, x.lim = c(0,750)-MaxBrTimeCompan[[2]][i], main = paste('Average Tree of Cluster ', as.character(i), ': ', GrpAvgTrees[[i]]@file, sep = ''), cex.main = 3, edge.width = 4)
        abline(v=max(branching.times(lad.tree))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
        abline(v=max(branching.times(lad.tree))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
        segments(x0=nodebar_pos[,1], y0=nodebar_pos[,5], x1=nodebar_pos[,2], y1=nodebar_pos[,5], lwd = 6, col = 'royalblue', lend = 'butt')
        segments(x0=nodebar_pos[,3], y0=nodebar_pos[,5], x1=nodebar_pos[,4], y1=nodebar_pos[,5], lwd = 4, col = 'coral', lend = 'butt')
        nodelabels(node = as.numeric(unlist(strsplit(lad.tree$node.label[grep('@',lad.tree$node.label)], '@'))) + ifelse(is.rooted(lad.tree), 1, 0), frame = 'none', pch = 8, adj = c(1.5,1), cex = 3)
        segments(x0 = max(branching.times(lad.tree)) + 7, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree)) + 7, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 8, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
        if (i == 1){
            text(x = max(branching.times(lad.tree)) + 14, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 4, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
            rect(max(branching.times(lad.tree))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 185, max(branching.times(lad.tree))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 191, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
            text(x=max(branching.times(lad.tree))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
        }
        if (i == length(GrpAvgTrees)){
            axisPhylo(cex.axis=3, lwd = 3, padj = 1)
            mtext('Ma', side=1, at = 640, cex = 2, padj = 1.5)
            legend(x = 'bottomleft', legend = c('Relaxed 95% HPD', 'Strict 95% HPD','Calibrated nodes', EdgeBarTxtColors[[3]][,2]), pch = c(22, 22, 8, rep(15, nrow(EdgeBarTxtColors[[3]]))), col = c('royalblue','coral', 'black', EdgeBarTxtColors[[3]][,1]), text.col = c('royalblue','coral', 'black', EdgeBarTxtColors[[3]][,1]), cex = 2, bg = 'white', box.lwd =3)
        }
    }
    dev.off()
    
    for (i in 1:length(GrpCntTrees)){
        svg(filename = paste(fileprefix,'-MarkedGroupCentroid&AverageTrees-Group-',as.character(i),'.svg', sep = ''), width = 100, height = 120, pointsize = 20)
        layout(mat = matrix(c(1:2), nrow = 1, ncol = 2))
        # lad.tree <- GrpCntTrees[[i]]@phylo
        # Centroid Tree
        lad.tree1 <- ladderize(GrpCntTrees[[i]]@phylo, right = T)
        # if (i == 1){
        EdgeBarTxtColors <- EdgeColors(lad.tree1, ClassLong)
        # }
        nodebar_pos <- max(branching.times(lad.tree1)) - Reduce(rbind, GrpCntTrees[[i]]@data$`0.95HPD`[order(as.numeric(GrpCntTrees[[i]]@data$node))])
        nodebar_pos <- cbind(nodebar_pos, node.height(lad.tree1)[-c(1:(Ntip(lad.tree1)+1))])
        avgnodes <- GrpCntTrees[[i]]@data[order(as.numeric(GrpCntTrees[[i]]@data$node)),c('MU','EPSILON')]
        hpd95 <- unlist(GrpCntTrees[[i]]@data[order(as.numeric(GrpCntTrees[[i]]@data$node)),'0.95HPD']) %>% matrix(ncol = 2, byrow = T)
        plot(lad.tree1, edge.color = EdgeBarTxtColors[[1]], show.tip.label = TRUE, x.lim = c(0,800)-MaxBrTimeCompan[[1]][i], main = paste('Centroid Tree of Cluster ', as.character(i), ': ', GrpCntTrees[[i]]@file, sep = ''), cex.main = 3, edge.width = 4)
        abline(v=max(branching.times(lad.tree1))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
        abline(v=max(branching.times(lad.tree1))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
        segments(x0=nodebar_pos[,1], y0=nodebar_pos[,3], x1=nodebar_pos[,2], y1=nodebar_pos[,3], lwd = 14, col = 'royalblue', lend = 'butt')
        points(x=max(branching.times(lad.tree1)) - avgnodes$MU, y=nodebar_pos[,3], pch = ifelse(avgnodes$MU >= hpd95[,1] & avgnodes$MU <= hpd95[,2], 18, 23), cex = 3, col = ifelse(branching.times(lad.tree1)[-1] >= avgnodes$MU, 'darkolivegreen','orange'))
        nodelabels(node = as.numeric(unlist(strsplit(lad.tree1$node.label[grep('@',lad.tree1$node.label)], '@'))) + ifelse(is.rooted(lad.tree1), 1, 0), frame = 'none', pch = 8, adj = c(1.5,1), cex = 2)
        segments(x0 = max(branching.times(lad.tree1)) + 75, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree1)) + 75, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 16, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
        text(x = max(branching.times(lad.tree1)) + 80, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 2, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
        rect(max(branching.times(lad.tree1))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 186, max(branching.times(lad.tree1))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 190, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
        text(x=max(branching.times(lad.tree1))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
        axisPhylo(cex.axis=3, lwd = 3, padj = 1)
        mtext('Ma', side=1, at = 640, cex = 2, padj = 1.5)
        legend(x = 'bottomleft', legend = c('Cluster averaged median (<= node age, dropped in 95%HPD)', 'Cluster averaged median (<= node age, out of 95%HPD)', 'Cluster averaged median (> node age, dropped in 95%HPD)', 'Cluster averaged median (> node age, out of 95%HPD)', 'Calibrated nodes', EdgeBarTxtColors[[3]][,2]), pch = c(18, 23, 18, 23, 8, rep(15, nrow(EdgeBarTxtColors[[3]]))), col = c('darkolivegreen', 'darkolivegreen', 'orange', 'orange', 'black', EdgeBarTxtColors[[3]][,1]), text.col = c('darkolivegreen', 'darkolivegreen', 'orange', 'orange', 'black', EdgeBarTxtColors[[3]][,1]), cex = 2, bg = 'white', box.lwd =3)
        # Averaged Tree
        lad.tree2 <- ladderize(GrpAvgTrees[[i]]@phylo, right = T)
        nodebar_pos <- cbind(max(branching.times(lad.tree2)) - Reduce(rbind, GrpAvgTrees[[i]]@data$`0.95HPD_RLX`[order(as.numeric(GrpAvgTrees[[i]]@data$node))]), 
                             max(branching.times(lad.tree2)) - Reduce(rbind, GrpAvgTrees[[i]]@data$`0.95HPD_STR`[order(as.numeric(GrpAvgTrees[[i]]@data$node))]), 
                             node.height(lad.tree2)[-c(1:(Ntip(lad.tree2)+1))])
        avgnodes <- GrpAvgTrees[[i]]@data[order(as.numeric(GrpAvgTrees[[i]]@data$node)),'EPSILON']
        # EdgeBarTxtColors <- EdgeColors(lad.tree2, ClassLong)
        plot(lad.tree2, edge.color = EdgeBarTxtColors[[1]], show.tip.label = TRUE, x.lim = c(0,800)-MaxBrTimeCompan[[2]][i], main = paste(fileprefix,'-Average Tree of Cluster ', as.character(i), sep = ''), cex.main = 3, edge.width = 4)
        abline(v=max(branching.times(lad.tree2))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
        abline(v=max(branching.times(lad.tree2))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
        segments(x0=nodebar_pos[,1], y0=nodebar_pos[,5], x1=nodebar_pos[,2], y1=nodebar_pos[,5], lwd = 14, col = 'royalblue', lend = 'butt')
        segments(x0=nodebar_pos[,3], y0=nodebar_pos[,5], x1=nodebar_pos[,4], y1=nodebar_pos[,5], lwd = 6, col = 'coral', lend = 'butt')
        nodelabels(node = as.numeric(unlist(strsplit(lad.tree2$node.label[grep('@',lad.tree2$node.label)], '@'))) + ifelse(is.rooted(lad.tree2), 1, 0), frame = 'none', pch = 8, adj = c(1.5,1), cex = 2)
        # nodelabels(node = as.numeric(unlist(strsplit(lad.tree2$node.label[grep('@',lad.tree2$node.label)], '@'))) + ifelse(is.rooted(lad.tree2), 1, 0), frame = 'none', pch = 8, adj = c(0.5,0.5), cex = 2)
        segments(x0 = max(branching.times(lad.tree2)) + 75, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree2)) + 75, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 16, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
        text(x = max(branching.times(lad.tree2)) + 80, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 2, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
        rect(max(branching.times(lad.tree2))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 186, max(branching.times(lad.tree2))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 190, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
        text(x=max(branching.times(lad.tree2))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
        axisPhylo(cex.axis=3, lwd = 3, padj = 1)
        mtext('Ma', side=1, at = 640, cex = 2, padj = 1.5)
        legend(x = 'bottomleft', legend = c('Relaxed 95% HPD', 'Strict 95% HPD','Calibrated nodes', EdgeBarTxtColors[[3]][,2]), pch = c(22, 22, 8, rep(15, nrow(EdgeBarTxtColors[[3]]))), col = c('royalblue','coral', 'black', EdgeBarTxtColors[[3]][,1]), text.col = c('royalblue','coral', 'black', EdgeBarTxtColors[[3]][,1]), cex = 2, bg = 'white', box.lwd =3)
        dev.off()
    }
    return(list(GrpAvgTrees,GrpCntTrees))
}

## compute the mean and SE of median ages and HPD95% trapezoids for PCA-DBSCAN trees (good tree only)----
xxx <- PlotSaveGroupTrees(good_trees=AllTrees[mcmc$cvg=='G'], cluster=pca_db$cluster, centpoints=pca_centpoints.ind, fileprefix='PCA-DBSCAN')

GrpAvgTrees_PCA <- xxx[[1]]
GrpCntTrees_PCA <- xxx[[2]]

## compute the mean and SE of median ages and HPD95% trapezoids for tSNE-DBSCAN trees (good tree only)----
xxx <- PlotSaveGroupTrees(good_trees=AllTrees[mcmc$cvg=='G'], cluster=tsne_db$cluster, centpoints=tsne_centpoints.ind, fileprefix='tSNE-DBSCAN')

GrpAvgTrees_tSNE <- xxx[[1]]
GrpCntTrees_tSNE <- xxx[[2]]

## compute the mean and SE of median ages and HPD95% trapezoids for PRD-DBSCAN trees (good tree only)----
xxx <- PlotSaveGroupTrees(good_trees=AllTrees[mcmc$cvg=='G'], cluster=prd_db$cluster, centpoints=prd_centpoints.ind, fileprefix='PRD-DBSCAN')

GrpAvgTrees_PRD <- xxx[[1]]
GrpCntTrees_PRD <- xxx[[2]]

## compute the mean and SE of median ages and HPD95% trapezoids for AEC-DBSCAN trees (good tree only)----
xxx <- PlotSaveGroupTrees(good_trees=AllTrees[mcmc$cvg=='G'], cluster=aec_db$cluster, centpoints=aec_centpoints.ind, fileprefix='AEC-DBSCAN')

GrpAvgTrees_AEC <- xxx[[1]]
GrpCntTrees_AEC <- xxx[[2]]

rm(xxx)

saveRDS(GrpCntTrees_PCA, './GrpCntTrees_PCA.rds')
saveRDS(GrpAvgTrees_PCA, './GrpAvgTrees_PCA.rds')
saveRDS(GrpCntTrees_tSNE, './GrpCntTrees_tSNE.rds')
saveRDS(GrpAvgTrees_tSNE, './GrpAvgTrees_tSNE.rds')
saveRDS(GrpCntTrees_PRD, './GrpCntTrees_PRD.rds')
saveRDS(GrpAvgTrees_PRD, './GrpAvgTrees_PRD.rds')
saveRDS(GrpCntTrees_AEC, './GrpCntTrees_AEC.rds')
saveRDS(GrpAvgTrees_AEC, './GrpAvgTrees_AEC.rds')

# divergence time of key nodes----
keyclades <- c('root', 'EuMetazoa', 'Ecdysozoa', 'Arthropoda', 'Tardigrada', 'Nematomorpha', 'Nematoda', 'Enoplia (Clade II)', 'Dorylaimia (Clade I)', 'Chromadoria', 'Rhabditida','Spirurina (Clade III)', 'Tylenchina (Clade IV)', 'Rhabditina (Clade V)', 'Trichinellida', 'Tylenchomorpha', 'Diplogastromorpha', 'Strongyloididae', 'Ascarididae', 'Onchocercidae', 'Strongyloidea')

GetTime <- function(phy, tre='cnt', out = 'char'){
    keynodes <- c(getMRCA(phy@phylo, tip = row.names(Classification)), 
                  getMRCA(phy@phylo, tip = row.names(Classification)[-1]),
                  getMRCA(phy@phylo, tip = row.names(Classification)[-1:-9]),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Arthropoda']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Tardigrada']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Nematomorpha']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Phylum %in% c('Chromadoria','Dorylaimia','Enoplia')]),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Enoplia (Clade II)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Dorylaimia (Clade I)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Phylum=='Chromadoria']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade %in% c('Spirurina (Clade III)','Tylenchina (Clade IV)','Rhabditina (Clade V)')]),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Spirurina (Clade III)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Tylenchina (Clade IV)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Rhabditina (Clade V)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Order=='Trichinellida']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Order=='Tylenchomorpha']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Order=='Diplogastromorpha']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Family=='Strongyloididae']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Family=='Ascarididae']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Family=='Onchocercidae']), 
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Order=='Strongyloidea'])
    )
    if (out == 'char'){
        if (tre=='cnt'){
            hdi <- unlist(Map(function(x){paste(round(unlist(phy@data[phy@data$node==x, '0.95HPD']), digit=2), collapse=',')}, keynodes))
        }else if (tre=='avg'){
            hdi <- unlist(Map(function(x){paste(round(unlist(phy@data[phy@data$node==x, '0.95HPD_RLX']), digit=2), collapse=',')}, keynodes))
        }
        bt <- round(branching.times(phy@phylo)[keynodes - Ntip(phy@phylo)],2)
        
        res <- paste(bt, '[', hdi, ']', sep='')
        names(res) <- keyclades
    }else if (out == 'num'){
        if (tre=='cnt'){
            res <- cbind(bt = branching.times(phy@phylo)[keynodes - Ntip(phy@phylo)], t(sapply(Map(function(x){unlist(phy@data[phy@data$node==x, '0.95HPD'])}, keynodes), c)))
        }else if (tre=='avg'){
            res <- cbind(bt = branching.times(phy@phylo)[keynodes - Ntip(phy@phylo)], t(sapply(Map(function(x){unlist(phy@data[phy@data$node==x, '0.95HPD_RLX'])}, keynodes), c)))
        }
        rownames(res) <- keyclades
    }
    return(res)
}

write.csv(cbind(Cluster=c(1:length(GrpCntTrees_PCA)), Reduce(rbind, lapply(GrpCntTrees_PCA, GetTime, tre='cnt')), Treefile=unlist(Map(function(x){GrpCntTrees_PCA[[x]]@file}, 1:length(GrpCntTrees_PCA)))), file = './KeyCladeTime_GrpCntTrees_PCA.csv', row.names = F)
write.csv(cbind(Cluster=c(1:length(GrpAvgTrees_PCA)), Reduce(rbind, lapply(GrpAvgTrees_PCA, GetTime, tre='avg')), Treefile=unlist(Map(function(x){GrpAvgTrees_PCA[[x]]@file}, 1:length(GrpAvgTrees_PCA)))), file = './KeyCladeTime_GrpAvgTrees_PCA.csv', row.names = F)
write.csv(cbind(Cluster=c(1:length(GrpCntTrees_tSNE)), Reduce(rbind, lapply(GrpCntTrees_tSNE, GetTime, tre='cnt')), Treefile=unlist(Map(function(x){GrpCntTrees_tSNE[[x]]@file}, 1:length(GrpCntTrees_tSNE)))), file = './KeyCladeTime_GrpCntTrees_tSNE.csv', row.names = F)
write.csv(cbind(Cluster=c(1:length(GrpAvgTrees_tSNE)), Reduce(rbind, lapply(GrpAvgTrees_tSNE, GetTime, tre='avg')), Treefile=unlist(Map(function(x){GrpAvgTrees_tSNE[[x]]@file}, 1:length(GrpAvgTrees_tSNE)))), file = './KeyCladeTime_GrpAvgTrees_tSNE.csv', row.names = F)
write.csv(cbind(Cluster=c(1:length(GrpCntTrees_PRD)), Reduce(rbind, lapply(GrpCntTrees_PRD, GetTime, tre='cnt')), Treefile=unlist(Map(function(x){GrpCntTrees_PRD[[x]]@file}, 1:length(GrpCntTrees_PRD)))), file = './KeyCladeTime_GrpCntTrees_PRD.csv', row.names = F)
write.csv(cbind(Cluster=c(1:length(GrpAvgTrees_PRD)), Reduce(rbind, lapply(GrpAvgTrees_PRD, GetTime, tre='avg')), Treefile=unlist(Map(function(x){GrpAvgTrees_PRD[[x]]@file}, 1:length(GrpAvgTrees_PRD)))), file = './KeyCladeTime_GrpAvgTrees_PRD.csv', row.names = F)
write.csv(cbind(Cluster=c(1:length(GrpCntTrees_AEC)), Reduce(rbind, lapply(GrpCntTrees_AEC, GetTime, tre='cnt')), Treefile=unlist(Map(function(x){GrpCntTrees_AEC[[x]]@file}, 1:length(GrpCntTrees_AEC)))), file = './KeyCladeTime_GrpCntTrees_AEC.csv', row.names = F)
write.csv(cbind(Cluster=c(1:length(GrpAvgTrees_AEC)), Reduce(rbind, lapply(GrpAvgTrees_AEC, GetTime, tre='avg')), Treefile=unlist(Map(function(x){GrpAvgTrees_AEC[[x]]@file}, 1:length(GrpAvgTrees_AEC)))), file = './KeyCladeTime_GrpAvgTrees_AEC.csv', row.names = F)

system('bash ./svg2pdf.sh r')

save.image('/mnt/hdd2/Nematoda/timing/20241203/AllPosteriorTimeTree.CLGPMSF.RData')
