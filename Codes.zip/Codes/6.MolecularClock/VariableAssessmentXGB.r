## Loading libraries----
library(xgboost);library(tidyverse);library(DataExplorer);library(pROC);library(shapr);library(iml);library(caret);library(DiagrammeR);library(SHAPforxgboost)
# library(tidymodels)

# custom function
shap.value.xgb<-function (xgb_model, X_train, target_class = NULL) 
{
    shap_contrib <- predict(xgb_model, (X_train), predcontrib = TRUE)
    if (is.list(shap_contrib)) {
        shap_contrib <- if (!is.null(target_class) && !is.na(target_class)) 
            shap_contrib[[target_class + 1]]
        else Reduce("+", lapply(shap_contrib, abs))
    }
    if (is.null(colnames(shap_contrib))) {
        colnames(shap_contrib) <- c(colnames(X_train), "BIAS")
    }
    shap_contrib <- data.table::as.data.table(shap_contrib)
    BIAS0 <- shap_contrib[, ncol(shap_contrib), with = FALSE][1]
    shap_contrib[, `:=`(BIAS, NULL)]
    imp <- colMeans(abs(shap_contrib))
    mean_shap_score <- imp[order(imp, decreasing = T)]
    return(list(shap_score = shap_contrib, mean_shap_score = mean_shap_score, 
                BIAS0 = BIAS0))
}

## Factors that determine the convergence (XGBoost classification)----
# selecting Good/Bad-convergence cases from original dataset----
# Dataset Partitioning
set.seed(20250410)
XGB_train2 <- as.vector(createDataPartition(y = mcmc.dump.bin[, 1], p = 0.8, list = F))
# XGB_test2 <- c(1:sum())[-XGB_train2]
# XGB_valid2 <- setdiff(XGB_train2, sample(XGB_train2, 50))
# XGB_train2 <- setdiff(XGB_train2, XGB_valid2)

XGB_data_train2 <- xgb.DMatrix(data = as.matrix(mcmc.dump.bin[XGB_train2, -1]), label = as.matrix(mcmc.dump.bin[XGB_train2, 1]))
XGB_data_valid2 <- xgb.DMatrix(data = as.matrix(mcmc.dump.bin[-XGB_train2, -1]), label = as.matrix(mcmc.dump.bin[-XGB_train2, 1]))
# XGB_data_test2 <- xgb.DMatrix(data = as.matrix(mcmc.dump.bin[XGB_test2, -1]), label = as.matrix(mcmc.dump.bin[XGB_test2, 1]))

watchlist2 <- list(train=XGB_data_train2, test=XGB_data_valid2)

# tuning
# fitGrid <- expand.grid(nrounds = 1000, 
#                        eta = c(0.001, 0.005, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8),
#                        max_depth = c(2, 3, 4, 5, 6, 7, 8),
#                        gamma = c(0, 0.001, 0.002, 0.005, 0.01, 0.05, 0.1, 0.5, 1), 
#                        colsample_bytree = seq(0.1, 1, 0.1), 
#                        min_child_weight = 1, 
#                        subsample = seq(0.1, 1, 0.1)
# )
fitControl <- trainControl(method = "repeatedcv", 
                           number = 5,
                           repeats = 3,
                           p = 0.8, 
                           verboseIter = FALSE,
                           search = "random", # "random" 
                           allowParallel = F
)
caret_xgb2 <- train(factor(cvg) ~.,
                    data = mcmc.dump.bin,
                    method="xgbTree",# xgbLinear
                    trControl=fitControl
)

# model training
sink(file = 'XGB-model-2-class-training-logging.txt')
cat("===== custom train model =====\n\n")
XGB_mod2 <- xgb.train(booster = 'gbtree', 
                      data = XGB_data_train2, 
                      eta = caret_xgb2$bestTune$eta, 
                      gamma = caret_xgb2$bestTune$gamma, 
                      max_depth = caret_xgb2$bestTune$max_depth, 
                      min_child_weight = caret_xgb2$bestTune$min_child_weight, 
                      subsample = caret_xgb2$bestTune$subsample, 
                      colsample_bytree = caret_xgb2$bestTune$colsample_bytree, 
                      objective = 'binary:logistic', 
                      nrounds = 2000, 
                      watchlist = watchlist2, 
                      verbose = 1, 
                      print_every_n = 100, 
                      early_stopping_rounds = 200)
XGB_mod2
cat("\n\n===== caret train best model =====\n\n")
caret_xgb2$finalModel
sink()

# variable importance
sink(file = 'XGB-model-2-class-variable-importance-Gain.txt')
(VarImp_xgb <- xgb.importance(model=XGB_mod2))
sink()

svg(filename = 'XGB-model-2-class-variable-importance-Gain.svg', width = 8, height = 16, bg = 'white', pointsize = 12)
xgb.plot.importance(importance_matrix=VarImp_xgb, measure = 'Gain', top_n = 8)
dev.off()

VarImp_xgb_all4 <- VarImp_xgb %>% 
                   select(Feature,Gain,Cover,Frequency) %>% 
                   pivot_longer(cols = 2:4, names_to = 'Measure', values_to = 'Value') %>% 
                   mutate(
                       Angle =  - 360 * (as.numeric(factor(Feature)) - 0.5) / nrow(VarImp_xgb), 
                       # hjust = ifelse(Angle < -90, 1, 0), 
                       Angle = ifelse(Angle < -90 & Angle > -270, Angle + 180, Angle)
                   )

imp <-ggplot(VarImp_xgb_all4, aes(Feature, Value, fill = Feature)) + 
             geom_col(width = 1, position = "identity") + 
             geom_text(aes(label = Feature, y = 1, 
                           angle = Angle),          # Add Feature label above each column
                       color = "black", size = 6) + 
             geom_text(aes(label = round(Value, 4), y = Value + 0.1, 
                           angle = Angle),          # Add Feature importance above each column
                       color = "black", size = 4) + 
             coord_radial(start = 0, theta = "x", clip = "off", r.axis.inside=FALSE, inner.radius=0.3) + 
             scale_y_continuous(limits = NULL) +
             facet_wrap(~Measure, scales = "free_y") + 
             scale_fill_manual(values = c("#00BFFFFF", "#B22222FF", "#228B22FF", "#DAA520FF", "#6B8E23FF", "#9932CCFF", "#708090FF")) + 
             theme_void() + 
             theme(axis.text.x = element_blank(),
                   strip.text = element_text(size = 12),
                   plot.title = element_text(hjust = 0.5),
                   legend.position = "bottom", legend.byrow = ) + 
             ggtitle("XGB-model Variable Importance", )

svg(filename = 'XGB-model-2-class-variable-importance-all4.svg', width = 18, height = 6, bg = 'white', pointsize = 12)
imp
dev.off()

# SHAP
shap_values_2 <- shap.value.xgb(xgb_model = XGB_mod2, X_train = as.matrix(mcmc.dump.bin[XGB_train2, -1]))

svg(filename = 'XGB-model-2-class-SHAP-dependence.svg', width = 8, height = 16, bg = 'white', pointsize = 12)
xgb.plot.shap(data = as.matrix(mcmc.dump.bin[XGB_train2, -1]), model = XGB_mod2, top_n = 8, n_col = 1, pch = 16, cex=0.8)
dev.off()

svg(filename = 'XGB-model-2-class-SHAP-summary-1.svg', width = 8, height = 6, bg = 'white', pointsize = 12)
xgb.ggplot.shap.summary(data = as.matrix(mcmc.dump.bin[XGB_train2, -1]), model = XGB_mod2, top_n = 8)
dev.off()

svg(filename = 'XGB-model-2-class-SHAP-summary-2.svg', width = 8, height = 6, bg = 'white', pointsize = 12)
shap_long_2 <- shap.prep(xgb_model = XGB_mod2, X_train = as.matrix(mcmc.dump.bin[XGB_train2, -1]), shap_contrib = shap_values_2$shap_score)
shap.plot.summary(shap_long_2)
dev.off()

# # Dependence plot
# plot_list_2 <- lapply(c('part', 'corr', 'cstLS', 'fpFull', 'cstLM', 'fpOI', 'bd', 'rg'), shap.plot.dependence, data_long = shap_long_2)
# gridExtra::grid.arrange(grobs = plot_list_2, ncol = 1)

# # SHAP force plot
# plot_data_2 <- shap.prep.stack.data(shap_contrib = shap_values_2$shap_score, top_n = 4, n_groups = 4)
# # you may choose to zoom in at a location, and set y-axis limit using `y_parent_limit`  
# shap.plot.force_plot(plot_data_2, y_parent_limit = c(-8,8))
# # plot the 2 clusters
# shap.plot.force_plot_bygroup(plot_data_2)

# prediction
XGB_pred2 <- data.frame(Prob=predict(XGB_mod2, newdata = XGB_data_train2))

# ROC
train_roc2 <- roc(response = mcmc.dump.bin[XGB_train2, 1],
                  predictor = XGB_pred2[,1])
# Area under the curve: 0.938
bestp <- train_roc2$thresholds[which.max(train_roc2$sensitivities+train_roc2$specificities-1)]
XGB_pred2$Conv <- factor(ifelse(XGB_pred2$Prob > bestp, 'G', 'B'))

svg(filename = 'XGB-model-2-class-ROC-curve.svg', width = 8, height = 8, bg = 'white', pointsize = 12)
plot(train_roc2, print.auc = T, auc.polygon = T, grid = T, max.auc.polygon = T, auc.polygon.col = 'skyblue', print.thres = T, legacy.axes = T, bty = 'l')
dev.off()

# confusion matrix
sink(file = 'XGB-model-2-class-Confusion-Matrix.txt')
confusionMatrix(data = XGB_pred2$Conv, 
                reference = factor(mcmc.dump[XGB_train2, 1]), 
                positive = 'G', 
                mode = 'everything')
sink()

# summary
sink(file = 'XGB-model-2-class-Binary-Summary.txt')
defaultSummary(
    data.frame(obs = factor(mcmc.dump[XGB_train2, 1]), 
               pred = XGB_pred2$Conv),
    lev = levels(factor(mcmc.dump[XGB_train2, 1]))
)
sink()

system('bash ./svg2pdf.sh r')

save.image('/mnt/hdd2/Nematoda/timing/20241203/AllPosteriorTimeTree.CLGPMSF.RData')

# plot trees
# xgb.plot.tree(model = XGB_mod2, trees = 1:5, plot_width = 1000, plot_height = 1000)
