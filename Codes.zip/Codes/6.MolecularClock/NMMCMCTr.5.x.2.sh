#!/bin/bash
#SBATCH --job-name=NMTmTr2
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=10GB
#SBATCH --time=14-00:00:0
#SBATCH --account=gely025283

module load paml/4.10.7
#MCMCTREE=/sw/apps/paml4.9i/bin/mcmctree

TreCali=$1 
Part=$2 
Clock=$3 
Rgene=$4 
R=$5 
stopgen=3000000
DIR_rt=$(pwd) 
DIR_cur=$DIR_rt/${TreCali}.${Part}.${Clock}.rg${Rgene} 

# MCMCtree step 2: Calculate the divergence time
cd $DIR_cur 
mkdir -p $DIR_cur/DIR_DIV && cd $DIR_cur/DIR_DIV 
if [[ ! -f $DIR_cur/DIR_DIV/run$R/FigTree.tre ]] || [[ $(awk 'END{print $1}' $DIR_cur/DIR_DIV/run$R/mcmc.txt) -lt $stopgen ]] 
then 
    mkdir -p $DIR_cur/DIR_DIV/run$R 
    cp $DIR_cur/DIR_BV/mcmctree.ctl $DIR_cur/DIR_DIV/run$R 
    cp $DIR_cur/DIR_BV/in.BV $DIR_cur/DIR_DIV/run$R 
    sed -i 's/usedata = 3/usedata = 2/g' $DIR_cur/DIR_DIV/run$R/mcmctree.ctl 
    cd $DIR_cur/DIR_DIV/run$R && 
    echo -e "#######################\nMCMCTREE STEP 2 start...\n$(date)\n#######################\n\n" > step2_log.text && 
    echo -e "JOB NAME: $SLURM_JOB_NAME\nJob ID: $SLURM_JOBID\nAllocate Nodes: $SLURM_JOB_NODELIST\n" >> step2_log.text && 
    mcmctree mcmctree.ctl >> step2_log.text 2>&1 
	
	# if step 2 does not round out, redo it one more time until FigTree.tre appears and MCMC comes to the stop generation
	if [[ ! -f $DIR_cur/DIR_DIV/run$R/FigTree.tre ]] || [[ $(awk 'END{print $1}' $DIR_cur/DIR_DIV/run$R/mcmc.txt) -lt $stopgen ]] 
	then 
	    rm -r $DIR_cur/DIR_DIV/run$R && 
		sbatch ./NMMCMCTr.5.x.2.sh $TreCali $Part $Clock $Rgene $R && scancel $SLURM_JOBID 
	fi 
fi 
		
# MCMCtree step 3: Calculate the prior distribution without sequence data
cd $DIR_cur 
mkdir -p $DIR_cur/DIR_PRD && cd $DIR_cur/DIR_PRD
if [[ ! -f $DIR_cur/DIR_PRD/run$R/FigTree.tre ]] || [[ $(awk 'END{print $1}' $DIR_cur/DIR_PRD/run$R/mcmc.txt) -lt $stopgen ]] || [[ $(cat $DIR_cur/DIR_DIV/run$R/SeedUsed) -ne $(grep -s 'seed =' $DIR_cur/DIR_PRD/run$R/mcmctree.ctl | awk -F ' = ' '{print $2}' | tre -d '\r') ]]
then 
	mkdir -p $DIR_cur/DIR_PRD/run$R && rm $DIR_cur/DIR_PRD/run$R/*
    cp $DIR_cur/DIR_BV/mcmctree.ctl $DIR_cur/DIR_PRD/run$R 
    sed -i 's/usedata = 3/usedata = 0/g' $DIR_cur/DIR_PRD/run$R/mcmctree.ctl
    sed -i 's/outfile = out/outfile = out_prd/g' $DIR_cur/DIR_PRD/run$R/mcmctree.ctl 
    sed -i "s#seed = -1#seed = $(cat $DIR_cur/DIR_DIV/run$R/SeedUsed)#g" $DIR_cur/DIR_PRD/run$R/mcmctree.ctl 
    cd $DIR_cur/DIR_PRD/run$R && 
    echo -e "#######################\nMCMCTREE STEP 3 start...\n$(date)\n#######################\n\n" > step3_log.text && 
    echo -e "JOB NAME: $SLURM_JOB_NAME\nJob ID: $SLURM_JOBID\nAllocate Nodes: $SLURM_JOB_NODELIST\n" >> step3_log.text && 
    mcmctree mcmctree.ctl >> step3_log.text 2>&1 

	# if step 3 does not round out, redo it one more time until FigTree.tre appears and MCMC comes to the stop generation
	until [[ -f $DIR_cur/DIR_PRD/run$R/FigTree.tre ]] && [[ $(awk 'END{print $1}' $DIR_cur/DIR_PRD/run$R/mcmc.txt) -ge $stopgen ]] 
	do 
	    rm $DIR_cur/DIR_PRD/run$R/mcmc.txt 
        echo -e "#######################\nMCMCTREE STEP 3 start...\n$(date)\n#######################\n\n" > step3_log.text && 
        echo -e "JOB NAME: $SLURM_JOB_NAME\nJob ID: $SLURM_JOBID\nAllocate Nodes: $SLURM_JOB_NODELIST\n" >> step3_log.text && 
        mcmctree mcmctree.ctl >> step3_log.text 2>&1 
	done 
fi

# MCMCtree step 4: Summarize the MCMC results
# cd $DIR_cur
# cp /user/work/vn21703/nematoda/SumMCMCtree.py .
# chmod -R 777 ./SumMCMCtree.py
# px=$(echo $DIR_cur | sed -s 's#/user/work/vn21703/nematoda/#NMtimetree_#g;s#\/#.#g')
# ./SumMCMCtree.py --postdir $DIR_cur/DIR_DIV --priodir $DIR_cur/DIR_PRD --classification /user/work/vn21703/nematoda/Classification.xlsx --tipcolor /user/work/vn21703/nematoda/tipcolors.xlsx --prefix $px 
