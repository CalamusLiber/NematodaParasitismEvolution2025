## This code is for setting the skew-t and gamma distributions of fossil calibration
setwd('F:/BristolProjects/Nematoda/timing/20250929/PriorDistributionPDF')
# save.image('calibration_distribution.RData')

library(sn)
library(tfprobability)
library(purrr)
library(doParallel)
library(iterators)

# highest prior density intervals----
HPrDI95 <- function(qfunc, st = 0.0001, ed = 0.9999, by = 0.0001){
    wqq <- function(p0){
        q0=qfunc(p0)
        q1=qfunc(p0 + 0.95)
        x <- data.frame(q0, q1, w=q1-q0)
        return(x)
    }
    seq(st,ed-0.95,by) |> map_dfr(\(x) wqq(x)) -> t
    return(unlist(t[which.min(t[,3]),-3]))
}

# plot cauchy curve----
# The following two functions of truncated Cauchy distribution are from: Saralees Nadarajah & Samuel Kotz (2007) Programs in R for Computing Truncated Cauchy Distributions, Quality Technology & Quantitative Management, 4:3, 407-412,DOI: 10.1080/16843703.2007.11673160

#this function computes (1) for given x, mu, scale, a & b
dtcauchy <- function(x, tl = 1, p = 0.1, c = 0.2, pl = 0.025){ 
    loc = tl * (1 + p)
    scl = tl * c
    r0 = pl / pcauchy(tl, loc, scl)
    d <- NULL
    for (t in x){
        if (t > tl) {
            d <- c(d, dcauchy(t, location=loc, scale=scl) / (1 - pcauchy(tl, location=loc, scale=scl) - pl))
        }else{
            d <- c(d, r0 * dcauchy(t, location=loc, scale=scl) / (1 - pcauchy(tl, location=loc, scale=scl) - pl))
        }
    }
    return(d)
}

dtcauchy2 <- function(x, tl = 1, p = 0.1, c = 0.2, pl = 0.025, pu = 0.975) {
    A <- 0.5 + (1/pi) * atan(p/c)
    om <- (pu/pl) * (1 / (pi * A * c * (1 + (p/c)^2)))
    d <- NULL
    for (t in x){
        if (t > tl){
            d <- c(d, pu * (1 / (A * pi * c * tl * (1 + ((t - tl * (1 + p)) / (c * tl)) ^ 2))))
        }else{
            d <- c(d, ifelse(pl == 0, 0, pl * (om/tl) * (t/tl) ^ (om-1)))
        }
    }
    return(d)
}

qtcauchy <- function(pt, p = 0.1, c = 0.2, tl = 1, pl = 0.025){
    loc = tl * (1 + p)
    scl = tl * c
    L <- pcauchy(tl, location=loc, scale=scl) - pl
    qcauchy(L + pt * (1 - L), location=loc, scale=scl)
}

pdf_tcauchy <- function(tl, p, c, pl = 0){
    loc = tl * (1 + p)
    scl = tl * c
    func <- function(x){dtcauchy2(x, tl = tl, p = p, c = c, pl = pl)}
    q01 <- qtcauchy(0.01, p, c, tl, pl)
    q99 <- qtcauchy(0.99, p, c, tl, pl)
    E.ql <- qtcauchy(pl, p, c, tl, pl)
    E.qu <- qtcauchy(0.975, p, c, tl, pl) # = qut
    hpdi <- HPrDI95(qfunc = function(pt){qtcauchy(pt, p, c, tl, pl)})
    xxx <- seq(hpdi[1], hpdi[2], by = 0.0001)
    xxx |> map_dbl(\(xxx) func(xxx)) -> dens
    vmax <- max(dens)
    pmax <- xxx[which.max(dens)]
    mod <- paste('L(', tl, ',', p, ',', c, ',', ifelse(pl == 0,'1e-300',pl), ')', sep = '')
    return(list(tl=tl, p=p, c=c, pl=pl, loc=loc, scl=scl, q01=q01, q99=q99, E.ql=E.ql, E.qu=E.qu, hpdi=hpdi, vmax=vmax, pmax=pmax, mod=mod))
}

plot.tcauchy <- function(pdf, hmin, hmax, TitlePrefix='', last=F){
    func <- function(x){dtcauchy2(x, tl = pdf$tl, p = pdf$p, c = pdf$c, pl = pdf$pl)}
    hleg <- pdf$tl + 0.66 * (hmax - pdf$tl)
    par(mar = c(ifelse(last,5,2),5,4,2)+0.1)
    curve(func, hmin, hmax, n=1001, type = 'l', col = 'red', lwd = 4, xlim=c(hmin, hmax), xaxt = ifelse(last, 's', 'n'), xlab = ifelse(last,'100 Ma',''), ylab = ifelse(last, 'Probability Density',''), cex = 2, cex.axis = 2, cex.lab = 2, mar = c(ifelse(last,5,2),10,4,2))
    title(main = paste(TitlePrefix, 'Truncated Cauchy Distribution: q.01 - q.99\n', '(tl=', pdf$tl, ', p=', pdf$p, ', c=', pdf$c, ', location=', pdf$loc, ', scale=', pdf$scl, ')', sep = ''), cex = 2)
    abline(v=pdf$loc, col='blue', lty = 2, lwd = 3)
    axis(3, at=c(pdf$q01,pdf$q99), labels=FALSE, lty = 1, lwd = 5, col = 'darkcyan')
    rect(pdf$hpdi[1], pdf$vmax * 0.25, pdf$hpdi[2], pdf$vmax * 0.45, density = 20, angle = 45, col = 'deeppink')
    rect(pdf$E.ql, pdf$vmax * 0, pdf$E.qu, pdf$vmax * 0.2, density = 20, angle = 45, col = 'darkorange')
    text(x = hleg, y = pdf$vmax * 0.90, adj = c(0.5,0.5), labels = pdf$mod, col = 'gray25', cex = 2)
    text(x = hleg, y = pdf$vmax * 0.80, adj = c(0.5,0.5), labels = paste('95% HDI = [', round(pdf$hpdi[1], 4), ', ', round(pdf$hpdi[2], 4), ']', sep = ''), col = 'deeppink', cex = 2)
    text(x = hleg, y = pdf$vmax * 0.70, adj = c(0.5,0.5), labels = paste('PTI = [', round(pdf$E.ql, 4), ', ', round(pdf$E.qu, 4), ']', sep = ''), col = 'darkorange', cex = 2)
}

# plot skew-t curve----
pdf_skewt <- function(xi, nu, ql, qu = 10, pl = 0.025, pu = 0.025, single.end = F){
    QUx <- function(omx=10){ 
        require(doParallel)
        qq <- function(x) {
            q <- data.frame(om=x, 
                            qu = qst(omega=x, p=1-pu, xi=xi, alpha=alpha, nu=nu, tol=1e-08, method = 0))
            return(q)
        }
        cl <- makeCluster(ifelse(Sys.info()['sysname']=='Windows',detectCores(),detectCores()-4))
        registerDoParallel(cl)
        omi <- 4
        om <- seq(0.001, omi, by=0.0001)
        while (omi < omx){
            q <- foreach(o=om, .export = c('alpha','pu','xi','nu'), .combine = rbind, .packages = c('sn','purrr')) %dopar% {qq(o)}
            d <- abs(qu - q[,2]) # L1 norm minimum
            res <- as.numeric(q[which.min(d),])
            if (res[1] == omi){
                om <- seq(omi, omi+2, by=0.0001); omi = omi+2
            }else {
                break
            }
        }
        stopCluster(cl)
        return(res)
    }
    QLx <- function(omx=10, alx=100){
        require(doParallel)
        qq <- function(x,y){
            q <- data.frame(om=x, al=y, 
                            ql = qst(p=pl, xi=xi, omega=x, alpha=y, nu=nu, tol=1e-08, method = 0))
            return(q)
        }
        cl <- makeCluster(ifelse(Sys.info()['sysname']=='Windows',detectCores(),detectCores()-4))
        registerDoParallel(cl)
        omi <- 4; alj <- 10
        om <- seq(0.001, omi, by=0.0001)
        al <- seq(0, alj, by=1)
        while (omi < omx && alj < alx){
            q <- foreach(o=om, .export = c('pl','pu','xi','nu'), .combine = rbind, .packages = c('sn','purrr')) %dopar% {map2_dfr(o, al, qq)}
            d <- abs(ql - q[,3]) # L1 norm minimum
            dm <- min(d)
            res <- as.numeric(q[d==dm,])
            if (res[1] == omi && res[2] == alj) {
                om <- seq(omi, omi+2, by=0.0001); omi = omi+2
                al <- seq(alj, alj+10, by=1); alj = alj+10
            }else if (res[1] == omi){
                om <- seq(omi, omi+2, by=0.0001); omi = omi+2
            }else if (res[2] == alj){
                al <- seq(alj, alj+10, by=1); alj = alj+10
            }else {
                break
            }
        }
        stopCluster(cl)
        return(res)
    }
    QLUx1 <- function(omx=10, alx=100){
        require(doParallel)
        qq <- function(x,y){
            q <- data.frame(om=x, al=y, 
                            ql = qst(p=pl, xi=xi, omega=x, alpha=y, nu=nu, tol=1e-08, method = 0), 
                            qu = qst(p=1-pu, xi=xi, omega=x, alpha=y, nu=nu, tol=1e-08, method = 0))
            return(q)
        }
        cl <- makeCluster(ifelse(Sys.info()['sysname']=='Windows',detectCores(),detectCores()-4))
        registerDoParallel(cl)
        omi <- 4; alj <- 10
        om <- seq(0.001, omi, by=0.0001)
        al <- seq(0, alj, by=1)
        while (omi < omx && alj < alx){
            qlu <- foreach(o=om, .export = c('pl','pu','xi','nu'), .combine = rbind, .packages = c('sn','purrr')) %dopar% {map2_dfr(o, al, qq)}
            ss <- (qlu[,3] - ql) ^ 2 / pl + (qlu[,4] - qu) ^ 2 / pu # weighted L2 norm minimum
            res <- as.numeric(qlu[which.min(ss),])
            if (res[1] == omi && res[2] == alj) {
                om <- seq(omi, omi+2, by=0.0001); omi = omi+2
                al <- seq(alj, alj+10, by=1); alj = alj+10
            }else if (res[1] == omi){
                om <- seq(omi, omi+2, by=0.0001); omi = omi+2
            }else if (res[2] == alj){
                al <- seq(alj, alj+10, by=1); alj = alj+10
            }else {
                break
            }
        }
        stopCluster(cl)
        return(res)
    }
    # not good idea
    QLUx2 <- function(omx=10, alx=4000){
        require(doParallel)
        qq <- function(x,y){
            q <- data.frame(om=x, al=y, 
                            ql = qst(p=pl, xi=xi, omega=x, alpha=y, nu=nu, tol=1e-08, method = 0), 
                            qu = qst(p=1-pu, xi=xi, omega=x, alpha=y, nu=nu, tol=1e-08, method = 0))
            return(q)
        }
        cl <- makeCluster(ifelse(Sys.info()['sysname']=='Windows',detectCores(),detectCores()-4))
        registerDoParallel(cl)
        omi <- 4; alj <- 8000
        om <- seq(0.001, omi, by=0.0001)
        al <- seq(10000, alj, by=-200)
        while (omi < omx && alj > alx){
            qlu <- foreach(o=om, .export = c('pl','pu','xi','nu'), .combine = rbind, .packages = c('sn','purrr')) %dopar% {map2_dfr(o, al, qq)}
            ss <- (qlu[,3] - ql) ^ 2 / pl + (qlu[,4] - qu) ^ 2 / pu # weighted L2 norm minimum
            res <- as.numeric(qlu[which.min(ss),])
            if (res[1] == omi && res[2] == alj) {
                om <- seq(omi, omi+2, by=0.0001); omi = omi+2
                al <- seq(alj, alj-2000, by=-200); alj = alj-2000
            }else if (res[1] == omi){
                om <- seq(omi, omi+2, by=0.0001); omi = omi+2
            }else if (res[2] == alj){
                al <- seq(alj, alj-2000, by=-200); alj = alj-2000
            }else {
                break
            }
        }
        stopCluster(cl)
        return(res)
    }
    if (pl == 0){
        if (missing(nu)) nu <- ifelse(single.end, 1, 100)
        alpha <- 10000
        qux <- QUx(omx=10)
        omega <- qux[1]
        E.ql <- ql
        E.qu <- qux[2]
    }else{
        if (single.end) {
            if (missing(nu)) nu <- 2
            qlx <- QLx(omx=10, alx=100)
            omega <- qlx[1]
            alpha <- ceiling(qlx[2])
            E.ql <- qlx[3]
            E.qu <- qst(p=1-pu, xi=xi, omega=omega, alpha=alpha, nu=nu, tol=1e-08, method = 0)
        }else if (pl >= 0.00001){
            if (missing(nu)) nu <- 100
            qlux <- QLUx1(omx=10, alx=100)
            omega <- qlux[1]
            alpha <- ceiling(qlux[2])
            E.ql <- qlux[3]
            E.qu <- qlux[4]
        }else{
            if (missing(nu)) nu <- 5 # not good idea
            qlux <- QLUx2(omx=10, alx=4000)
            omega <- qlux[1]
            alpha <- ceiling(qlux[2])
            E.ql <- qlux[3]
            E.qu <- qlux[4]
        }
    }
    func <- function(x){dst(x, xi = xi, omega = omega, alpha = alpha, nu = nu)}
    q01 <- qst(0.01, xi=xi, omega=omega, alpha=alpha, nu=nu, tol=1e-08, method = 0)
    q99 <- qst(0.99, xi=xi, omega=omega, alpha=alpha, nu=nu, tol=1e-08, method = 0)
    hpdi <- HPrDI95(qfunc = function(p) qst(p, xi = xi, omega = omega, alpha = alpha, nu = nu, tol=1e-08, method = 0))
    xxx <- seq(hpdi[1], hpdi[2], by = 0.0001)
    xxx |> map_dbl(\(xxx) func(xxx)) -> dens
    vmax <- max(dens)
    pmax <- xxx[which.max(dens)]
    mod <- paste('ST(', round(xi, 4), ',', round(omega, 4), ',', alpha, ',', nu, ')', sep = '')
    return(list(xi=xi, omega=omega, alpha=alpha, nu=nu, ql=ql, qu=qu, pl=pl, pu=pu, E.ql=E.ql, E.qu=E.qu, q01=q01, q99=q99, hpdi=hpdi, vmax=vmax, pmax=pmax, mod=mod))
}

plot.skewt <- function(pdf, hmin, hmax, TitlePrefix='', last=F){
    func <- function(x){dst(x, xi = pdf$xi, omega = pdf$omega, alpha = pdf$alpha, nu = pdf$nu)}
    if (pdf$pmax < hmin + 0.66 * diff(c(hmin, hmax))){
        hleg <- pdf$pmax + 0.66 * (hmax - pdf$pmax)        
    }else{
        hleg <- pdf$pmax - 0.66 * (pdf$pmax - hmin)    
    }
    par(mar = c(ifelse(last,5,2),5,4,2)+0.1)
    curve(func, hmin, hmax, n=1001, type = 'l', col = 'red', lwd = 4, xlim=c(hmin, hmax), xaxt = ifelse(last, 's', 'n'), xlab = ifelse(last,'100 Ma',''), ylab = ifelse(last, 'Probability Density',''), cex = 2, cex.axis = 2, cex.lab = 2, mar = c(ifelse(last,5,2),10,4,2))
    title(main = paste(TitlePrefix, 'Skew-t Distribution: q.01 - q.99\n', '(xi=', pdf$xi, ', omega=', round(pdf$omega,4), ', alpha=', pdf$alpha, ', nu=', pdf$nu, ')', sep = ''), cex = 2)
    abline(v=pdf$xi, col='blue', lty = 2, lwd = 3)
    axis(3, at=c(pdf$q01,pdf$q99), labels=FALSE, lty = 1, lwd = 5, col = 'darkcyan')
    rect(pdf$hpdi[1], pdf$vmax * 0.25, pdf$hpdi[2], pdf$vmax * 0.45, density = 20, angle = 45, col = 'deeppink')
    rect(pdf$E.ql, pdf$vmax * 0, pdf$E.qu, pdf$vmax * 0.2, density = 20, angle = 45, col = 'darkorange')
    text(x = hleg, y = pdf$vmax * 0.90, adj = c(0.5,0.5), labels = pdf$mod, col = 'gray25', cex = 2)
    text(x = hleg, y = pdf$vmax * 0.80, adj = c(0.5,0.5), labels = paste('95% HDI = [', round(pdf$hpdi[1], 4), ', ', round(pdf$hpdi[2], 4), ']', sep = ''), col = 'deeppink', cex = 2)
    text(x = hleg, y = pdf$vmax * 0.70, adj = c(0.5,0.5), labels = paste('PTI = [', round(pdf$E.ql, 4), ', ', round(pdf$E.qu, 4), ']', sep = ''), col = 'darkorange', cex = 2)
}

# plot uniform curve----
pdf_between <- function(lower, upper, p.lower = 0, p.upper = 0.025){
    d = abs(upper - lower)
    h.poss <- (1 - p.lower - p.upper) / d
    l.bound <- ifelse(p.lower == 0, '(hard)', paste('(',p.lower,')',sep = ''))
    u.bound <- ifelse(p.upper == 0, '(hard)', paste('(',p.upper,')',sep = ''))
    mod <- paste('B(', lower, ',', upper, ',', ifelse(p.lower == 0,'1e-300',p.lower), ',', ifelse(p.upper == 0,'1e-300',p.upper), ')', sep = '')
    return(list(lower=lower, upper=upper, p.lower=p.lower, p.upper=p.upper, h.poss=h.poss, l.bound=l.bound, u.bound=u.bound, mod=mod))
}

plot.between <- function(pdf, hmin, hmax, TitlePrefix='', last=F){
    par(mar = c(ifelse(last,5,2),5,4,2)+0.1)
    plot(NULL, xlim=c(hmin, hmax), ylim=c(0, pdf$h.poss* 1.2), xaxt = ifelse(last, 's', 'n'), xlab = ifelse(last,'100 Ma',''), ylab = ifelse(last, 'Probability Density',''), cex = 2, cex.axis = 2, cex.lab = 2)
    title(main=paste(TitlePrefix, 'Uniform Distribution:\n(', pdf$lower, pdf$l.bound, '-', pdf$upper, pdf$u.bound, ')'), cex = 2)
    segments(x0=pdf$lower, y0=pdf$h.poss, x1=pdf$upper, col = 'red', lwd = 4)
    segments(x0=pdf$lower, y0=0, y1=pdf$h.poss, col = 'red', lwd = 4, lty = ifelse(pdf$p.lower == 0, 1, 4))
    segments(x0=pdf$upper, y0=pdf$h.poss, y1=0, col = 'red', lwd = 4, lty = ifelse(pdf$p.upper == 0, 1, 4))
    hleg <- mean(c(pdf$lower,pdf$ upper))
    text(x = hleg, y = pdf$h.poss * 0.90, adj = c(0.5,0.5), labels = pdf$mod, col = 'gray25', cex = 2)
}

FinalPlot <- function(lower.cali=NA, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord= 1){
    pl0 <- ifelse(is.na(relax.lower), 0, relax.lower)
    if (is.na(upper.cali)){
        # strategy 1
        pdf1 <- pdf_tcauchy(tl = lower.cali, p = 0.1, c = 0.2, pl = pl0)
        # strategy 2
        pdf2 <- pdf_skewt(xi = lower.cali, ql = lower.cali, qu = pdf1$E.qu, pl = pl0, pu = 0.025, single.end = T)
        # strategy 3
        pdf3 <- pdf_tcauchy(tl = lower.cali, p = 0.5, c = 0.2, pl = pl0)
        # strategy 4
        pdf4 <- pdf_skewt(xi = lower.cali * 1.5, ql = lower.cali, qu = pdf3$E.qu, pl = ifelse(is.na(relax.lower), 0.001, max(relax.lower, 0.001)), pu = 0.025, single.end = T)
        # calculate x-axis limits
        hrange <- range(c(lower.cali, pdf1$q01, pdf1$q99, pdf1$E.ql, pdf1$E.qu, pdf1$hpdi, pdf2$q01, pdf2$q99, pdf2$E.ql, pdf2$E.qu, pdf2$hpdi, pdf3$q01, pdf3$q99, pdf3$E.ql, pdf3$E.qu, pdf3$hpdi, pdf4$q01, pdf4$q99, pdf4$E.ql, pdf4$E.qu, pdf4$hpdi))
        ehmin <- hrange[1] - 0.1 * diff(hrange)
        ehmax <- hrange[2] + 0.1 * diff(hrange)
        
        # plot
        svg(filename = paste('./',ord,'.PriorDensity.CST.1-4.svg', sep = ''), width = 12, height = 16)
        layout(matrix(1:4,4,1))
        plot.tcauchy(pdf1, hmin = ehmin, hmax = ehmax, TitlePrefix = 'Strategy 1: ', last = F)
        plot.skewt(pdf2, hmin = ehmin, hmax = ehmax, TitlePrefix = 'Strategy 2: ', last = F)
        plot.tcauchy(pdf3, hmin = ehmin, hmax = ehmax, TitlePrefix = 'Strategy 3: ', last = F)
        plot.skewt(pdf4, hmin = ehmin, hmax = ehmax, TitlePrefix = 'Strategy 4: ', last = T)
        dev.off()
        
        # write table
        if (output.table) {
            TAB <- data.frame(CaliNum = rep(ord, 4),
                          Strategy = paste('CST', 1:4), 
                          Minima = rep(lower.cali, 4), 
                          Maxima = rep(upper.cali, 4), 
                          Quantile.l = c(pdf1$ql, pdf2$ql, pdf3$ql, pdf4$ql),
                          Viol.Prob.l = c(pdf1$pl, pdf2$pl, pdf3$pl, pdf4$pl),
                          Quantile.u = c(pdf1$qu, pdf2$qu, pdf3$qu, pdf4$qu),
                          Viol.Prob.u = c(pdf1$pu, pdf2$pu, pdf3$pu, pdf4$pu),
                          Formula = c(pdf1$mod, pdf2$mod, pdf3$mod, pdf4$mod), 
                          PTI.l = round(c(pdf1$E.ql, pdf2$E.ql, pdf3$E.ql, pdf4$E.ql), 4), 
                          PTI.u = round(c(pdf1$E.qu, pdf2$E.qu, pdf3$E.qu, pdf4$E.qu), 4), 
                          HDI95.l = round(c(pdf1$hpdi[1], pdf2$hpdi[1], pdf3$hpdi[1], pdf4$hpdi[1]), 4), 
                          HDI95.u = round(c(pdf1$hpdi[2], pdf2$hpdi[2], pdf3$hpdi[2], pdf4$hpdi[2]), 4),
                          PeakPos = round(c(pdf1$pmax, pdf2$pmax, pdf3$pmax, pdf4$pmax), 4))
            if (append.table){
                write.table(TAB, file = paste('./AllPriorDensityDistribution.CST.1-4.csv', sep = ''), sep = ",", na = "", col.names = ifelse(ord==1,TRUE,FALSE), row.names = FALSE, append = ifelse(ord==1,FALSE,TRUE))
            }else{
                write.table(TAB, file = paste('./',ord,'.PriorDensityDistribution.CST.1-4.csv', sep = ''), sep = ",", na = "", col.names = TRUE, row.names = FALSE, append = F)
            }
        }
    }else{
        # strategy 1
        pdf1 <- pdf_between(lower = lower.cali, upper = upper.cali, p.lower = pl0, p.upper = 0.025)
        # strategy 2
        pdf2 <- pdf_skewt(xi = lower.cali, ql = lower.cali, qu = upper.cali, pl = pl0, pu = 0.025, single.end = F)
        # strategy 3
        pdf3 <- pdf_skewt(xi = mean(c(lower.cali, upper.cali)), ql = lower.cali, qu = upper.cali, pl = ifelse(is.na(relax.lower), 0.00001, max(relax.lower, 0.001)), pu = 0.025, single.end = F)
        # strategy 4
        pdf4 <- pdf_skewt(xi = mean(c(lower.cali, upper.cali)), ql = lower.cali, qu = upper.cali, pl = ifelse(is.na(relax.lower), 0.001, max(relax.lower, 0.001)), pu = 0.025, single.end = F)
        # calculate x-axis limits
        hrange <- range(c(lower.cali, upper.cali, pdf2$q01, pdf2$q99, pdf2$E.ql, pdf2$E.qu, pdf2$hpdi, pdf3$q01, pdf3$q99, pdf3$E.ql, pdf3$E.qu, pdf3$hpdi, pdf4$q01, pdf4$q99, pdf4$E.ql, pdf4$E.qu, pdf4$hpdi))
        ehmin <- hrange[1] - 0.1 * diff(hrange)
        ehmax <- hrange[2] + 0.1 * diff(hrange)
        
        # plot
        svg(filename = paste('./',ord,'.PriorDensity.CST.1-4.svg', sep = ''), width = 12, height = 16)
        layout(matrix(1:4,4,1))
        plot.between(pdf1, hmin = ehmin, hmax = ehmax, TitlePrefix = 'Strategy 1: ', last = F)
        plot.skewt(pdf2, hmin = ehmin, hmax = ehmax, TitlePrefix = 'Strategy 2: ', last = F)
        plot.skewt(pdf3, hmin = ehmin, hmax = ehmax, TitlePrefix = 'Strategy 3: ', last = F)
        plot.skewt(pdf4, hmin = ehmin, hmax = ehmax, TitlePrefix = 'Strategy 4: ', last = T)
        dev.off()
        
        # write table
        if (output.table) {
        TAB <- data.frame(CaliNum = rep(ord, 4),
                          Strategy = paste('CST', 1:4), 
                          Minima = rep(lower.cali,4), 
                          Maxima = rep(upper.cali,4), 
                          Quantile.l = c(lower.cali,pdf2$ql,pdf3$ql,pdf4$ql),
                          Viol.Prob.l = c(pdf1$p.lower,pdf2$pl,pdf3$pl,pdf4$pl),
                          Quantile.u = c(upper.cali,pdf2$qu,pdf3$qu,pdf4$qu),
                          Viol.Prob.u = c(pdf1$p.upper,pdf2$pu,pdf3$pu,pdf4$pu),
                          Formula = c(pdf1$mod,pdf2$mod,pdf3$mod,pdf4$mod), 
                          PTI.l = round(c(pdf1$lower,pdf2$E.ql,pdf3$E.ql,pdf4$E.ql), 4), 
                          PTI.u = round(c(pdf1$upper,pdf2$E.qu,pdf3$E.qu,pdf4$E.qu), 4), 
                          HDI95.l = round(c(NA,pdf2$hpdi[1],pdf3$hpdi[1],pdf4$hpdi[1]), 4), 
                          HDI95.u = round(c(NA,pdf2$hpdi[2],pdf3$hpdi[2],pdf4$hpdi[2]), 4),
                          PeakPos = round(c(NA,pdf2$pmax,pdf3$pmax,pdf4$pmax), 4))
            if (append.table){
                write.table(TAB, file = paste('./AllPriorDensityDistribution.CST.1-4.csv', sep = ''), sep = ",", na = "", col.names = ifelse(ord==1,TRUE,FALSE), row.names = FALSE, append = ifelse(ord==1,FALSE,TRUE))
            }else{
                write.table(TAB, file = paste('./',ord,'.PriorDensityDistribution.CST.1-4.csv', sep = ''), sep = ",", na = "", col.names = TRUE, row.names = FALSE, append = F)
            }
        }
    }
}

## translate uniform to gamma----
# 1. B(5.7351,6.09,1e-300,0.025)
FinalPlot(lower.cali=5.7351, upper.cali=6.09, relax.lower=NA, output.table=T, append.table = T, ord=1)

# 2. B(5.7351,6.3497,1e-300,0.025)
FinalPlot(lower.cali=5.7351, upper.cali=6.3497, relax.lower=NA, output.table=T, append.table = T, ord=2)

# 3. B(5.7351,5.908,1e-300,0.025)
FinalPlot(lower.cali=5.7351, upper.cali=5.908, relax.lower=NA, output.table=T, append.table = T, ord=3)

# 4. B(5.5025,6.09,1e-300,0.025)
FinalPlot(lower.cali=5.5025, upper.cali=6.09, relax.lower=NA, output.table=T, append.table = T, ord=4)

# 5. L(2.591,0.1,0.2,1e-300)
FinalPlot(lower.cali=2.591, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=5)

# 6. B(5.2882,5.908,1e-300,0.025)
FinalPlot(lower.cali=5.2882, upper.cali=5.908, relax.lower=NA, output.table=T, append.table = T, ord=6)

# 7. B(5.14,5.908,1e-300,0.025)
FinalPlot(lower.cali=5.14, upper.cali=5.908, relax.lower=NA, output.table=T, append.table = T, ord=7)

# 8. B(4.443,5.4209,1e-300,0.025)
FinalPlot(lower.cali=4.443, upper.cali=5.4209, relax.lower=NA, output.table=T, append.table = T, ord=8)

# 9. L(0.9817,0.1,0.2,1e-300)
FinalPlot(lower.cali=0.9817, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=9)

# 10. L(4.054,0.1,0.2,1e-300)
FinalPlot(lower.cali=4.054, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=10)

# 11. L(0.9415,0.1,0.2,1e-300)
FinalPlot(lower.cali=0.9415, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=11)

# 12. L(1.202,0.1,0.2,1e-300)
FinalPlot(lower.cali=1.202, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=12)

# 13. L(1.202,0.1,0.2,0.025)
FinalPlot(lower.cali=1.202, upper.cali=NA, relax.lower=0.025, output.table=T, append.table = T, ord=13)

# 14. L(1.983,0.1,0.2,1e-300)
FinalPlot(lower.cali=1.983, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=14)

# 15. L(0.347,0.1,0.2,1e-300)
FinalPlot(lower.cali=0.347, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=15)

# 16. L(2.355,0.1,0.2,1e-300)
FinalPlot(lower.cali=2.355, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=16)

# 17. L(0.1762,0.1,0.2,1e-300)
FinalPlot(lower.cali=0.1762, upper.cali=NA, relax.lower=NA, output.table=T, append.table = T, ord=17)

# dev.off()
