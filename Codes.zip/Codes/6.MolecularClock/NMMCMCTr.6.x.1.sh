#!/usr/bin/bash
#SBATCH --job-name=NMTmTr1
#SBATCH --partition=cpu
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1

#module load paml/4.10.7
MCMCTREE=/share/home/clc24a1001/apps/paml-master/bin/mcmctree
#BASEML=/sw/apps/paml4.9i/bin/baseml
CODEML=/share/home/clc24a1001/apps/paml-master/bin/codeml

DIR_rt=$(pwd)
cd $DIR_rt 

TreCali=$1 
Part=$2
Clock=$3 
Rgene=$4
stopgen=3000000

mkdir -p $DIR_rt/${TreCali}.${Part}.${Clock}.rg${Rgene} && 
DIR_cur=$DIR_rt/${TreCali}.${Part}.${Clock}.rg${Rgene}
cd $DIR_cur
nruns=4 # number of runs

# MCMCtree step 1: Generate a in.BV file
if [[ ! -f $DIR_cur/DIR_BV/in.BV ]] || [[ $(grep -o 'Hessian' $DIR_cur/DIR_BV/in.BV | wc -l) -ne ${Part:0:1} ]] 
then 
    cd $DIR_cur && 
    [[ -d $DIR_cur/DIR_BV ]] && rm -rf $DIR_cur/DIR_BV 
	mkdir $DIR_cur/DIR_BV && 
    cd $DIR_cur/DIR_BV && 
    cp $DIR_rt/mcmctree.ctl ./ 

    sed -i "s#seqfile = seq.phy#seqfile = $DIR_rt/Nema.TBDL.nom.rmsp.${Part}.phy#g" mcmctree.ctl 
    sed -i "s#treefile = input.tre#treefile = $DIR_rt/Nema.${TreCali}.tre#g" mcmctree.ctl 
    
    # if [[ $TreCali == 'CST3' ]]
    # then
    #     sed -i "s#RootAge =#RootAge = 6.09#g" mcmctree.ctl
    # fi

    if [[ $Part == '5P' ]]
    then
        sed -i "s#ndata = 1#ndata = 5#g" mcmctree.ctl
    fi

    if [[ $Clock == 'IR' ]]
    then
        sed -i "s#clock = #&2#g" mcmctree.ctl
    elif [[ $Clock == 'AR' ]]
    then
        sed -i "s#clock = #&3#g" mcmctree.ctl
    fi

    sed -i "s#rgene_gamma = 2 x#rgene_gamma = 2 ${Rgene}#g" mcmctree.ctl

    echo -e "#######################\nMCMCTREE STEP 1 start...\n$(date)\n#######################\n\n" > step1_log.text && 
    echo -e "JOB NAME: $SLURM_JOB_NAME\nJob ID: $SLURM_JOBID\nAllocate Nodes: $SLURM_JOB_NODELIST\n" >> step1_log.text && 

    $MCMCTREE mcmctree.ctl >> step1_log.text 2>&1

    cp $DIR_rt/lg.dat ./
    
    for file in tmp*ctl 
    do 
        sed -i "s/model = 0/model = 2/g" $file
        sed -i "s/aaRatefile = /aaRatefile = lg.dat/g" $file
        sed -i "s/method = 0/method = 1/g" $file
        echo -e "fix_alpha = 0\nalpha = 0.5\nncatG = 4" >> $file
    done
    
    for file in tmp*ctl 
    do 
        $CODEML $file && 

        # Test large branch length 
        # while [[ $(sed -n '6p' rst2 | awk '{for (i=1; i<=NF; i++) if ($i >= 20) {print "True"; exit}}') == 'True' ]] 
        # do 
        #     $CODEML $file
        # done 
		
        # in case there are any single spaces between numbers, which will lead to errors in the subsequent steps 
        sed -i '6s/[[:space:]]\{1,\}/  /g' rst2 && 
		sed -i '6s/[[:space:]]\{3,\}/  /g' rst2 && 
		
        cat rst2 >> in.BV
    done

fi 

# Run MCMCtree step 2 script
for ((R=1;R<=$nruns;R++))
do
    cd $DIR_rt 
    if [[ ! -f $DIR_cur/DIR_DIV/run$R/FigTree.tre ]] || [[ ! -f $DIR_cur/DIR_PRD/run$R/FigTree.tre ]] || [[ $(awk 'END{print $1}' $DIR_cur/DIR_DIV/run$R/mcmc.txt) -lt $stopgen ]] || [[ $(awk 'END{print $1}' $DIR_cur/DIR_PRD/run$R/mcmc.txt) -lt $stopgen ]]
    then 
        sbatch ./NMMCMCTr.6.x.2.sh $TreCali $Part $Clock $Rgene $R 
    fi 
done

exit 
