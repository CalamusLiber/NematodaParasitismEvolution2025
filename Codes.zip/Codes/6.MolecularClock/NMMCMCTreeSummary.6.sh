#!/bin/bash

DIR_rt=$(pwd)
cd $DIR_rt

TreeCalibration=$(ls *.tre | sed "s#\/##g;s#Nema.##g;s#.tre##g")
Partition='5P'
ClockModel='IR'
rgene_gamma='15'

# Run SumMCMCtree.py
for TreCali in $TreeCalibration
do 
    for Part in $Partition 
    do
        for Clock in $ClockModel
        do 
            for Rgene in $rgene_gamma
            do 
                DIR_cur=$DIR_rt/${TreCali}.${Part}.${Clock}.rg${Rgene}
                cd $DIR_cur
                if [ $(find . -type f -name "*MCMCtree_final_report.txt" | wc -l) -lt 1 -a $(find . -type f -name FigTree.tre | wc -l) -eq 8 -a $(find . -type f -name mcmc.txt | wc -l) -eq 8 ] 
                then 
                    cp $DIR_rt/SumMCMCtree.py .
                    chmod -R 777 ./SumMCMCtree.py
                    px=$(echo $DIR_cur | sed -s "s#/share/home/clc24a1001/#NMtimetree_#g;s#\/#.#g")
                    sbatch ./SumMCMCtree.py --postdir $DIR_cur/DIR_DIV --priodir $DIR_cur/DIR_PRD --classification $DIR_rt/Classification.xlsx --tipcolor $DIR_rt/tipcolors.xlsx --prefix $px --burnin 50000 --select_chains --good_ess 100 --rm_mcmc none 
                fi 
            done
        done
    done
done

