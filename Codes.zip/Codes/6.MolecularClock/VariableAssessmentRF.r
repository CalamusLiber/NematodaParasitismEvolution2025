## Loading libraries----
library(randomForest);library(tidyverse);library(DataExplorer);library(pROC);library(shapr);library(iml);library(caret);library(DiagrammeR);library(kernelshap);library(shapviz);library(treeshap)

# defining a new method implementing tuning of 'ntree' in lieu of 'rf' method
rf2p <- list(type = "Classification", library = "randomForest", loop = NULL,
                 parameters = data.frame(parameter = c("mtry", "ntree"), 
                                         class = rep("numeric", 2), 
                                         label = c("mtry", "ntree")),
                 grid = function(x, y, len = NULL, search = "grid") {
                     if(search == "grid") {
                         out <- expand.grid(mtry = caret::var_seq(p = ncol(x),
                                                                  classification = is.factor(y),
                                                                  len = len),
                                            ntree = c(500,600,700,800,900,1000,1500,2000))
                     } else {
                         out <- data.frame(mtry = unique(sample(1:ncol(x), size = len, replace = TRUE)),
                                           ntree = unique(sample(c(500,600,700,800,900,1000,1500,2000), 
                                                                 size = len, replace = TRUE)))
                     }
                 },
                 fit = function(x, y, wts, param, lev, last, weights, classProbs, ...) {
                     randomForest(x, y, mtry = param$mtry, ntree=param$ntree, ...)
                 },
                 predict = function(modelFit, newdata, preProc = NULL, submodels = NULL)
                     predict(modelFit, newdata),
                 prob = function(modelFit, newdata, preProc = NULL, submodels = NULL)
                     predict(modelFit, newdata, type = "prob"),
                 sort = function(x) x[order(x[,1]),],
                 levels = function(x) x$classes
)

## Factors that determine the convergence (Random Forest classification)----
# selecting Good/Bad-convergence cases from original dataset----
# Dataset Partitioning
set.seed(20230906)
RF.Data2 <- cbind(cvg=factor(mcmc.dump.bin[,1]), mcmc.dump.bin[,-1])

# tuning
fitControl <- trainControl(method = "repeatedcv", 
                           number = 10,
                           repeats = 3,
                           p = 0.8, 
                           verboseIter = FALSE,
                           search = "random" # 随机搜索，也可设定 "grid" 
)
caret_rf2 <- train(cvg ~ . ,
                   data = RF.Data2,
                   method = rf2p, # custom rf (rf2p)
                   trainControl=fitControl
)

# model training
sink(file = 'RF-model-2-class-training-logging.txt')
RF_mod2 <- randomForest(cvg ~ . , 
                        data = RF.Data2,
                        ntree = caret_rf2$bestTune$ntree, 
                        mtry = caret_rf2$bestTune$mtry, 
                        importance = TRUE)
RF_mod2
sink()

# variable importance
sink(file = 'RF-model-2-class-variable-importance.txt')
(VarImp <- importance(RF_mod2))
sink()

pdf(file = 'RF-model-2-class-variable-importance.pdf', width = 8, height = 16, bg = 'white', pointsize = 12)
varImpPlot(RF_mod2, main = 'RF model 2-class Variable Importance')
dev.off()

# prediction
RF_pred2 <- data.frame(Prob=predict(RF_mod2, newdata = RF.Data2[, -1]))

# ROC
train_roc2 <- roc(response = RF.Data2[, 1],
                  predictor = as.numeric(RF_pred2[,1])-1)
# Area under the curve: 0.9844
bestp <- train_roc2$thresholds[which.max(train_roc2$sensitivities+train_roc2$specificities-1)]
RF_pred2$Conv <- factor(ifelse(as.numeric(RF_pred2$Prob)-1 > bestp, 'G', 'B'))

pdf(file = 'RF-model-2-class-ROC-curve.pdf', width = 8, height = 8, bg = 'white', pointsize = 12)
plot(train_roc2, print.auc = T, auc.polygon = T, grid = T, max.auc.polygon = T, auc.polygon.col = 'skyblue', print.thres = T, legacy.axes = T, bty = 'l')
dev.off()

# confusion matrix
sink(file = 'RF-model-2-class-Confusion-Matrix.txt')
confusionMatrix(data = RF_pred2$Conv, 
                reference = factor(mcmc.dump[, 1]), 
                positive = 'G', 
                mode = 'everything')
sink()

# summary
sink(file = 'RF-model-2-class-Binary-Summary.txt')
defaultSummary(
    data.frame(obs = factor(mcmc.dump[, 1]), 
               pred = RF_pred2$Conv),
    lev = levels(factor(mcmc.dump[, 1]))
)
sink()

## Factors that determine the time estimation grouping (Random Forest classification)----
# selecting 5-grouped cases from original dataset----
# Dataset Partitioning
set.seed(20230906)
RF.Data5 <- cbind(grp=factor(pca_group[pca_group > 0]-1), mcmc.dump.bin[pca_group > 0, -1:-2])

# tuning
fitControl <- trainControl(method = "repeatedcv", 
                           number = 10,
                           repeats = 3,
                           p = 0.8, 
                           verboseIter = FALSE,
                           search = "random" # 随机搜索，也可设定 "grid" 
)
caret_rf5 <- train(grp ~ . ,
                   data = RF.Data5,
                   method = rf2p, # custom rf (rf2p)
                   trainControl=fitControl
)

# model training
sink(file = 'RF-model-5-class-training-logging.txt')
RF_mod5 <- randomForest(grp ~ . ,
                        data = RF.Data5,
                        ntree = caret_rf5$bestTune$ntree, 
                        mtry = caret_rf5$bestTune$mtry, 
                        importance = TRUE)
RF_mod5
sink()

# variable importance
sink(file = 'RF-model-5-class-variable-importance-Gain.txt')
(VarImp <- importance(model=RF_mod5))
sink()

pdf(file = 'RF-model-5-class-variable-importance-Gain.pdf', width = 8, height = 16, bg = 'white', pointsize = 12)
varImpPlot(RF_mod5, main = 'RF model 5-class Variable Importance')
dev.off()

# prediction
RF_pred5 <- as.data.frame(matrix(predict(RF_mod5, newdata = RF.Data5), ncol = 5, byrow = T))
colnames(RF_pred5) <- as.character(1:5)
RF_pred5$Grp <- factor(apply(RF_pred5, 1, which.max))

# ROC
multiclass.roc(response = RF.Data5[,1],
               predictor = RF_pred5[,-ncol(RF_pred5)])
# Multi-class area under the curve: 1

# confusion matrix
sink(file = 'RF-model-5-class-Confusion-Matrix.txt')
confusionMatrix(data = RF_pred5$Grp, 
                reference = factor(pca_group[pca_group > 0][RF_train5]), 
                mode = 'everything')
sink()

# summary
sink(file = 'RF-model-5-class-MultiClass-Summary.txt')
multiClassSummary(
    data.frame(obs = factor(pca_group[pca_group > 0][RF_train5]), 
               pred = RF_pred5$Grp),
    lev = levels(factor(pca_group[pca_group > 0][RF_train5]))
)
sink()

# plot trees
# xgb.plot.tree(model = RF_mod5, trees = 1:5, plot_width = 1000, plot_height = 1000)




