#!/usr/bin/bash

DIR_cur=$(pwd)
cd $DIR_cur

TreeCalibration=$(ls *.tre | sed "s#\/##g;s#Nema.##g;s#.tre##g")
Partition='5P'
ClockModel='IR'
rgene_gamma='15'

# Run MCMCtree step 1 script
for TreCali in $TreeCalibration
do 
    for Part in $Partition 
    do
        for Clock in $ClockModel
        do 
            for Rgene in $rgene_gamma
            do 
                if [ ! -f $DIR_cur/${TreCali}.${Part}.${Clock}.rg${Rgene}/*MCMCtree_final_report.txt ] 
                then 
                    sbatch $DIR_cur/NMMCMCTr.6.x.1.sh $TreCali $Part $Clock $Rgene 
                fi
            done
        done
    done
done
