## Summarize Sensitivity Analysis----
# Loading libraries----
library(ape)
library(ggtree)
library(treeio)
library(grid)
library(ggalt)

## Setting directory and loading image----
# setwd('H:/BristolProjects/Nematoda/timing/AllPosteriorTimeTree.C60.PMSF')
# setwd('F:/Nematoda/timing/20231106/CalibrSensitivityAnalysis/FinalTimeTrees')
setwd('/mnt/hdd2/Nematoda/timing/20241203/CalibrSensitivityAnalysis/FinalTimeTrees')
load('/mnt/hdd2/Nematoda/timing/20241203/SensAna.RData')
# save.image('SensAna.RData')

# function----
# print figure
ColorX <- c('#cc8cbc','#95a7a4','#948f6c','#609c70','#f05d4a','#aedbe1','#90447c','#002468','#194f1d','#5d1d07','#edc720','#dccaa8','#b59af2','#b56710','#dc6626','#42e476','#d0aca2','#6fc8d8','#a68a8d','#32a04d','#d7c1c0','#9d0000','#7c664e','#1d4d66','#8b4c39','#2982a2','#ba8547','#846671','#5f6b6b','#584f31','#4525b1','#cdcd00','#c4bda5','#ebd261','#ac9f77','#627f89','#9d5d8c','#aea88f','#146d1e','#71542b','#bfbfb4','#8b7a50','#1cbcd5','#bab590','#553e2d','#92310f','#00868b','#591618','#978466','#a4915c','#e29873','#36648b','#693e5a','#327570','#8c571b','#ba6452','#a787a1','#b5a49e','#ba3000','#646d4f','#d21111','#7c9d9e','#3c3520','#be9e1e','#c380d9','#579261','#90988e','#7f7f66','#ffdcca','#917a63','#b6cd2b','#bda683') 

EdgeColors <- function(tree, cat){
    tips <- tree$tip.label
    Colors <- rep('black', nrow(tree$edge))
    CAT0 <- cbind(ColorX[1:length(unique(cat))], unique(cat))
    rownames(CAT0) <- unique(cat)
    cat <- cat[tips]
    CAT0 <- CAT0[unique(cat), ]
    CAT1 <- NULL
    for (i in 1:nrow(CAT0)){
        xxx <- which(cat==CAT0[i,2])
        icat <- c(1, which(diff(xxx) > 1) + 1)
        if (length(icat) > 1){
            newcat <- paste(CAT0[i,2], '(', as.character(1:length(icat)), ')', sep = '')
            CAT1 <- rbind(CAT1, cbind(CAT0[i,1], newcat))
            for (j in 1:length(icat)){
                cat[xxx[icat[j]:length(xxx)]] <- newcat[j]
            }
        }else{
            CAT1 <- rbind(CAT1, cbind(CAT0[i,1], CAT0[i,2]))
        }
    }
    SppYPos <- node.height(tree)[1:length(tips)]
    names(SppYPos) <- tips
    ncat1 <- nrow(CAT1)
    BarTxtPos <- data.frame(by0 = rep(NA, nrow = ncat1),
                            by1 = rep(NA, nrow = ncat1),
                            ty = rep(NA, nrow = ncat1),
                            btc = rep('black', nrow = ncat1))
    m <- mrca(tree)
    for (i in 1:ncat1){
        ed <- unique(as.vector(m[tips[cat==CAT1[i,2]],tips[cat==CAT1[i,2]]]))
        Colors[tree$edge[,2] %in% ed] <- CAT1[i,1]
        BarTxtPos[i,4] <- CAT1[i,1]
        BarTxtPos[i,3] <- max(SppYPos[tips[cat==CAT1[i,2]]]) 
        BarTxtPos[i,2] <- BarTxtPos[i,3] + 0.1
        BarTxtPos[i,1] <- min(SppYPos[tips[cat==CAT1[i,2]]]) - 0.1
    }
    return(list(Colors, BarTxtPos, CAT0, CAT1[,2]))
}

## Reading data----
Classification <- read.csv('/mnt/hdd2/Nematoda/timing/20241203/Classification.csv', header = T, row.names = 1)
ClassLong <- c(Classification[1:28,'Phylum'],Classification[-(1:28),'Order'])
ClassShort <- c(Classification[1:28,'Phylum'],Classification[-(1:28),'Clade'])
names(ClassLong) <- names(ClassShort) <- row.names(Classification)
safiles <- dir(getwd())
satreefiles <- safiles[grep("^NMtimetree[A-Za-z0-9_\\.]*\\.tre", safiles)]
satreefiles <- satreefiles[c(5,7,9,11,6,8,10,12,1:4,13:20)]

SATrees <- NULL
mcmc.sa <- data.frame(matrix(NA,nrow = length(satreefiles),ncol = 7))
colnames(mcmc.sa) <- c('cvg','mod','cst','fp','part','corr','rg')
mcmc.sa$cvg <- rep(NA,length(satreefiles))
BrTime <- matrix(NA,nrow = length(satreefiles), ncol = 184)

for (i in 1:length(satreefiles)){
    tre <- read.beast(satreefiles[i])
    nm <- strsplit(substr(satreefiles[i], nchar('NMtimetree_CalibrSensitivityAnalysis.')+1, nchar(satreefiles[i])-4), '_combined_time_tree_')[[1]]
    xxx <- strsplit(nm[1], '[.]')[[1]]
    mcmc.sa[i,] <- c(ifelse(nm[2]=='good','G','B'),
                  xxx[1],
                  substr(xxx[2],4,4),
                  toupper(gsub('CST[1-4]','',xxx[2])),
                  toupper(xxx[3]),
                  toupper(xxx[4]),
                  gsub('rg','',xxx[5]))
    BrTime[i,] <- branching.times(tre@phylo)
    SATrees[[i]] <- tre
}
mcmc.sa[mcmc.sa[,4]=='',4] <- '0'

MaxBrTimeCompan_SA <- unlist(lapply(SATrees, function(x){max(branching.times(x@phylo))}))
MaxBrTimeCompan_SA <- max(MaxBrTimeCompan_SA)-MaxBrTimeCompan_SA

# writing results----

setwd('/mnt/hdd2/Nematoda/timing/20241203/Res_posttrees')

svg(filename = './SA_TimeTrees.svg', width = 40, height = 200, pointsize = 12)
layout(mat = matrix(c(1:length(SATrees)),nrow = length(SATrees)))
for (i in 1:length(SATrees)){
    lad.tree <- ladderize(SATrees[[i]]@phylo, right = T)
    # lad.tree <- SATrees[[i]]@phylo
    # if (i == 1){
        EdgeBarTxtColors <- EdgeColors(lad.tree, ClassShort)
    # }
    nodebar_pos <- max(branching.times(lad.tree)) - Reduce(rbind, SATrees[[i]]@data$`0.95HPD`[order(as.numeric(SATrees[[i]]@data$node))])
    nodebar_pos <- cbind(nodebar_pos, node.height(lad.tree)[-c(1:(Ntip(lad.tree)+1))])
    # avgnodes <- SATrees[[i]]@data[order(as.numeric(SATrees[[i]]@data$node)),c('MU','EPSILON')]
    
    plot(lad.tree, edge.color = EdgeBarTxtColors[[1]], show.tip.label = FALSE, x.lim = c(0,750)-MaxBrTimeCompan_SA[i], main = paste('Sensitivity Analysis Time Tree ', as.character(i), ': ', SATrees[[i]]@file, sep = ''), cex.main = 3, edge.width = 4)
    abline(v=max(branching.times(lad.tree))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
    abline(v=max(branching.times(lad.tree))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
    segments(x0=nodebar_pos[,1], y0=nodebar_pos[,3], x1=nodebar_pos[,2], y1=nodebar_pos[,3], lwd = 4, col = 'royalblue', lend = 'butt')
    # points(x=max(branching.times(lad.tree)) - avgnodes$MU, y=nodebar_pos[,3], pch = 18, cex = 3, col = ifelse(branching.times(lad.tree)[-1] >= avgnodes$MU, 'blue','orange'))
    nodelabels(node = as.numeric(unlist(strsplit(lad.tree$node.label[grep('@',lad.tree$node.label)], '@'))) + ifelse(is.rooted(lad.tree), 1, 0), frame = 'none', pch = 8, adj = c(1.5,1), cex = 3)
    segments(x0 = max(branching.times(lad.tree)) + 7, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree)) + 7, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 8, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
    text(x = max(branching.times(lad.tree)) + 14, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 3, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
    rect(max(branching.times(lad.tree))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 185, max(branching.times(lad.tree))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 191, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
    text(x=max(branching.times(lad.tree))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
    if (i == length(SATrees)){
        axisPhylo(cex.axis=3, lwd = 3, padj = 1)
        mtext('Ma', side=1, at = 640, cex = 2, padj = 1.7)
        legend(x = 'bottomleft', legend = c('Calibrated nodes', EdgeBarTxtColors[[3]][,2]), pch = c(8, rep(15, nrow(EdgeBarTxtColors[[3]]))), col = c('black', EdgeBarTxtColors[[3]][,1]), text.col = c('black', EdgeBarTxtColors[[3]][,1]), cex = 2.5, bg = 'white', box.lwd =3)
    }
}
dev.off()

svg(filename = './SA_TimeTrees_simple.svg', width = 40, height = 8*length(SATrees), pointsize = 12)
layout(mat = matrix(c(1:length(SATrees)),nrow = length(SATrees)))
for (i in 1:length(SATrees)){
    lad.tree <- ladderize(SATrees[[i]]@phylo, right = T)
    EdgeBarTxtColors <- EdgeColors(lad.tree, ClassShort)
    plot(lad.tree, edge.color = EdgeBarTxtColors[[1]], show.tip.label = FALSE, x.lim = c(0,750)-MaxBrTimeCompan_SA[i], main = paste('Sensitivity Analysis Time Tree ', as.character(i), ': ', SATrees[[i]]@file, sep = ''), cex.main = 3, edge.width = 4)
    abline(v=max(branching.times(lad.tree))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
    abline(v=max(branching.times(lad.tree))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
    segments(x0 = max(branching.times(lad.tree)) + 7, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree)) + 7, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 8, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
    text(x = max(branching.times(lad.tree)) + 14, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 3, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
    rect(max(branching.times(lad.tree))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 185, max(branching.times(lad.tree))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 191, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
    text(x=max(branching.times(lad.tree))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
    if (i == length(SATrees)){
        axisPhylo(cex.axis=3, lwd = 3, padj = 1)
        mtext('Ma', side=1, at = 640, cex = 2, padj = 1.7)
        legend(x = 'bottomleft', legend = EdgeBarTxtColors[[3]][,2], pch = rep(15, nrow(EdgeBarTxtColors[[3]])), col = EdgeBarTxtColors[[3]][,1], text.col = EdgeBarTxtColors[[3]][,1], cex = 2.5, bg = 'white', box.lwd =3)
    }
}
dev.off()

svg(filename = './SA_TimeTrees_2C.svg', width = 80, height = 200, pointsize = 12)
layout(mat = matrix(c(1:length(SATrees)), ncol = 2, nrow = length(SATrees)/2, byrow = T))
for (i in 1:length(SATrees)){
    lad.tree <- ladderize(SATrees[[i]]@phylo, right = T)
    # lad.tree <- SATrees[[i]]@phylo
    # if (! i %in% c(6, 7, 8)){
        EdgeBarTxtColors <- EdgeColors(lad.tree, ClassShort)
    # }
    nodebar_pos <- max(branching.times(lad.tree)) - Reduce(rbind, SATrees[[i]]@data$`0.95HPD`[order(as.numeric(SATrees[[i]]@data$node))])
    nodebar_pos <- cbind(nodebar_pos, node.height(lad.tree)[-c(1:(Ntip(lad.tree)+1))])
    # avgnodes <- SATrees[[i]]@data[order(as.numeric(SATrees[[i]]@data$node)),c('MU','EPSILON')]
    
    plot(lad.tree, edge.color = EdgeBarTxtColors[[1]], show.tip.label = FALSE, x.lim = c(0,750)-MaxBrTimeCompan_SA[i], main = paste('Sensitivity Analysis Time Tree ', as.character(i), ': ', SATrees[[i]]@file, sep = ''), cex.main = 3, edge.width = 4)
    abline(v=max(branching.times(lad.tree))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
    abline(v=max(branching.times(lad.tree))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
    segments(x0=nodebar_pos[,1], y0=nodebar_pos[,3], x1=nodebar_pos[,2], y1=nodebar_pos[,3], lwd = 4, col = 'royalblue', lend = 'butt')
    # points(x=max(branching.times(lad.tree)) - avgnodes$MU, y=nodebar_pos[,3], pch = 18, cex = 3, col = ifelse(branching.times(lad.tree)[-1] >= avgnodes$MU, 'blue','orange'))
    nodelabels(node = as.numeric(unlist(strsplit(lad.tree$node.label[grep('@',lad.tree$node.label)], '@'))) + ifelse(is.rooted(lad.tree), 1, 0), frame = 'none', pch = 8, adj = c(1.5,1), cex = 3)
    segments(x0 = max(branching.times(lad.tree)) + 7, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree)) + 7, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 8, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
    text(x = max(branching.times(lad.tree)) + 14, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 3, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
    rect(max(branching.times(lad.tree))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 185, max(branching.times(lad.tree))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 191, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
    text(x=max(branching.times(lad.tree))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
    if (i == length(SATrees)){
        axisPhylo(cex.axis=3, lwd = 3, padj = 1)
        mtext('Ma', side=1, at = 640, cex = 2, padj = 1.7)
        legend(x = 'bottomleft', legend = c('Calibrated nodes', EdgeBarTxtColors[[3]][,2]), pch = c(8, rep(15, nrow(EdgeBarTxtColors[[3]]))), col = c('black', EdgeBarTxtColors[[3]][,1]), text.col = c('black', EdgeBarTxtColors[[3]][,1]), cex = 2.5, bg = 'white', box.lwd =3)
    }
}
dev.off()

for (i in 1:length(SATrees)){
    svg(filename = paste('./SA_TimeTree-',as.character(i),'.svg', sep = ''), width = 50, height = 120, pointsize = 20)
    # lad.tree <- SATrees[[i]]@phylo
    # Centroid Tree
    lad.tree <- ladderize(SATrees[[i]]@phylo, right = T)
    # if (i == 1){
    EdgeBarTxtColors <- EdgeColors(lad.tree, ClassLong)
    # }
    nodebar_pos <- max(branching.times(lad.tree)) - Reduce(rbind, SATrees[[i]]@data$`0.95HPD`[order(as.numeric(SATrees[[i]]@data$node))])
    nodebar_pos <- cbind(nodebar_pos, node.height(lad.tree)[-c(1:(Ntip(lad.tree)+1))])
    hpd95 <- unlist(SATrees[[i]]@data[order(as.numeric(SATrees[[i]]@data$node)),'0.95HPD']) %>% matrix(ncol = 2, byrow = T)
    plot(lad.tree, edge.color = EdgeBarTxtColors[[1]], show.tip.label = TRUE, x.lim = c(0,800)-MaxBrTimeCompan_SA[i], main = paste('Sensativity Analysis Tree ', as.character(i), ': ', SATrees[[i]]@file, sep = ''), cex.main = 2, edge.width = 4)
    abline(v=max(branching.times(lad.tree))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
    abline(v=max(branching.times(lad.tree))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
    segments(x0=nodebar_pos[,1], y0=nodebar_pos[,3], x1=nodebar_pos[,2], y1=nodebar_pos[,3], lwd = 14, col = 'royalblue', lend = 'butt')
    nodelabels(node = as.numeric(unlist(strsplit(lad.tree$node.label[grep('@',lad.tree$node.label)], '@'))) + ifelse(is.rooted(lad.tree), 1, 0), frame = 'none', pch = 8, adj = c(1.5,1), cex = 2)
    segments(x0 = max(branching.times(lad.tree)) + 75, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree)) + 75, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 16, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
    text(x = max(branching.times(lad.tree)) + 80, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 2, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
    rect(max(branching.times(lad.tree))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 186, max(branching.times(lad.tree))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 190, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
    text(x=max(branching.times(lad.tree))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
    axisPhylo(cex.axis=3, lwd = 3, padj = 1)
    mtext('Ma', side=1, at = 640, cex = 3, padj = 1.7)
    legend(x = 'bottomleft', legend = c('Calibrated nodes', EdgeBarTxtColors[[3]][,2]), pch = c(8, rep(15, nrow(EdgeBarTxtColors[[3]]))), col = c('black', EdgeBarTxtColors[[3]][,1]), text.col = c('black', EdgeBarTxtColors[[3]][,1]), cex = 3, bg = 'white', box.lwd =3)
    dev.off()
}

rm(tre, nm, xxx, lad.tree, EdgeBarTxtColors, nodebar_pos)

# divergence time of key nodes----
keyclades <- c('root', 'EuMetazoa', 'Ecdysozoa', 'Arthropoda', 'Tardigrada', 'Nematomorpha', 'Nematoda', 'Enoplia (Clade II)', 'Dorylaimia (Clade I)', 'Chromadoria', 'Rhabditida','Spirurina (Clade III)', 'Tylenchina (Clade IV)', 'Rhabditina (Clade V)', 'Trichinellida', 'Tylenchomorpha', 'Diplogastromorpha', 'Strongyloididae', 'Ascarididae', 'Onchocercidae', 'Strongyloidea')

GetTime <- function(phy, tre='cnt', out = 'char'){
    keynodes <- c(getMRCA(phy@phylo, tip = row.names(Classification)), 
                  getMRCA(phy@phylo, tip = row.names(Classification)[-1]),
                  getMRCA(phy@phylo, tip = row.names(Classification)[-1:-9]),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Arthropoda']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Tardigrada']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Nematomorpha']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Phylum %in% c('Chromadoria','Dorylaimia','Enoplia')]),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Enoplia (Clade II)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Dorylaimia (Clade I)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Phylum=='Chromadoria']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade %in% c('Spirurina (Clade III)','Tylenchina (Clade IV)','Rhabditina (Clade V)')]),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Spirurina (Clade III)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Tylenchina (Clade IV)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Clade=='Rhabditina (Clade V)']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Order=='Trichinellida']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Order=='Tylenchomorpha']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Order=='Diplogastromorpha']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Family=='Strongyloididae']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Family=='Ascarididae']),
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Family=='Onchocercidae']), 
                  getMRCA(phy@phylo, tip = row.names(Classification)[Classification$Order=='Strongyloidea'])
    )
    if (out == 'char'){
        if (tre=='cnt'){
            hdi <- unlist(Map(function(x){paste(round(unlist(phy@data[phy@data$node==x, '0.95HPD']), digit=2), collapse=',')}, keynodes))
        }else if (tre=='avg'){
            hdi <- unlist(Map(function(x){paste(round(unlist(phy@data[phy@data$node==x, '0.95HPD_RLX']), digit=2), collapse=',')}, keynodes))
        }
        bt <- round(branching.times(phy@phylo)[keynodes - Ntip(phy@phylo)],2)
        
        res <- paste(bt, '[', hdi, ']', sep='')
        names(res) <- keyclades
    }else if (out == 'num'){
        if (tre=='cnt'){
            res <- cbind(bt = branching.times(phy@phylo)[keynodes - Ntip(phy@phylo)], t(sapply(Map(function(x){unlist(phy@data[phy@data$node==x, '0.95HPD'])}, keynodes), c)))
        }else if (tre=='avg'){
            res <- cbind(bt = branching.times(phy@phylo)[keynodes - Ntip(phy@phylo)], t(sapply(Map(function(x){unlist(phy@data[phy@data$node==x, '0.95HPD_RLX'])}, keynodes), c)))
        }
        rownames(res) <- keyclades
    }
    return(res)
}

write.csv(cbind(Cluster=c(1:length(SATrees)), Reduce(rbind, lapply(SATrees, GetTime, tre='cnt')), Treefile=unlist(Map(function(x){SATrees[[x]]@file}, 1:length(SATrees)))), file = './KeyCladeTime_SATrees.csv', row.names = F)

# saveRDS(SATrees, file = './SATrees.rds')

## streamer plot----
# SATrees <- readRDS('/mnt/hdd2/Nematoda/timing/20241203/CalibrSensitivityAnalysis/FinalTimeTrees/SATrees.rds')
GrpCntTrees_tSNE <- readRDS('./GrpCntTrees_tSNE.rds')
GrpAvgTrees_tSNE <- readRDS('./GrpAvgTrees_tSNE.rds')
GrpCntTrees_PRD <- readRDS('./GrpCntTrees_PRD.rds')
GrpAvgTrees_PRD <- readRDS('./GrpAvgTrees_PRD.rds')
GrpCntTrees_AEC <- readRDS('./GrpCntTrees_AEC.rds')
GrpAvgTrees_AEC <- readRDS('./GrpAvgTrees_AEC.rds')

GrpCntTrees_tSNE_CladeAges <- lapply(GrpCntTrees_tSNE, GetTime, tre='cnt', out='num')
GrpAvgTrees_tSNE_CladeAges <- lapply(GrpAvgTrees_tSNE, GetTime, tre='avg', out='num')
GrpCntTrees_PRD_CladeAges <- lapply(GrpCntTrees_PRD, GetTime, tre='cnt', out='num')
GrpAvgTrees_PRD_CladeAges <- lapply(GrpAvgTrees_PRD, GetTime, tre='avg', out='num')
GrpCntTrees_AEC_CladeAges <- lapply(GrpCntTrees_AEC, GetTime, tre='cnt', out='num')
GrpAvgTrees_AEC_CladeAges <- lapply(GrpAvgTrees_AEC, GetTime, tre='avg', out='num')

SATrees_CladeAges <- lapply(SATrees, GetTime, tre='cnt', out='num')

StrmPlotCladeAges <- NULL

for (i in 1:length(GrpCntTrees_tSNE_CladeAges)) {
    StrmPlotCladeAges <- append(StrmPlotCladeAges, GrpCntTrees_tSNE_CladeAges[i])
    StrmPlotCladeAges <- append(StrmPlotCladeAges, GrpAvgTrees_tSNE_CladeAges[i])
}

for (i in 1:length(GrpCntTrees_PRD_CladeAges)) {
    StrmPlotCladeAges <- append(StrmPlotCladeAges, GrpCntTrees_PRD_CladeAges[i])
    StrmPlotCladeAges <- append(StrmPlotCladeAges, GrpAvgTrees_PRD_CladeAges[i])
}

for (i in 1:length(GrpCntTrees_AEC_CladeAges)) {
    StrmPlotCladeAges <- append(StrmPlotCladeAges, GrpCntTrees_AEC_CladeAges[i])
    StrmPlotCladeAges <- append(StrmPlotCladeAges, GrpAvgTrees_AEC_CladeAges[i])
}

StrmPlotCladeAges <- append(StrmPlotCladeAges, SATrees_CladeAges)

# for (i in 1:nrow(StrmPlotCladeAges[[1]])){
df <- lapply(as.list(1:nrow(StrmPlotCladeAges[[1]])), function(i){as.data.frame(Reduce(rbind, lapply(StrmPlotCladeAges, function(x, r){x[r,]}, r = i)))})
df <- Reduce(rbind, df)
df$Tree <- rep(1:length(StrmPlotCladeAges), nrow(StrmPlotCladeAges[[1]]))
df$Clade <- rep(keyclades, each=length(StrmPlotCladeAges))
rownames(df) <- NULL
colnames(df) <- c("bt", "HPD1", "HPD2", "Tree", "Clade")

svg('./Key_Clade_Ages.svg', width = 18, height = 18, pointsize = 12)
pushViewport(viewport(layout = grid.layout(nrow = nrow(StrmPlotCladeAges[[1]]), ncol = 1)))
for (i in 1:nrow(StrmPlotCladeAges[[1]])){
    df <- as.data.frame(Reduce(rbind, lapply(StrmPlotCladeAges, function(x, r){x[r,]}, r = i)))
    if (i == nrow(StrmPlotCladeAges[[1]])){
        cldsp0<-ggplot()+
            stat_xspline(aes(x=1:length(StrmPlotCladeAges), y= df[,2]), spline_shape = -0.5, col = 'gray80')+
            stat_xspline(aes(x=1:length(StrmPlotCladeAges), y= df[,3]), spline_shape = -0.5, col = 'gray80')+
            theme_bw()+
            theme(panel.grid = element_blank(), axis.text=element_text(size=6), axis.title.y = element_text(angle = 90, vjust = 0.5, hjust=0.5, size=6), panel.border = element_blank(), panel.background = element_blank(), axis.line = element_line(color = 'black'))+
            ylab(keyclades[i])
    }else{
        cldsp0<-ggplot()+
            stat_xspline(aes(x=1:length(StrmPlotCladeAges), y= df[,2]), spline_shape = -0.5, col = 'gray80')+
            stat_xspline(aes(x=1:length(StrmPlotCladeAges), y= df[,3]), spline_shape = -0.5, col = 'gray80')+
            theme_bw()+
            theme(panel.grid = element_blank(), axis.text=element_text(size=6), axis.title.y = element_text(angle = 90, vjust = 0.5, hjust=0.5, size=6), panel.border = element_blank(), panel.background = element_blank(), axis.line.y = element_line(color = 'black'), axis.line.x = element_blank())+
            ylab(keyclades[i])
    }
    gg <- ggplot_build(cldsp0)
    cldsp1<-cldsp0+
        geom_polygon(mapping=aes(x=c(gg$data[[1]]$x,rev(gg$data[[2]]$x)), y=c(gg$data[[1]]$y,rev(gg$data[[2]]$y))), fill='gray80', alpha=1)+
        geom_xspline(mapping=aes(x=1:length(StrmPlotCladeAges), y= df[,1]), spline_shape = -0.5, col = 'gray40', linetype = 1)+
        geom_point(mapping=aes(x=1:length(StrmPlotCladeAges), y= df[,1]), size = 0.5, col = 'gray20')
    if (i == nrow(StrmPlotCladeAges[[1]])){
        cldsp2<-cldsp1+
            scale_x_discrete(limits=factor(1:length(StrmPlotCladeAges)), labels=c(rep(c('C','A'), 0.5 * (length(StrmPlotCladeAges)-length(SATrees_CladeAges))), rep(c('CST1', 'CST2', 'CST3', 'CST4'), length(SATrees_CladeAges)/4)))+
            xlab(element_blank())
    }else{
        cldsp2<-cldsp1+
            scale_x_discrete(element_blank())+
            xlab(element_blank())
    }
    print(cldsp2, vp = viewport(layout.pos.row = i, layout.pos.col = 1))
}
dev.off()

## Combine streamer plots into a single coordinates----
# KeyCladeColors <- c("#1F78B4", "#33A02C", "#E31A1C", "#FF7F00", "#6A3D9A", 
#                     "#B15928", "#A6CEE3", "#B2DF8A", "#FB9A99", "#FDBF6F", 
#                     "#CAB2D6", "#FFFF99", "#1B9E77", "#D95F02", "#7570B3", 
#                     "#E7298A", "#66A61E", "#E6AB02", "#A6761D", "#666666", 
#                     "#F0E442")
# 
# svg('./Key_Clade_Ages_allinone.svg', width = 18, height = 18, pointsize = 12)
# cldsp <- ggplot()
# for (i in 1:nrow(StrmPlotCladeAges[[1]])){
#     df <- as.data.frame(Reduce(rbind, lapply(StrmPlotCladeAges, function(x, r){x[r,]}, r = i)))
#     cldsp0 <- ggplot()+
#         stat_xspline(aes(x=1:length(StrmPlotCladeAges), y= df[,2]), spline_shape = -0.5, col = KeyCladeColors[i], alpha=0.8)+
#         stat_xspline(aes(x=1:length(StrmPlotCladeAges), y= df[,3]), spline_shape = -0.5, col = KeyCladeColors[i], alpha=0.8)
#     gg <- ggplot_build(cldsp0)
#     ggx <- c(gg$data[[1]]$x,rev(gg$data[[2]]$x))
#     ggy <- c(gg$data[[1]]$y,rev(gg$data[[2]]$y))
#     rm(cldsp0, gg)
#     cldsp <- cldsp + 
#         geom_polygon(mapping=aes(x=ggx, y=ggy), fill=KeyCladeColors[i], alpha=0.5) + 
#         geom_xspline(mapping=aes(x=1:length(StrmPlotCladeAges), y= df[,1]), spline_shape = -0.5, col = KeyCladeColors[i], linetype = 1) + 
#         geom_point(mapping=aes(x=1:length(StrmPlotCladeAges), y= df[,1]), size = 0.5, col = KeyCladeColors[i]) + 
#         geom_text(aes(x = length(StrmPlotCladeAges) + 0.5, y = df[nrow(df),1], label = keyclades[i], color = KeyCladeColors[i]), hjust = 0, size = 3)  # 在右侧添加标签
# }
# cldsp <- cldsp + 
#     theme_bw() + 
#     theme(panel.grid = element_blank(), axis.text=element_text(size=6), axis.title.y = element_text(angle = 90, vjust = 0.5, hjust=0.5, size=6), panel.border = element_blank(), panel.background = element_blank(), axis.line.y = element_line(color = 'black'), axis.line.x = element_blank()) + 
#     scale_x_discrete(limits=factor(1:length(StrmPlotCladeAges)), labels=c(rep(c('C','A'), 0.5 * (length(StrmPlotCladeAges)-length(SATrees_CladeAges))), rep(c('CST1', 'CST2', 'CST3', 'CST4'), length(SATrees_CladeAges)/4))) + 
#     xlab('Clusters and Sensitivity Analysis') + 
#     ylab('Clade Age (Ma)')
# print(cldsp)
# dev.off()

GrpAvg_SA_Timetrees <- c(GrpAvgTrees_PRD, SATrees[c(1, 5, 9, 13, 17)])

MaxBrTimeAVG_SA <- unlist(lapply(GrpAvg_SA_Timetrees, function(x){max(branching.times(x@phylo))}))
MaxBrTimeAVG_SA <- max(MaxBrTimeAVG_SA)-MaxBrTimeAVG_SA

svg(filename = './GrpAvg_SA_Timetrees_simple.svg', width = 40, height = 80, pointsize = 12)
layout(mat = matrix(c(1:length(GrpAvg_SA_Timetrees)),nrow = length(GrpAvg_SA_Timetrees)))
j <- 1
for (i in 1:length(GrpAvg_SA_Timetrees)){
    
    # if (i <= length(GrpAvgTrees_PRD)){
    #     xxx <- paste('Average Tree of Cluster ', as.character(i), ': ', GrpAvgTrees_PRD[[i]]@file, sep = '')
    # }else{
    #     xxx <- paste('Sensitivity Analysis Time Tree ', as.character(j), ': ', SATrees[[j]]@file, sep = '')
    #     j <- j+4
    # }
    
    lad.tree <- ladderize(GrpAvg_SA_Timetrees[[i]]@phylo, right = T)
    EdgeBarTxtColors <- EdgeColors(lad.tree, ClassShort)
    plot(lad.tree, edge.color = EdgeBarTxtColors[[1]], show.tip.label = FALSE, x.lim = c(0,750)-MaxBrTimeAVG_SA[i], main = , cex.main = 3, edge.width = 4)
    abline(v=max(branching.times(lad.tree))-seq(0,600,100), lty = 'solid', lend = 'butt', col = "gray30", lwd = 3)
    abline(v=max(branching.times(lad.tree))-seq(50,650,100), lty = 'dotdash', lend = 'butt', col = "gray60", lwd = 3)
    segments(x0 = max(branching.times(lad.tree)) + 7, y0 = EdgeBarTxtColors[[2]]$by0, x1 = max(branching.times(lad.tree)) + 7, y1 = EdgeBarTxtColors[[2]]$by1, lwd = 8, col = EdgeBarTxtColors[[2]]$btc, lend = 'butt')
    if (i == 1){
    text(x = max(branching.times(lad.tree)) + 14, y = EdgeBarTxtColors[[2]]$ty, labels = EdgeBarTxtColors[[4]], cex = 3, col = EdgeBarTxtColors[[2]]$btc, adj = c(0,0.5))
    rect(max(branching.times(lad.tree))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), 185, max(branching.times(lad.tree))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 191, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
    text(x=max(branching.times(lad.tree))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=188, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
    }
    if (i == length(GrpAvg_SA_Timetrees)){
        rect(max(branching.times(lad.tree))-c(66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8, 650), -6, max(branching.times(lad.tree))-c(0, 66, 145, 201.4, 251.902, 298.9, 358.9, 419.2, 443.8, 485.4, 538.8), 0, border = NA, col = c('#8ecfc9','#ffbe7a','#fa7f6f','#82b0d2cc','#beb8dc','#e7dad2','#999900','#c497b2','#1450908a','#a9b8c6','#8e8bfe'))
        text(x=max(branching.times(lad.tree))-c(33, 105.5, 173.2, 226.651, 275.401, 328.9, 389.05, 431.5, 464.6, 512.1, 570), y=-3, labels = c('Cz', 'K', 'J', 'T', 'P', 'Cn', 'D', 'S', 'O', 'Cm', 'PreCm'), cex = 2)
        axisPhylo(cex.axis=3, lwd = 3, padj = 6)
        mtext('Ma', side=1, at = 640, cex = 2, padj = 1.7)
        legend(x = 'bottomleft', legend = EdgeBarTxtColors[[3]][,2], pch = rep(15, nrow(EdgeBarTxtColors[[3]])), col = EdgeBarTxtColors[[3]][,1], text.col = EdgeBarTxtColors[[3]][,1], cex = 2.5, bg = 'white', box.lwd =3)
    }
}
dev.off()

rm(i, gg, df, cldsp0, cldsp1, cldsp2)

system('bash ./svg2pdf.sh r')

save.image('/mnt/hdd2/Nematoda/timing/20241203/SensAna.RData')
