# Time-Tree analyses, selection, and integration

## Loading libraries----
library(ape)
# library(data.table)
library(caTools);library(rpart);library(rpart.plot);library(caret);library(dplyr);library(treeio)

## Setting directory and loading image----
# setwd('G:/BristolProjects/Nematoda/timing')
# setwd('F:/Nematoda/timing/20241203')
setwd('/mnt/hdd2/Nematoda/timing/20241203/AllPosteriorTimeTree.cLGPMSF')
load('/mnt/hdd2/Nematoda/timing/20241203/AllPosteriorTimeTree.CLGPMSF.RData')
# save.image('/mnt/hdd2/Nematoda/timing/20241203/AllPosteriorTimeTree.CLGPMSF.RData')

## Reading data----
Classification <- read.csv('../Classification.csv', header = T, row.names = 1)
ClassLong <- c(Classification[1:28,'Phylum'],Classification[-(1:28),'Order'])
ClassShort <- c(Classification[1:28,'Phylum'],Classification[-(1:28),'Clade'])
names(ClassLong) <- names(ClassShort) <- row.names(Classification)
allfiles <- dir(getwd())
alltreefiles <- allfiles[grep("^NMtimetree[A-Za-z0-9_\\.]*\\.tre", allfiles)]

AllTrees <- NULL
mcmc <- data.frame(matrix(NA,nrow = length(alltreefiles),ncol = 7))
colnames(mcmc) <- c('cvg','sf','cst','fp','part','corr','rg')
mcmc$cvg <- rep(NA,length(alltreefiles))
BrTime <- matrix(NA,nrow = length(alltreefiles), ncol = 184)
TimeRange3 <- NULL

for (i in 1:length(alltreefiles)){
    tre <- read.beast(alltreefiles[i])
    nm <- strsplit(substr(alltreefiles[i], nchar('NMtimetree_cLGPMSF.')+1, nchar(alltreefiles[i])-4), '_combined_time_tree_')[[1]]
    xxx <- strsplit(nm[1], '[.]')[[1]]
    mcmc[i,] <- c(ifelse(nm[2]=='good','G','B'),
                  gsub('BD11','',xxx[1]),
                  substr(xxx[2],4,4),
                  toupper(gsub('CST[1-4]','',xxx[2])),
                  toupper(xxx[3]),
                  toupper(xxx[4]),
                  gsub('rg','',xxx[5]))
    BrTime[i,] <- yyy <- branching.times(tre@phylo)
    HPD95 <- matrix(unlist(tre@data['0.95HPD']),2,Ntip(tre@phylo)-1)[,order(tre@data$node)]
    AllTrees[[i]] <- tre
    TimeRange3[[i]] <- rbind(HPD95[1,], yyy[-1], HPD95[2,])
}
mcmc[mcmc[,4]=='',4] <- '0'

rm(list=c('allfiles', 'xxx', 'yyy', 'nm', 'tre', 'i'))

mcmc$cvg <- factor(mcmc$cvg, levels = c('B','G')) # arbitrary order
mcmc$sf <- factor(mcmc$sf, levels = c("0","005","1")[order(table(mcmc[mcmc$cvg=='G','sf']))])
mcmc$cst <- factor(mcmc$cst, levels = c("1","2","3","4")[order(table(mcmc[mcmc$cvg=='G','cst']))])
mcmc$fp <- factor(mcmc$fp, levels = c("0","A","B")[order(table(mcmc[mcmc$cvg=='G','fp']))])
mcmc$part <- factor(mcmc$part, levels = c("1P","5P")) 
mcmc$corr <- factor(mcmc$corr, levels = c("AR","IR")[order(table(mcmc[mcmc$cvg=='G','corr']))])
mcmc$rg <- factor(mcmc$rg, levels = c("15","20","25")[order(table(mcmc[mcmc$cvg=='G','rg']))])

# dummy variables====
# mcmc.dump <- predict(dummyVars(~ ., data = mcmc[,c(2,4,7)], fullRank = T), mcmc[,c(2,4,7)])
cst.stg <- data.frame(matrix(NA, nrow(mcmc), 2))
colnames(cst.stg) <- c('cstLM', 'cstLS')
cst.stg[mcmc$cst==1,] <- matrix(c(0,0), sum(mcmc$cst==1), 2, byrow = T)
cst.stg[mcmc$cst==2,] <- matrix(c(0,1), sum(mcmc$cst==2), 2, byrow = T)
cst.stg[mcmc$cst==3,] <- matrix(c(1,0), sum(mcmc$cst==3), 2, byrow = T)
cst.stg[mcmc$cst==4,] <- matrix(c(1,1), sum(mcmc$cst==4), 2, byrow = T)

fp <- data.frame(matrix(NA, nrow(mcmc), 2))
colnames(fp) <- c('fpFull', 'fpOI')
fp[mcmc$fp=='0',] <- matrix(c(1,0), sum(mcmc$fp=='0'), 2, byrow = T)
fp[mcmc$fp=='A',] <- matrix(c(0,1), sum(mcmc$fp=='A'), 2, byrow = T)
fp[mcmc$fp=='B',] <- matrix(c(0,0), sum(mcmc$fp=='B'), 2, byrow = T)

mcmc.dump <- cbind(mcmc[,c(-3,-4)], cst.stg, fp)
mcmc.dump$sf <- NA
mcmc.dump$sf[mcmc$sf=="0"] <- 0
mcmc.dump$sf[mcmc$sf=="005"] <- 1
mcmc.dump$sf[mcmc$sf=="1"] <- 2
mcmc.dump$rg <- NA
mcmc.dump$rg[mcmc$rg=='15'] <- 0
mcmc.dump$rg[mcmc$rg=='20'] <- 1
mcmc.dump$rg[mcmc$rg=='25'] <- 2

mcmc.dump.bin <- cbind(ifelse(mcmc.dump[,c(1,3,4)]=='B' | mcmc.dump[,c(1,3,4)]=='1P' | mcmc.dump[,c(1,3,4)]=='AR',0,1), mcmc.dump[,c(-1,-3,-4)])

# mcmc.dump.logical <- as.data.frame(lapply(mcmc.dump.bin, as.logical))
mcmc.dump <- as.data.frame(lapply(mcmc.dump, factor))

## Factors that determine the convergence (Decision tree)----
cart.model <- rpart(cvg ~ ., data = mcmc.dump, method = "class")
svg(filename = '../Res_posttrees/CART.model.decisiontree.svg', width = 8, height = 6, bg = 'white', pointsize = 12)
rpart.plot(cart.model)
dev.off()
importances <- varImp(cart.model)
importances %>% arrange(desc(Overall))
#          Overall
# part   57.041667
# corr   56.310185
# cstLS  21.273148
# fpOI   13.564815
# cstLM   5.532407
# fpFull  3.402778
# rg      1.388889
# sf      1.148148

